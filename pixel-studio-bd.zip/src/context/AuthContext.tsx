import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Wallet, Language } from '../types';

interface AuthContextType {
  user: User | null;
  token: string | null;
  wallet: Wallet;
  language: Language;
  setLanguage: (lang: Language) => void;
  toggleLanguage: () => void;
  activeView: string;
  setActiveView: (view: string) => void;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  register: (name: string, email: string, mobile: string, password: string, role?: string) => Promise<{ success: boolean; error?: string }>;
  adminLogin: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  refreshUser: () => Promise<void>;
  // Modals
  isAuthModalOpen: boolean;
  authModalTab: 'login' | 'register' | 'admin';
  openAuthModal: (tab?: 'login' | 'register' | 'admin') => void;
  closeAuthModal: () => void;
  isWalletModalOpen: boolean;
  openWalletModal: (tab?: 'deposit' | 'withdraw' | 'ledger') => void;
  closeWalletModal: () => void;
  isPostJobModalOpen: boolean;
  openPostJobModal: () => void;
  closePostJobModal: () => void;
  isEmployerReqModalOpen: boolean;
  openEmployerReqModal: () => void;
  closeEmployerReqModal: () => void;
  isSupportModalOpen: boolean;
  openSupportModal: () => void;
  closeSupportModal: () => void;
  isProfileModalOpen: boolean;
  openProfileModal: () => void;
  closeProfileModal: () => void;
  walletModalTab: 'deposit' | 'withdraw' | 'ledger';
}

const defaultWallet: Wallet = {
  availableBalance: 0,
  pendingBalance: 0,
  heldBalance: 0,
  totalEarned: 0,
  totalDeposited: 0,
  totalWithdrawn: 0
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('pixel_token'));
  const [wallet, setWallet] = useState<Wallet>(defaultWallet);
  const [language, setLanguageState] = useState<Language>(() => {
    return (localStorage.getItem('pixel_lang') as Language) || 'bn';
  });
  const [activeView, setActiveView] = useState<string>('home');
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Modals
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalTab, setAuthModalTab] = useState<'login' | 'register' | 'admin'>('login');
  const [isWalletModalOpen, setIsWalletModalOpen] = useState(false);
  const [isPostJobModalOpen, setIsPostJobModalOpen] = useState(false);
  const [isEmployerReqModalOpen, setIsEmployerReqModalOpen] = useState(false);
  const [isSupportModalOpen, setIsSupportModalOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [walletModalTab, setWalletModalTab] = useState<'deposit' | 'withdraw' | 'ledger'>('deposit');

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('pixel_lang', lang);
  };

  const toggleLanguage = () => {
    const next = language === 'bn' ? 'en' : 'bn';
    setLanguage(next);
  };

  const openAuthModal = (tab: 'login' | 'register' | 'admin' = 'login') => {
    setAuthModalTab(tab);
    setIsAuthModalOpen(true);
  };

  const closeAuthModal = () => setIsAuthModalOpen(false);
  const openWalletModal = (tab: 'deposit' | 'withdraw' | 'ledger' = 'deposit') => {
    setWalletModalTab(tab);
    setIsWalletModalOpen(true);
  };
  const closeWalletModal = () => setIsWalletModalOpen(false);
  const openPostJobModal = () => setIsPostJobModalOpen(true);
  const closePostJobModal = () => setIsPostJobModalOpen(false);
  const openEmployerReqModal = () => setIsEmployerReqModalOpen(true);
  const closeEmployerReqModal = () => setIsEmployerReqModalOpen(false);
  const openSupportModal = () => setIsSupportModalOpen(true);
  const closeSupportModal = () => setIsSupportModalOpen(false);
  const openProfileModal = () => setIsProfileModalOpen(true);
  const closeProfileModal = () => setIsProfileModalOpen(false);

  // Fetch current user & wallet data
  const refreshUser = async () => {
    if (!token) {
      setUser(null);
      setWallet(defaultWallet);
      setIsLoading(false);
      return;
    }
    try {
      const res = await fetch('/api/auth/me', {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
        if (data.wallet) {
          setWallet(data.wallet);
        }
      } else {
        localStorage.removeItem('pixel_token');
        setToken(null);
        setUser(null);
      }
    } catch (e) {
      console.error('Failed to fetch auth state:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    refreshUser();
  }, [token]);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('master') === 'pixel') {
      openAuthModal('admin');
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, []);

  const login = async (email: string, password: string) => {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Login failed' };
      }
      localStorage.setItem('pixel_token', data.token);
      setToken(data.token);
      setUser(data.user);
      setIsAuthModalOpen(false);
      await refreshUser();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error' };
    }
  };

  const adminLogin = async (email: string, password: string) => {
    try {
      const res = await fetch('/api/auth/admin-login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Admin login failed' };
      }
      localStorage.setItem('pixel_token', data.token);
      setToken(data.token);
      setUser(data.user);
      setIsAuthModalOpen(false);
      setActiveView('admin');
      await refreshUser();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error' };
    }
  };

  const register = async (name: string, email: string, mobile: string, password: string, role?: string) => {
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, mobile, password, role })
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Registration failed' };
      }
      localStorage.setItem('pixel_token', data.token);
      setToken(data.token);
      setUser(data.user);
      setIsAuthModalOpen(false);
      await refreshUser();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error' };
    }
  };

  const logout = () => {
    localStorage.removeItem('pixel_token');
    window.location.href = '/';
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        wallet,
        language,
        setLanguage,
        toggleLanguage,
        activeView,
        setActiveView,
        isLoading,
        login,
        register,
        adminLogin,
        logout,
        refreshUser,
        isAuthModalOpen,
        authModalTab,
        openAuthModal,
        closeAuthModal,
        isWalletModalOpen,
        openWalletModal,
        closeWalletModal,
        isPostJobModalOpen,
        openPostJobModal,
        closePostJobModal,
        isEmployerReqModalOpen,
        openEmployerReqModal,
        closeEmployerReqModal,
        isSupportModalOpen,
        openSupportModal,
        closeSupportModal,
        isProfileModalOpen,
        openProfileModal,
        closeProfileModal,
        walletModalTab
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
