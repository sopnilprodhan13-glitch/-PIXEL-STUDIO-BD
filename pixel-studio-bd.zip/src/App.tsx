import React, { useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { HeroBanner } from './components/HeroBanner';
import { JobsSection } from './components/JobsSection';
import { ServicesSection } from './components/ServicesSection';
import { FreelancingSection } from './components/FreelancingSection';
import { TutorialsSection } from './components/TutorialsSection';
import { AdminDashboard } from './components/AdminDashboard';
import { Footer } from './components/Footer';
import { FloatingSupport } from './components/FloatingSupport';
import { MobileBottomNav } from './components/MobileBottomNav';
import { AdsterraSlot } from './components/AdsterraSlot';
import { AuthModal } from './components/AuthModal';
import { WalletModal } from './components/WalletModal';
import { PostJobModal } from './components/PostJobModal';
import { EmployerRequestModal } from './components/EmployerRequestModal';
import { SupportModal } from './components/SupportModal';
import { ProfileModal } from './components/ProfileModal';
import { useTranslation } from './translations';
import {
  CheckCircle2,
  TrendingUp,
  ShieldCheck,
  CreditCard,
  Sparkles,
  ArrowRight
} from 'lucide-react';

const MainContent: React.FC = () => {
  const { user, activeView, setActiveView, openAuthModal, language } = useAuth();
  const t = useTranslation(language);

  // Add scroll to top when view changes
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [activeView]);

  // Check URL pathname for /admin or /admin/login
  useEffect(() => {
    const path = window.location.pathname.toLowerCase();
    if (path.includes('/admin/login')) {
      openAuthModal('admin');
    } else if (path.includes('/admin')) {
      setActiveView('admin');
    }
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-white text-slate-900 selection:bg-emerald-500/30 selection:text-emerald-900">
      <Navbar />

      <main className="flex-1">
        {activeView === 'home' && (
          <>
            <HeroBanner />

            {/* Adsterra Under Hero Slot */}
            <AdsterraSlot placement="underHero" />

            {/* How It Works 4-Step Architecture Strip */}
            <section className="py-12 border-b border-slate-200 bg-slate-50/50">
              <div className="max-w-7xl mx-auto px-4 sm:px-6">
                <div className="text-center max-w-2xl mx-auto mb-10">
                  <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 font-display">
                    {t.howTitle}
                  </h2>
                  <p className="text-xs text-slate-500 mt-1">
                    সহজ ৪টি ধাপে আয় করা শুরু করুন বিশ্বস্ত প্ল্যাটফর্মে
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                  <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-2">
                    <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-600 font-mono font-bold flex items-center justify-center text-sm">
                      ১
                    </div>
                    <h3 className="text-sm font-bold text-slate-900">{t.howStep1Title}</h3>
                    <p className="text-xs text-slate-500 leading-relaxed">{t.howStep1Desc}</p>
                  </div>

                  <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-2">
                    <div className="w-8 h-8 rounded-lg bg-teal-500/10 text-teal-600 font-mono font-bold flex items-center justify-center text-sm">
                      ২
                    </div>
                    <h3 className="text-sm font-bold text-slate-900">{t.howStep2Title}</h3>
                    <p className="text-xs text-slate-500 leading-relaxed">{t.howStep2Desc}</p>
                  </div>

                  <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-2">
                    <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-600 font-mono font-bold flex items-center justify-center text-sm">
                      ৩
                    </div>
                    <h3 className="text-sm font-bold text-slate-900">{t.howStep3Title}</h3>
                    <p className="text-xs text-slate-500 leading-relaxed">{t.howStep3Desc}</p>
                  </div>

                  <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-2">
                    <div className="w-8 h-8 rounded-lg bg-violet-500/10 text-violet-600 font-mono font-bold flex items-center justify-center text-sm">
                      ৪
                    </div>
                    <h3 className="text-sm font-bold text-slate-900">{t.howStep4Title}</h3>
                    <p className="text-xs text-slate-500 leading-relaxed">{t.howStep4Desc}</p>
                  </div>
                </div>
              </div>
            </section>

            {/* Find Jobs Marketplace Section */}
            <JobsSection />

            {/* Middle Adsterra Ad Slot */}
            <AdsterraSlot placement="middle" />

            {/* Digital Services Creative Suite */}
            <ServicesSection />

            {/* Freelancing Contracts */}
            <FreelancingSection />

            {/* YouTube Tutorials Section */}
            <TutorialsSection />

            {/* Footer Adsterra Ad Slot */}
            <AdsterraSlot placement="footer" />
          </>
        )}

        {activeView === 'jobs' && <JobsSection />}
        {activeView === 'freelancing' && <FreelancingSection />}
        {activeView === 'services' && <ServicesSection />}
        {activeView === 'tutorials' && <TutorialsSection />}

        {activeView === 'admin' && (
          user?.role === 'admin' ? (
            <AdminDashboard />
          ) : (
            <div className="max-w-md mx-auto my-20 p-8 rounded-2xl bg-white border border-slate-200 text-center shadow-xl space-y-4">
              <div className="w-12 h-12 rounded-full bg-amber-500/10 text-amber-600 flex items-center justify-center mx-auto">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h2 className="text-lg font-bold text-slate-900">অ্যাডমিন অ্যাক্সেস প্রয়োজন</h2>
              <p className="text-xs text-slate-500 leading-relaxed">
                এই ড্যাশবোর্ড ব্যবহারের জন্য অনুগ্রহ করে নির্দিষ্ট অ্যাডমিন ক্রেডেনশিয়াল দিয়ে লগইন করুন।
              </p>
              <button
                onClick={() => openAuthModal('admin')}
                className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs cursor-pointer"
              >
                অ্যাডমিন লগইন পোর্টাল খুলুন
              </button>
            </div>
          )
        )}
      </main>

      {/* Floating Live Support Widget */}
      <FloatingSupport />

      {/* Global Modals */}
      <AuthModal />
      <WalletModal />
      <PostJobModal />
      <EmployerRequestModal />
      <SupportModal />
      <ProfileModal />

      <Footer />
      <MobileBottomNav />
      <div className="h-16 lg:hidden" /> {/* Spacer for bottom nav */}
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <MainContent />
    </AuthProvider>
  );
}
