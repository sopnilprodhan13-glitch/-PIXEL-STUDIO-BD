import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTranslation } from '../translations';
import { DigitalService } from '../types';
import {
  Check,
  Clock,
  RotateCcw,
  Sparkles,
  ShoppingBag,
  X,
  CreditCard,
  AlertCircle
} from 'lucide-react';

export const ServicesSection: React.FC = () => {
  const { language, user, wallet, openAuthModal, openWalletModal, refreshUser } = useAuth();
  const t = useTranslation(language);

  const [services, setServices] = useState<DigitalService[]>([]);
  const [selectedService, setSelectedService] = useState<DigitalService | null>(null);
  const [selectedPackage, setSelectedPackage] = useState<'basic' | 'standard' | 'premium'>('standard');
  const [requirements, setRequirements] = useState<string>('');
  const [referenceLink, setReferenceLink] = useState<string>('');
  const [isOrdering, setIsOrdering] = useState<boolean>(false);
  const [orderFeedback, setOrderFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    fetch('/api/services')
      .then((res) => (res.ok ? res.json() : []))
      .then((data) => setServices(data))
      .catch((err) => console.error(err));
  }, []);

  const handleOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      openAuthModal('login');
      return;
    }
    if (!selectedService) return;

    const pkg = selectedService.packages[selectedPackage];
    const cost = pkg ? pkg.price : selectedService.startingPrice;

    if (wallet.availableBalance < cost) {
      setOrderFeedback({
        type: 'error',
        text: `ওয়ালেটে পর্যাপ্ত টাকা নেই। এই প্যাকেজের মূল্য ৳${cost}। দয়া করে আগে ডিপোজিট করুন।`
      });
      return;
    }

    setIsOrdering(true);
    setOrderFeedback(null);

    try {
      const token = localStorage.getItem('pixel_token');
      const res = await fetch(`/api/services/${selectedService.id}/order`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          packageType: selectedPackage,
          requirements,
          referenceLink
        })
      });

      const data = await res.json();
      if (res.ok) {
        setOrderFeedback({
          type: 'success',
          text: `অর্ডার সফলভাবে গ্রহণ করা হয়েছে! ডেলিভারি ডেডলাইনের মধ্যে সম্পন্ন হবে।`
        });
        setRequirements('');
        setReferenceLink('');
        await refreshUser();
      } else {
        setOrderFeedback({ type: 'error', text: data.error || 'অর্ডার করতে সমস্যা হয়েছে।' });
      }
    } catch (err: any) {
      setOrderFeedback({ type: 'error', text: err.message || 'Network error' });
    } finally {
      setIsOrdering(false);
    }
  };

  return (
    <section className="py-14 border-b border-slate-100" id="services-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="text-xs uppercase tracking-wider text-violet-600 font-bold mb-2 flex items-center justify-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Creative Studio Solutions</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display">
            {t.servicesTitle}
          </h2>
          <p className="text-sm text-slate-500 mt-2">
            {t.servicesSubtitle}
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((srv) => (
            <div
              key={srv.id}
              className="rounded-2xl bg-white border border-slate-200 hover:border-violet-500/50 transition-all p-5 flex flex-col justify-between group shadow-sm hover:shadow-md"
            >
              <div>
                {/* Thumbnail Image */}
                <div className="relative h-44 rounded-xl overflow-hidden mb-4 bg-slate-100">
                  <img
                    src={srv.thumbnail}
                    alt={srv.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-3 left-3 px-2.5 py-1 rounded-md bg-white/90 backdrop-blur-md text-[11px] font-semibold text-emerald-700 border border-emerald-100">
                    {srv.category}
                  </div>
                </div>

                {/* Title */}
                <h3 className="text-base font-bold text-slate-900 group-hover:text-violet-600 transition-colors mb-2">
                  {language === 'bn' && srv.titleBn ? srv.titleBn : srv.title}
                </h3>
                <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed mb-4">
                  {srv.description}
                </p>
              </div>

              <div>
                {/* Price and Order CTA */}
                <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                  <div>
                    <span className="text-[11px] text-slate-400 block">{t.startingFrom}</span>
                    <span className="text-lg font-extrabold text-emerald-600 font-mono">
                      ৳{srv.startingPrice}
                    </span>
                  </div>

                  <button
                    onClick={() => {
                      if (!user) {
                        openAuthModal('login');
                      } else {
                        setSelectedService(srv);
                        setSelectedPackage('standard');
                        setOrderFeedback(null);
                      }
                    }}
                    className="px-4 py-2 rounded-xl bg-violet-600 hover:bg-violet-700 text-white text-xs font-bold transition-all shadow-sm cursor-pointer flex items-center gap-1.5"
                  >
                    <ShoppingBag className="w-3.5 h-3.5" />
                    <span>{t.btnOrderPackage}</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Package Selector & Order Modal */}
      {selectedService && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
          <div className="bg-white border border-slate-200 w-full max-w-2xl rounded-2xl p-6 sm:p-7 max-h-[90vh] overflow-y-auto shadow-2xl relative">
            <button
              onClick={() => setSelectedService(null)}
              className="absolute top-5 right-5 text-slate-400 hover:text-slate-900 transition-colors cursor-pointer p-1"
            >
              <X className="w-5 h-5" />
            </button>

            <span className="text-xs font-bold text-violet-600 uppercase tracking-wider block mb-1">
              {selectedService.category}
            </span>
            <h3 className="text-xl font-extrabold text-slate-900 font-display mb-4">
              {language === 'bn' && selectedService.titleBn ? selectedService.titleBn : selectedService.title}
            </h3>

            {/* Package Tabs */}
            <div className="grid grid-cols-3 gap-2 p-1.5 bg-slate-50 rounded-xl border border-slate-200 mb-6">
              {(['basic', 'standard', 'premium'] as const).map((pkgKey) => {
                const pkg = selectedService.packages[pkgKey];
                const isActive = selectedPackage === pkgKey;
                return (
                  <button
                    key={pkgKey}
                    type="button"
                    onClick={() => setSelectedPackage(pkgKey)}
                    className={`py-2 px-2 text-center rounded-lg transition-all cursor-pointer ${
                      isActive
                        ? 'bg-violet-600 text-white font-bold shadow-sm'
                        : 'text-slate-500 hover:text-slate-900 hover:bg-white'
                    }`}
                  >
                    <div className="text-xs capitalize">{pkgKey}</div>
                    <div className={`text-xs font-mono font-bold ${isActive ? 'text-white' : 'text-slate-700'}`}>৳{pkg?.price}</div>
                  </button>
                );
              })}
            </div>

            {/* Selected Package Details */}
            {selectedService.packages[selectedPackage] && (
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 mb-6">
                <div className="flex items-center justify-between pb-3 border-b border-slate-200 mb-3">
                  <div className="font-bold text-slate-800 text-sm">
                    {selectedService.packages[selectedPackage].name}
                  </div>
                  <div className="text-lg font-bold text-emerald-600 font-mono">
                    ৳{selectedService.packages[selectedPackage].price}
                  </div>
                </div>

                <div className="flex items-center gap-6 text-xs text-slate-500 mb-3 font-medium">
                  <div className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-teal-600" />
                    <span>ডেলিভারি: {selectedService.packages[selectedPackage].deliveryDays} দিন</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <RotateCcw className="w-3.5 h-3.5 text-amber-600" />
                    <span>রিভিশন: {selectedService.packages[selectedPackage].revisions} বার</span>
                  </div>
                </div>

                <div className="space-y-1.5 text-xs text-slate-600">
                  {selectedService.packages[selectedPackage].features.map((feat, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <Check className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Order Form */}
            <form onSubmit={handleOrder} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  প্রয়োজনীয় নির্দেশনা (Requirements / Text / Colors):
                </label>
                <textarea
                  rows={3}
                  required
                  placeholder="আপনার ডিজাইন সম্পর্কে বিস্তারিত বলুন (কী কালার পছন্দ, কী টেক্সট থাকবে, কোন স্টাইল চান)..."
                  value={requirements}
                  onChange={(e) => setRequirements(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-violet-500 transition-colors resize-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  রেফারেন্স লিংক বা চ্যানেল লিংক (ঐচ্ছিক):
                </label>
                <input
                  type="url"
                  placeholder="https://youtube.com/@channel or sample image drive link"
                  value={referenceLink}
                  onChange={(e) => setReferenceLink(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-violet-500 transition-colors"
                />
              </div>

              {/* Wallet Balance Info */}
              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs">
                <span className="text-slate-500 flex items-center gap-1.5 font-medium">
                  <CreditCard className="w-3.5 h-3.5 text-emerald-600" />
                  <span>আপনার ওয়ালেট ব্যালেন্স:</span>
                </span>
                <span className="font-mono font-bold text-emerald-600 text-sm">
                  ৳{wallet.availableBalance}
                </span>
              </div>

              {orderFeedback && (
                <div
                  className={`p-3 rounded-xl text-xs font-medium ${
                    orderFeedback.type === 'success'
                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-100'
                      : 'bg-rose-50 text-rose-700 border border-rose-100'
                  }`}
                >
                  {orderFeedback.text}
                </div>
              )}

              <div className="pt-2 flex items-center justify-end gap-3">
                {wallet.availableBalance < (selectedService.packages[selectedPackage]?.price || 0) && (
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedService(null);
                      openWalletModal();
                    }}
                    className="px-4 py-2 rounded-xl bg-emerald-50 text-emerald-700 hover:bg-emerald-100 text-xs font-bold border border-emerald-100 cursor-pointer"
                  >
                    আগে ডিপোজিট করুন
                  </button>
                )}
                <button
                  type="submit"
                  disabled={isOrdering}
                  className="px-6 py-2.5 rounded-xl bg-violet-600 hover:bg-violet-700 text-white font-bold text-xs shadow-sm transition-all cursor-pointer disabled:opacity-50"
                >
                  {isOrdering ? 'অর্ডার হচ্ছে...' : `অর্ডার নিশ্চিত করুন (৳${selectedService.packages[selectedPackage]?.price})`}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </section>
  );
};
