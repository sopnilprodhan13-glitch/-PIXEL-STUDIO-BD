import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTranslation } from '../translations';
import { YouTubeTutorial } from '../types';
import { Play, Video, X } from 'lucide-react';

export const TutorialsSection: React.FC = () => {
  const { language, user, openAuthModal } = useAuth();
  const t = useTranslation(language);

  const [tutorials, setTutorials] = useState<YouTubeTutorial[]>([]);
  const [activeVideo, setActiveVideo] = useState<YouTubeTutorial | null>(null);

  useEffect(() => {
    fetch('/api/tutorials')
      .then((res) => (res.ok ? res.json() : []))
      .then((data) => setTutorials(data))
      .catch((err) => console.error(err));
  }, []);

  return (
    <section className="py-14 border-b border-slate-200" id="tutorials-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="text-xs uppercase tracking-wider text-emerald-400 font-bold mb-2 flex items-center justify-center gap-1.5">
            <Video className="w-3.5 h-3.5" />
            <span>Video Learning Hub</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display">
            {t.navTutorials} & গাইড
          </h2>
          <p className="text-sm text-slate-500 mt-2">
            কাজ শুরু করা, ডিপোজিট করা এবং টাকা উত্তোলনের সহজ ভিডিও গাইডলাইন
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {tutorials.map((tut) => (
            <div
              key={tut.id}
              onClick={() => {
                if (!user) {
                  openAuthModal('login');
                } else {
                  setActiveVideo(tut);
                }
              }}
              className="group cursor-pointer rounded-2xl bg-white border border-slate-200 hover:border-emerald-500/50 transition-all overflow-hidden flex flex-col justify-between shadow-sm"
            >
              <div>
                <div className="relative aspect-video bg-slate-100 overflow-hidden flex items-center justify-center">
                  <img
                    src={`https://img.youtube.com/vi/${tut.youtubeId}/hqdefault.jpg`}
                    alt={tut.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors flex items-center justify-center">
                    <div className="w-12 h-12 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                      <Play className="w-5 h-5 ml-0.5 fill-current" />
                    </div>
                  </div>
                </div>

                <div className="p-4">
                  <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider block mb-1">
                    {tut.category}
                  </span>
                  <h3 className="text-sm font-bold text-slate-900 group-hover:text-emerald-600 transition-colors line-clamp-2 leading-snug">
                    {language === 'bn' && tut.titleBn ? tut.titleBn : tut.title}
                  </h3>
                  <p className="text-xs text-slate-500 line-clamp-2 mt-2 leading-relaxed">
                    {tut.description}
                  </p>
                </div>
              </div>

              <div className="p-4 pt-0 text-[11px] font-semibold text-emerald-400 flex items-center gap-1">
                <span>ভিডিও দেখুন</span>
                <span aria-hidden="true">→</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Video Modal Player */}
      {activeVideo && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/90 backdrop-blur-sm animate-fade-in">
          <div className="bg-white border border-slate-200 w-full max-w-3xl rounded-2xl p-4 sm:p-6 shadow-2xl relative">
            <button
              onClick={() => setActiveVideo(null)}
              className="absolute -top-12 right-0 text-white hover:text-emerald-400 transition-colors cursor-pointer p-1"
            >
              <X className="w-6 h-6" />
            </button>

            <div className="relative aspect-video rounded-xl overflow-hidden bg-black mb-4">
              <iframe
                src={`https://www.youtube.com/embed/${activeVideo.youtubeId}?autoplay=1`}
                title={activeVideo.title}
                className="w-full h-full border-0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>

            <h3 className="text-lg font-bold text-slate-900 mb-1">
              {language === 'bn' && activeVideo.titleBn ? activeVideo.titleBn : activeVideo.title}
            </h3>
            <p className="text-xs text-slate-500">
              {activeVideo.description}
            </p>
          </div>
        </div>
      )}
    </section>
  );
};
