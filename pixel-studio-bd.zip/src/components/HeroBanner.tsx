import React from 'react';
import { useAuth } from '../context/AuthContext';
import { useTranslation } from '../translations';
import {
  ArrowRight,
  ShieldCheck,
  Sparkles,
  Zap,
  TrendingUp,
  Layers,
  CheckCircle2,
  Lock
} from 'lucide-react';

export const HeroBanner: React.FC = () => {
  const { language, setActiveView, openAuthModal, user, openWalletModal, activeView } = useAuth();
  const t = useTranslation(language);

  const handleProtectedAction = (view: typeof activeView) => {
    if (!user) {
      openAuthModal('login');
    } else {
      setActiveView(view);
    }
  };

  const [stats, setStats] = React.useState({
    activeJobs: 0,
    totalPaid: 0,
    activeFreelancers: 0,
    successRate: 0
  });

  React.useEffect(() => {
    fetch('/api/stats')
      .then(res => res.ok ? res.json() : null)
      .then(data => {
        if (data) setStats(data);
      })
      .catch(err => console.error('Error fetching stats:', err));
  }, []);

  return (
    <section className="relative overflow-hidden pt-10 pb-16 lg:pt-14 lg:pb-20 border-b border-slate-100">
      {/* Background radial glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[450px] bg-gradient-to-b from-emerald-500/5 via-teal-500/5 to-transparent blur-3xl pointer-events-none -z-10" />
      <div className="absolute -top-24 -left-20 w-96 h-96 bg-violet-600/5 rounded-full blur-3xl pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          {/* Left Column: Headlines & Call to Actions */}
          <div className="lg:col-span-7 flex flex-col items-start text-left">
            {/* Quiet text kicker with typographic separator */}
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-700 mb-4 bg-emerald-50 border border-emerald-100 px-3 py-1 rounded-full">
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
              <span>বাংলাদেশি নির্ভরযোগ্য মাইক্রো-জব ও ফ্রিল্যান্সিং প্ল্যাটফর্ম</span>
              <span aria-hidden="true">·</span>
              <span className="text-amber-600 font-bold">100% Manual Verification</span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 tracking-tight leading-[1.18] font-display mb-4 text-balance">
              {t.tagline}
            </h1>

            <p className="text-base sm:text-lg text-slate-600 mb-6 max-w-2xl leading-relaxed">
              {t.subTagline}
            </p>

            {/* Earning badge & disclaimer box */}
            <div className="w-full max-w-xl p-4 rounded-xl bg-slate-50 border border-slate-100 mb-8 shadow-sm">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-8 h-8 rounded-lg bg-emerald-100 border border-emerald-200 flex items-center justify-center shrink-0">
                  <TrendingUp className="w-4 h-4 text-emerald-600" />
                </div>
                <div>
                  <div className="text-sm font-bold text-emerald-800">
                    {t.earningPromise}
                  </div>
                  <div className="text-xs text-slate-500">
                    {t.earningDisclaimer}
                  </div>
                </div>
              </div>
            </div>

            {/* Main Action Buttons */}
            <div className="flex flex-wrap items-center gap-3 sm:gap-4 w-full">
              <button
                onClick={() => handleProtectedAction('jobs')}
                className="px-6 py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-lg shadow-emerald-500/20 transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap"
              >
                <span>{t.btnFindJobs}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => handleProtectedAction('freelancing')}
                className="px-5 py-3.5 rounded-xl bg-white border border-slate-200 hover:border-slate-400 text-slate-700 hover:text-slate-900 font-semibold text-sm transition-all cursor-pointer whitespace-nowrap"
              >
                {t.btnExploreFreelancing}
              </button>

              <button
                onClick={() => handleProtectedAction('services')}
                className="px-5 py-3.5 rounded-xl bg-violet-50 border border-violet-100 hover:bg-violet-100 text-violet-700 font-semibold text-sm transition-all cursor-pointer whitespace-nowrap"
              >
                {t.btnOurServices}
              </button>
            </div>

            {/* Trust highlights */}
            <div className="flex flex-wrap items-center gap-4 sm:gap-6 mt-8 text-xs text-slate-500 font-medium">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>বিকাশ · নগদ সাপোর্ট</span>
              </div>
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-teal-600" />
                <span>ম্যানুয়াল পেমেন্ট ভেরিফিকেশন</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Lock className="w-4 h-4 text-amber-600" />
                <span>জিরো ফ্রড পলিসি</span>
              </div>
            </div>
          </div>

          {/* Right Column: Visual Showcase Card */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl p-1 bg-gradient-to-b from-emerald-100 via-slate-100 to-violet-100 shadow-xl">
              <div className="bg-white rounded-2xl p-6 border border-slate-100">
                {/* Brand Badge */}
                <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                  <div className="flex items-center gap-3">
                    <img
                      src="/assets/aistudio/WhatsApp_Image_2026-11-06_at_11.02.12_AM_4c49fd8b.jpeg"
                      alt="Pixel Studio BD"
                      className="w-12 h-12 rounded-full border border-emerald-500 shadow-sm"
                    />
                    <div>
                      <h2 className="text-slate-900 font-bold text-sm font-display leading-tight">
                        PIXEL STUDIO BD
                      </h2>
                      <p className="text-xs text-emerald-600 font-bold">
                        Verified Ecosystem
                      </p>
                    </div>
                  </div>
                  <span className="text-xs px-2.5 py-1 rounded bg-emerald-50 text-emerald-700 font-mono font-bold border border-emerald-100">
                    BDT (৳) Active
                  </span>
                </div>

                {/* Popular Services Quick Showcase */}
                <div className="mt-5 space-y-3">
                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between hover:border-emerald-200 transition-colors">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-lg bg-emerald-100 flex items-center justify-center text-emerald-600 font-bold">
                        <Zap className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-sm font-bold text-slate-800">YouTube Thumbnail</div>
                        <div className="text-[10px] text-slate-500">Starts at ৳20</div>
                      </div>
                    </div>
                    <span className="text-xs font-mono font-bold text-emerald-600">৳20</span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between hover:border-emerald-200 transition-colors">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-lg bg-teal-100 flex items-center justify-center text-teal-600 font-bold">
                        <Layers className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-sm font-bold text-slate-800">Vector Logo</div>
                        <div className="text-[10px] text-slate-500">Starts at ৳20</div>
                      </div>
                    </div>
                    <span className="text-xs font-mono font-bold text-emerald-600">৳20</span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between hover:border-emerald-200 transition-colors">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-lg bg-violet-100 flex items-center justify-center text-violet-600 font-bold">
                        <Sparkles className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-sm font-bold text-slate-800">Video Reels</div>
                        <div className="text-[10px] text-slate-500">Starts at ৳50</div>
                      </div>
                    </div>
                    <span className="text-xs font-mono font-bold text-emerald-600">৳50</span>
                  </div>
                </div>

                {/* Instant Deposit / Action banner */}
                <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between">
                  <div className="text-xs text-slate-500 font-medium">
                    ন্যূনতম ডিপোজিট মাত্র <span className="text-emerald-600 font-bold font-mono">৳১০</span>
                  </div>
                  <button
                    onClick={user ? () => openWalletModal() : () => openAuthModal('register')}
                    className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all cursor-pointer whitespace-nowrap"
                  >
                    {user ? 'ওয়ালেট দেখুন' : 'একাউন্ট খুলুন'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 4-Column Metric Strip below hero */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-12 pt-8 border-t border-slate-100">
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 shadow-sm">
            <div className="text-[11px] text-slate-500 font-bold mb-1 uppercase tracking-wider">{t.statJobsAvailable}</div>
            <div className="text-2xl font-extrabold text-slate-900 font-mono tabular-nums">{stats.activeJobs}</div>
            <div className="text-[10px] text-slate-400 mt-1 font-medium">নতুন কাজ শীঘ্রই আসছে</div>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 shadow-sm">
            <div className="text-[11px] text-slate-500 font-bold mb-1 uppercase tracking-wider">{t.statTotalPaid}</div>
            <div className="text-2xl font-extrabold text-emerald-600 font-mono tabular-nums">৳{stats.totalPaid}</div>
            <div className="text-[10px] text-slate-400 mt-1 font-medium">সরাসরি বিকাশ ও নগদে</div>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 shadow-sm">
            <div className="text-[11px] text-slate-500 font-bold mb-1 uppercase tracking-wider">{t.statActiveFreelancers}</div>
            <div className="text-2xl font-extrabold text-slate-900 font-mono tabular-nums">{stats.activeFreelancers}</div>
            <div className="text-[10px] text-slate-400 mt-1 font-medium">প্লাটফর্মে সক্রিয় ইউজার</div>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 shadow-sm">
            <div className="text-[11px] text-slate-500 font-bold mb-1 uppercase tracking-wider">{t.statSuccessRate}</div>
            <div className="text-2xl font-extrabold text-amber-600 font-mono tabular-nums">{stats.successRate}%</div>
            <div className="text-[10px] text-slate-400 mt-1 font-medium">সঠিক কাজের পেমেন্ট নিশ্চিত</div>
          </div>
        </div>
      </div>
    </section>
  );
};
