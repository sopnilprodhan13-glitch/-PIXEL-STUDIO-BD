import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTranslation } from '../translations';
import {
  X,
  MessageSquare,
  PhoneCall,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  Send,
  CheckCircle2
} from 'lucide-react';

export const SupportModal: React.FC = () => {
  const { isSupportModalOpen, closeSupportModal, language, user } = useAuth();
  const t = useTranslation(language);

  const [contactName, setContactName] = useState(user?.name || '');
  const [contactEmail, setContactEmail] = useState(user?.email || '');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  if (!isSupportModalOpen) return null;

  const faqs = [
    {
      q: 'টাকা কীভাবে ডিপোজিট করব?',
      a: 'ওয়ালেট অপশনে গিয়ে bKash, Nagad বা Rocket নির্বাচন করুন। নির্দিষ্ট নম্বরে সেন্ড মানি করে TrxID ও প্রেরকের নম্বর জমা দিন। ৫–১৫ মিনিটের মধ্যে অ্যাডমিন ভেরিফাই করে ব্যালেন্স যোগ করবেন।'
    },
    {
      q: 'কাজের পারিশ্রমিক কীভাবে পাওয়া যায়?',
      a: 'কাজটি সম্পন্ন করে নির্ধারিত প্রুফ (লিংক বা স্ক্রিনশট) জমা দিন। এমপ্লয়ার অথবা অ্যাডমিন কাজটি যাচাই করে অনুমোদন দেওয়ার সাথে সাথে আপনার ওয়ালেটে টাকা যুক্ত হবে।'
    },
    {
      q: 'সর্বনিম্ন কত টাকা উত্তোলন করা যায়?',
      a: 'ওয়ালেটে নূন্যতম ১০০ টাকা ব্যালেন্স থাকলেই আপনি বিকাশ, নগদ অথবা রকেটে উত্তোলনের আবেদন করতে পারবেন।'
    },
    {
      q: 'এমপ্লয়ার হতে চাইলে কী করতে হবে?',
      a: 'মেনু থেকে "এমপ্লয়ার হন" ক্লিক করে আবেদন জমা দিন। এরপর দ্রুত অনুমোদনের জন্য আমাদের হোয়াটসঅ্যাপ বা টেলিগ্রাম সাপোর্টে আপনার রেজিস্টার্ড ইমেইল পাঠিয়ে জানান।'
    }
  ];

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setMessage('');
      closeSupportModal();
    }, 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/40 backdrop-blur-sm animate-fade-in">
      <div className="bg-white border border-slate-200 w-full max-w-2xl rounded-2xl p-6 sm:p-7 max-h-[92vh] overflow-y-auto shadow-2xl relative">
        <button
          onClick={closeSupportModal}
          className="absolute top-5 right-5 text-slate-400 hover:text-slate-600 transition-colors cursor-pointer p-1"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
            <HelpCircle className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xl font-extrabold text-slate-900 font-display">
              PIXEL STUDIO BD কাস্টমার সাপোর্ট
            </h3>
            <span className="text-xs text-slate-400">
              ২৪/৭ সরাসরি সাপোর্ট ও হেল্প ডেস্ক
            </span>
          </div>
        </div>

        {/* Quick Action Channels */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
          <a
            href="https://t.me/INCOME47776"
            target="_blank"
            rel="noreferrer"
            className="p-4 rounded-xl bg-[#229ED9]/5 hover:bg-[#229ED9]/10 border border-[#229ED9]/20 flex items-center gap-3 transition-all group"
          >
            <div className="w-10 h-10 rounded-lg bg-[#229ED9]/20 flex items-center justify-center text-[#229ED9] shrink-0 group-hover:scale-105 transition-transform">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs text-slate-500">অফিশিয়াল টেলিগ্রাম চ্যানেল</div>
              <div className="text-sm font-bold text-slate-900 group-hover:text-[#229ED9]">
                @INCOME47776
              </div>
            </div>
          </a>

          <a
            href="https://wa.me/8801320765354"
            target="_blank"
            rel="noreferrer"
            className="p-4 rounded-xl bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 flex items-center gap-3 transition-all group"
          >
            <div className="w-10 h-10 rounded-lg bg-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0 group-hover:scale-105 transition-transform">
              <PhoneCall className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs text-slate-500">হোয়াটসঅ্যাপ হটলাইন</div>
              <div className="text-sm font-bold text-slate-900 group-hover:text-emerald-600 font-mono">
                01320765354
              </div>
            </div>
          </a>
        </div>

        {/* FAQ Accordion */}
        <div className="mb-6">
          <h4 className="text-xs uppercase tracking-wider text-slate-500 font-bold mb-3">
            সাধারণ প্রশ্নোত্তর (Frequently Asked Questions):
          </h4>
          <div className="space-y-2">
            {faqs.map((faq, idx) => (
              <div
                key={idx}
                className="rounded-xl border border-slate-200 bg-slate-50 overflow-hidden"
              >
                <button
                  type="button"
                  onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
                  className="w-full p-3.5 text-left flex items-center justify-between text-xs font-bold text-slate-700 hover:text-slate-900 cursor-pointer"
                >
                  <span>{faq.q}</span>
                  {openFaq === idx ? (
                    <ChevronUp className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-slate-400" />
                  )}
                </button>
                {openFaq === idx && (
                  <div className="p-3.5 pt-0 text-xs text-slate-600 border-t border-slate-200 leading-relaxed">
                    {faq.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Direct Ticket Form */}
        <div className="pt-4 border-t border-slate-200">
          <h4 className="text-xs uppercase tracking-wider text-slate-500 font-bold mb-3">
            আমাদের মেসেজ পাঠান:
          </h4>
          {submitted ? (
            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-center text-emerald-700 text-xs font-bold flex items-center justify-center gap-2">
              <CheckCircle2 className="w-4 h-4" />
              <span>ধন্যবাদ! আপনার মেসেজ সাপোর্ট টিমের কাছে পৌঁছেছে। দ্রুত যোগাযোগ করা হবে।</span>
            </div>
          ) : (
            <form onSubmit={handleContactSubmit} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <input
                  type="text"
                  required
                  placeholder="আপনার নাম"
                  value={contactName}
                  onChange={(e) => setContactName(e.target.value)}
                  className="px-3.5 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-emerald-500"
                />
                <input
                  type="email"
                  required
                  placeholder="আপনার ইমেইল"
                  value={contactEmail}
                  onChange={(e) => setContactEmail(e.target.value)}
                  className="px-3.5 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <textarea
                rows={3}
                required
                placeholder="আপনার জিজ্ঞাসা বা সমস্যা বিস্তারিত লিখুন..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="w-full px-3.5 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-emerald-500 resize-none"
              />

              <div className="flex justify-end">
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md shadow-emerald-600/20 transition-all cursor-pointer flex items-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>মেসেজ পাঠান</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
