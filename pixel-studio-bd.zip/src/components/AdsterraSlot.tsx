import React, { useEffect, useState } from 'react';

interface AdsterraSlotProps {
  placement: 'underHero' | 'middle' | 'footer' | 'tutorial';
}

export const AdsterraSlot: React.FC<AdsterraSlotProps> = ({ placement }) => {
  const [adConfig, setAdConfig] = useState<{ enabled: boolean; code: string } | null>(null);

  useEffect(() => {
    fetch('/api/settings/adsterra')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data && data.enabled && data.slots && data.slots[placement]) {
          setAdConfig(data.slots[placement]);
        } else {
          setAdConfig(null);
        }
      })
      .catch(() => setAdConfig(null));
  }, [placement]);

  if (!adConfig || !adConfig.enabled || !adConfig.code || !adConfig.code.trim()) {
    return null; // Keep completely hidden if not enabled or no code
  }

  return (
    <div className="w-full max-w-5xl mx-auto my-6 px-4">
      <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-center flex flex-col items-center justify-center min-h-[90px] overflow-hidden relative">
        <span className="text-[10px] uppercase tracking-wider text-slate-500 font-mono mb-1">
          Adsterra Sponsored
        </span>
        <AdExecution code={adConfig.code} />
      </div>
    </div>
  );
};

const AdExecution: React.FC<{ code: string }> = ({ code }) => {
  const containerRef = React.useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;
    
    // Clear previous content
    containerRef.current.innerHTML = '';
    
    // Create a temporary container to parse the HTML string
    const parser = new Range().createContextualFragment(code);
    
    // Append the fragment to the container - this triggers script execution for contextual fragments
    containerRef.current.appendChild(parser);
  }, [code]);

  return <div ref={containerRef} className="w-full flex justify-center items-center overflow-x-auto" />;
};
