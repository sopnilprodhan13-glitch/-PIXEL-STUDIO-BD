import React from 'react';
import { useAuth } from '../context/AuthContext';
import { useTranslation } from '../translations';
import {
  Briefcase,
  PlusCircle,
  ArrowUpCircle,
  User,
  Home
} from 'lucide-react';

export const MobileBottomNav: React.FC = () => {
  const { user, activeView, setActiveView, openAuthModal, openWalletModal, openProfileModal, language } = useAuth();
  const t = useTranslation(language);

  // Hidden on desktop
  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-md border-t border-slate-200 px-2 pb-safe">
      <div className="max-w-md mx-auto flex items-center justify-around py-3">
        <button
          onClick={() => setActiveView('home')}
          className={`flex flex-col items-center gap-1 transition-colors ${
            activeView === 'home' ? 'text-emerald-600' : 'text-slate-400'
          }`}
        >
          <Home className="w-5 h-5" />
          <span className="text-[10px] font-bold">{t.navHome}</span>
        </button>

        <button
          onClick={() => {
            if (!user) {
              openAuthModal('login');
            } else {
              setActiveView('jobs');
            }
          }}
          className={`flex flex-col items-center gap-1 transition-colors ${
            activeView === 'jobs' ? 'text-emerald-600' : 'text-slate-400'
          }`}
        >
          <Briefcase className="w-5 h-5" />
          <span className="text-[10px] font-bold">{t.navFindJobs}</span>
        </button>

        <button
          onClick={() => {
            if (!user) {
              openAuthModal('login');
            } else {
              openWalletModal('deposit');
            }
          }}
          className="flex flex-col items-center gap-1 text-slate-400"
        >
          <PlusCircle className="w-5 h-5 text-emerald-500" />
          <span className="text-[10px] font-bold">ডিপোজিট</span>
        </button>

        <button
          onClick={() => {
            if (!user) {
              openAuthModal('login');
            } else {
              openWalletModal('withdraw');
            }
          }}
          className="flex flex-col items-center gap-1 text-slate-400"
        >
          <ArrowUpCircle className="w-5 h-5 text-amber-500" />
          <span className="text-[10px] font-bold">উত্তোলন</span>
        </button>

        <button
          onClick={() => {
            if (!user) {
              openAuthModal('login');
            } else {
              openProfileModal();
            }
          }}
          className={`flex flex-col items-center gap-1 transition-colors ${
            activeView === 'profile' ? 'text-emerald-600' : 'text-slate-400'
          }`}
        >
          <User className="w-5 h-5" />
          <span className="text-[10px] font-bold">প্রোফাইল</span>
        </button>
      </div>
    </nav>
  );
};
