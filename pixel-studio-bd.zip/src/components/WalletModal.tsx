import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTranslation } from '../translations';
import { PaymentMethod, LedgerItem, DepositRequest, WithdrawalRequest } from '../types';
import {
  X,
  Wallet as WalletIcon,
  ArrowDownLeft,
  ArrowUpRight,
  History,
  Copy,
  Check,
  Upload,
  AlertCircle,
  Clock,
  ShieldCheck
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const WalletModal: React.FC = () => {
  const { isWalletModalOpen, closeWalletModal, wallet, refreshUser, language, walletModalTab } = useAuth();
  const t = useTranslation(language);

  const [activeTab, setActiveTab] = useState<'deposit' | 'withdraw' | 'ledger'>('deposit');
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([]);
  const [ledger, setLedger] = useState<LedgerItem[]>([]);
  const [deposits, setDeposits] = useState<DepositRequest[]>([]);
  const [withdrawals, setWithdrawals] = useState<WithdrawalRequest[]>([]);

  // Deposit Form State
  const [depositAmount, setDepositAmount] = useState<string>('500');
  const [selectedMethod, setSelectedMethod] = useState<string>('bKash');
  const [trxId, setTrxId] = useState<string>('');
  const [senderNumber, setSenderNumber] = useState<string>('');
  const [screenshot, setScreenshot] = useState<string>('');
  const [isSubmittingDeposit, setIsSubmittingDeposit] = useState<boolean>(false);
  const [depositFeedback, setDepositFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [copiedNumber, setCopiedNumber] = useState<boolean>(false);

  // Withdrawal Form State
  const [withdrawAmount, setWithdrawAmount] = useState<string>('200');
  const [withdrawMethod, setWithdrawMethod] = useState<string>('bKash');
  const [withdrawAccountNumber, setWithdrawAccountNumber] = useState<string>('');
  const [withdrawAccountHolder, setWithdrawAccountHolder] = useState<string>('');
  const [withdrawNote, setWithdrawNote] = useState<string>('');
  const [isSubmittingWithdraw, setIsSubmittingWithdraw] = useState<boolean>(false);
  const [withdrawFeedback, setWithdrawFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const fetchWalletData = async () => {
    try {
      const token = localStorage.getItem('pixel_token');
      if (!token) return;
      const res = await fetch('/api/wallet', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setPaymentMethods(data.paymentMethods || []);
        setLedger(data.ledger || []);
        setDeposits(data.deposits || []);
        setWithdrawals(data.withdrawals || []);
      }
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    if (isWalletModalOpen) {
      setActiveTab(walletModalTab);
      fetchWalletData();
    }
  }, [isWalletModalOpen, walletModalTab]);

  if (!isWalletModalOpen) return null;

  const currentMethodDetails = paymentMethods.find((p) => p.provider.toLowerCase() === selectedMethod.toLowerCase()) || {
    accountNumber: '01320765354',
    instructions: 'সেন্ড মানি করুন এবং ট্রানজেকশন আইডি দিন।'
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedNumber(true);
    setTimeout(() => setCopiedNumber(false), 2000);
  };

  const handleDepositSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmittingDeposit(true);
    setDepositFeedback(null);

    try {
      const token = localStorage.getItem('pixel_token');
      const res = await fetch('/api/wallet/deposit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          amount: Number(depositAmount),
          paymentMethod: selectedMethod,
          trxId,
          senderNumber,
          screenshot
        })
      });

      const data = await res.json();
      if (res.ok) {
        confetti({ particleCount: 40, spread: 60, origin: { y: 0.7 } });
        setDepositFeedback({
          type: 'success',
          text: 'ডিপোজিট রিকোয়েস্ট সফলভাবে জমা হয়েছে! অ্যাডমিন যাচাই করে খুব দ্রুত অনুমোদন করবেন।'
        });
        setTrxId('');
        setSenderNumber('');
        setScreenshot('');
        await fetchWalletData();
        await refreshUser();
      } else {
        setDepositFeedback({ type: 'error', text: data.error || 'ডিপোজিট করতে ব্যর্থ হয়েছে।' });
      }
    } catch (err: any) {
      setDepositFeedback({ type: 'error', text: err.message || 'Network error' });
    } finally {
      setIsSubmittingDeposit(false);
    }
  };

  const handleWithdrawSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const amount = Number(withdrawAmount);
    if (amount < 200) {
      setWithdrawFeedback({ type: 'error', text: 'সর্বনিম্ন উত্তোলনের পরিমাণ ২০০ টাকা।' });
      return;
    }
    if (amount > 1000) {
      setWithdrawFeedback({ type: 'error', text: 'একবারে সর্বোচ্চ ১০০০ টাকা উত্তোলন করা সম্ভব।' });
      return;
    }
    if (wallet.availableBalance < amount) {
      setWithdrawFeedback({ type: 'error', text: 'আপনার ওয়ালেটে পর্যাপ্ত ব্যালেন্স নেই।' });
      return;
    }

    setIsSubmittingWithdraw(true);
    setWithdrawFeedback(null);

    try {
      const token = localStorage.getItem('pixel_token');
      const res = await fetch('/api/wallet/withdraw', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          amount,
          paymentMethod: withdrawMethod,
          accountNumber: withdrawAccountNumber,
          accountHolder: withdrawAccountHolder,
          note: withdrawNote
        })
      });

      const data = await res.json();
      if (res.ok) {
        setWithdrawFeedback({
          type: 'success',
          text: 'উত্তোলনের আবেদন জমা হয়েছে! ২৪ ঘণ্টার মধ্যে বিকাশ অ্যাকাউন্টে টাকা পৌঁছে যাবে।'
        });
        setWithdrawAccountNumber('');
        setWithdrawNote('');
        await fetchWalletData();
        await refreshUser();
      } else {
        setWithdrawFeedback({ type: 'error', text: data.error || 'উত্তোলন ব্যর্থ হয়েছে।' });
      }
    } catch (err: any) {
      setWithdrawFeedback({ type: 'error', text: err.message || 'Network error' });
    } finally {
      setIsSubmittingWithdraw(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/40 backdrop-blur-sm animate-fade-in">
      <div className="bg-white border border-slate-200 w-full max-w-3xl rounded-2xl p-5 sm:p-7 max-h-[92vh] overflow-y-auto shadow-2xl relative">
        {/* Close Button */}
        <button
          onClick={closeWalletModal}
          className="absolute top-5 right-5 text-slate-400 hover:text-slate-600 transition-colors cursor-pointer p-1"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
            <WalletIcon className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xl font-extrabold text-slate-900 font-display">
              {t.walletTitle}
            </h3>
            <span className="text-xs text-slate-400">
              Manual Mobile Financial System · Currency: <strong className="text-emerald-400">BDT (৳)</strong>
            </span>
          </div>
        </div>

        {/* 4 KPI Balances Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
          <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200">
            <span className="text-[11px] text-emerald-600 block mb-0.5">{t.availableBalance}</span>
            <span className="text-xl font-extrabold text-slate-900 font-mono tabular-nums">
              ৳{wallet.availableBalance}
            </span>
          </div>

          <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200">
            <span className="text-[11px] text-amber-600 block mb-0.5">{t.pendingBalance}</span>
            <span className="text-xl font-extrabold text-amber-700 font-mono tabular-nums">
              ৳{wallet.pendingBalance}
            </span>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
            <span className="text-[11px] text-slate-500 block mb-0.5">{t.heldBalance}</span>
            <span className="text-xl font-extrabold text-slate-700 font-mono tabular-nums">
              ৳{wallet.heldBalance}
            </span>
          </div>

          <div className="p-3.5 rounded-xl bg-teal-50 border border-teal-200">
            <span className="text-[11px] text-teal-600 block mb-0.5">{t.totalEarned}</span>
            <span className="text-xl font-extrabold text-teal-700 font-mono tabular-nums">
              ৳{wallet.totalEarned}
            </span>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 p-1 bg-slate-100 rounded-xl border border-slate-200 mb-6">
          <button
            onClick={() => setActiveTab('deposit')}
            className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'deposit'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            <ArrowDownLeft className="w-3.5 h-3.5" />
            <span>{t.tabDeposit}</span>
          </button>

          <button
            onClick={() => setActiveTab('withdraw')}
            className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'withdraw'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            <ArrowUpRight className="w-3.5 h-3.5" />
            <span>{t.tabWithdraw}</span>
          </button>

          <button
            onClick={() => setActiveTab('ledger')}
            className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'ledger'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            <span>{t.tabLedger}</span>
          </button>
        </div>

        {/* TAB 1: DEPOSIT */}
        {activeTab === 'deposit' && (
          <div className="space-y-5">
            {/* Payment Method Selector */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-2">
                পেমেন্ট মেথড বেছে নিন:
              </label>
              <div className="grid grid-cols-1 gap-3">
                {['bKash'].map((pm) => (
                  <button
                    key={pm}
                    type="button"
                    onClick={() => setSelectedMethod(pm)}
                    className={`py-3 px-3 rounded-xl border text-center transition-all cursor-pointer ${
                      selectedMethod === pm
                        ? 'border-emerald-500 bg-emerald-50 text-emerald-600 font-bold shadow-sm'
                        : 'border-slate-200 bg-slate-50/60 text-slate-500 hover:text-slate-700'
                    }`}
                  >
                    <div className="text-sm font-bold">{pm}</div>
                    <div className="text-[10px] text-slate-400 mt-0.5">ম্যানুয়াল সেন্ড মানি (বিকাশ)</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Official Number Instructions Box */}
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400">
                  {selectedMethod} নম্বর (Send Money):
                </span>
                <span className="text-[11px] text-emerald-600 font-semibold flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" /> Official Verified
                </span>
              </div>

              <div className="flex items-center justify-between p-3 rounded-lg bg-white border border-slate-200">
                <span className="text-lg font-mono font-bold text-slate-900 tracking-wider">
                  {currentMethodDetails.accountNumber}
                </span>
                <button
                  type="button"
                  onClick={() => copyToClipboard(currentMethodDetails.accountNumber)}
                  className="px-3 py-1.5 rounded-md bg-emerald-100 hover:bg-emerald-200 text-emerald-700 text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors"
                >
                  {copiedNumber ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedNumber ? 'কপি হয়েছে' : 'কপি করুন'}</span>
                </button>
              </div>

              <p className="text-xs text-slate-400 leading-relaxed pt-1">
                {currentMethodDetails.instructions}
              </p>
            </div>

            {/* Deposit Submit Form */}
            <form onSubmit={handleDepositSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    {t.amountLabel}:
                  </label>
                  <input
                    type="number"
                    required
                    min={50}
                    value={depositAmount}
                    onChange={(e) => setDepositAmount(e.target.value)}
                    className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm text-slate-900 font-mono focus:outline-none focus:border-emerald-500"
                  />
                  <div className="flex flex-wrap gap-2 mt-2">
                    {[10, 50, 100, 200, 500, 1000, 2500].map((amt) => (
                      <button
                        key={amt}
                        type="button"
                        onClick={() => setDepositAmount(amt.toString())}
                        className="px-2 py-1 rounded bg-slate-100 hover:bg-slate-200 text-[11px] font-mono text-slate-600 cursor-pointer"
                      >
                        ৳{amt}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    {t.trxIdLabel}:
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="যেমন: BKASH9X8472"
                    value={trxId}
                    onChange={(e) => setTrxId(e.target.value)}
                    className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm text-slate-900 font-mono uppercase focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    {t.senderPhoneLabel}:
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="01XXXXXXXXX"
                    value={senderNumber}
                    onChange={(e) => setSenderNumber(e.target.value)}
                    className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm text-slate-900 font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    পেমেন্ট স্ক্রিনশট (ঐচ্ছিক):
                  </label>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        const r = new FileReader();
                        r.onloadend = () => setScreenshot(r.result as string);
                        r.readAsDataURL(file);
                      }
                    }}
                    className="w-full text-xs text-slate-500 file:mr-2 file:py-2 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-slate-100 file:text-slate-700"
                  />
                </div>
              </div>

              {depositFeedback && (
                <div
                  className={`p-3 rounded-xl text-xs font-medium ${
                    depositFeedback.type === 'success'
                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                      : 'bg-rose-50 text-rose-700 border border-rose-200'
                  }`}
                >
                  {depositFeedback.text}
                </div>
              )}

              <button
                type="submit"
                disabled={isSubmittingDeposit}
                className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-lg shadow-emerald-600/20 transition-all cursor-pointer disabled:opacity-50"
              >
                {isSubmittingDeposit ? 'জমা হচ্ছে...' : t.btnSubmitDeposit}
              </button>
            </form>
          </div>
        )}

        {/* TAB 2: WITHDRAW */}
        {activeTab === 'withdraw' && (
          <form onSubmit={handleWithdrawSubmit} className="space-y-4">
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600 flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <p>সর্বনিম্ন উত্তোলনের পরিমাণ ২০০ টাকা এবং সর্বোচ্চ ১০০০ টাকা।</p>
                <p className="text-[10px] text-slate-400">প্রতিদিন একবার উত্তোলন রিকোয়েস্ট দিতে পারবেন।</p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  উত্তোলনের পরিমাণ (BDT ৳):
                </label>
                <input
                  type="number"
                  required
                  min={200}
                  max={1000}
                  value={withdrawAmount}
                  onChange={(e) => setWithdrawAmount(e.target.value)}
                  className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm text-slate-900 font-mono focus:outline-none focus:border-emerald-500"
                />
                <span className="text-[11px] text-slate-400 mt-1 block">
                  উত্তোলন সীমা: <strong className="text-emerald-600 font-mono">৳২০০ - ৳১০০০</strong>
                </span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  পেমেন্ট মেথড:
                </label>
                <select
                  value={withdrawMethod}
                  onChange={(e) => setWithdrawMethod(e.target.value)}
                  className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm text-slate-900 focus:outline-none focus:border-emerald-500"
                >
                  <option value="bKash">bKash (বিকাশ)</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  {t.accountNumberLabel}:
                </label>
                <input
                  type="tel"
                  required
                  placeholder="01XXXXXXXXX"
                  value={withdrawAccountNumber}
                  onChange={(e) => setWithdrawAccountNumber(e.target.value)}
                  className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm text-slate-900 font-mono focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  {t.accountHolderLabel}:
                </label>
                <input
                  type="text"
                  placeholder="আপনার নাম"
                  value={withdrawAccountHolder}
                  onChange={(e) => setWithdrawAccountHolder(e.target.value)}
                  className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm text-slate-900 focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            {withdrawFeedback && (
              <div
                className={`p-3 rounded-xl text-xs font-medium ${
                  withdrawFeedback.type === 'success'
                    ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                    : 'bg-rose-50 text-rose-700 border border-rose-200'
                }`}
              >
                {withdrawFeedback.text}
              </div>
            )}

            <button
              type="submit"
              disabled={isSubmittingWithdraw || wallet.availableBalance < 200}
              className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-lg shadow-emerald-600/20 transition-all cursor-pointer disabled:opacity-50"
            >
              {isSubmittingWithdraw ? 'আবেদন পাঠানো হচ্ছে...' : t.btnSubmitWithdraw}
            </button>
          </form>
        )}

        {/* TAB 3: LEDGER */}
        {activeTab === 'ledger' && (
          <div className="space-y-4">
            <h4 className="text-xs uppercase tracking-wider text-slate-400 font-bold mb-2">
              আর্থিক লেজার ট্রানজেকশন হিস্ট্রি (Financial Ledger)
            </h4>

            {ledger.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-500 rounded-xl bg-slate-50 border border-slate-200">
                এখনো কোনো ট্রানজেকশন হয়নি। কাজ সম্পন্ন করে বা ডিপোজিট করে ব্যালেন্স তৈরি করুন।
              </div>
            ) : (
              <div className="space-y-2 overflow-x-auto">
                {ledger.map((item) => {
                  const isPositive = item.amount > 0;
                  return (
                    <div
                      key={item.id}
                      className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs"
                    >
                      <div>
                        <div className="font-semibold text-slate-900">{item.description}</div>
                        <div className="text-[11px] text-slate-400 mt-0.5">
                          {new Date(item.createdAt).toLocaleString('bn-BD')} · ধরণ: {item.type}
                        </div>
                      </div>
                      <div className="text-right">
                        <span
                          className={`font-mono font-bold text-sm ${
                            isPositive ? 'text-emerald-400' : 'text-rose-400'
                          }`}
                        >
                          {isPositive ? `+৳${item.amount}` : `-৳${Math.abs(item.amount)}`}
                        </span>
                        <div className="text-[10px] text-slate-400 font-mono">
                          ব্যালেন্স: ৳{item.balanceAfter}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
