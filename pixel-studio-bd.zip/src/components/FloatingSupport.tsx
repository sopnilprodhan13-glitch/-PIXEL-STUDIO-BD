import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { MessageSquare, PhoneCall, HelpCircle, X } from 'lucide-react';

export const FloatingSupport: React.FC = () => {
  const { openSupportModal } = useAuth();
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end gap-2.5">
      {isOpen && (
        <div className="bg-white border border-slate-200 rounded-2xl p-3 shadow-2xl flex flex-col gap-2 animate-fade-in w-48 mb-1">
          <a
            href="https://wa.me/8801320765354"
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-2.5 p-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-600 text-xs font-bold transition-colors"
          >
            <PhoneCall className="w-4 h-4" />
            <span>WhatsApp Chat</span>
          </a>

          <a
            href="https://t.me/INCOME47776"
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-2.5 p-2 rounded-xl bg-[#229ED9]/5 hover:bg-[#229ED9]/10 text-[#229ED9] text-xs font-bold transition-colors"
          >
            <MessageSquare className="w-4 h-4" />
            <span>Telegram Channel</span>
          </a>

          <button
            onClick={() => {
              setIsOpen(false);
              openSupportModal();
            }}
            className="flex items-center gap-2.5 p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-colors cursor-pointer text-left"
          >
            <HelpCircle className="w-4 h-4 text-amber-500" />
            <span>Help Center & FAQ</span>
          </button>
        </div>
      )}

      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-13 h-13 rounded-full bg-gradient-to-tr from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-bold flex items-center justify-center shadow-xl shadow-emerald-500/30 hover:scale-105 transition-all cursor-pointer"
        title="Live Support (WhatsApp / Telegram)"
      >
        {isOpen ? <X className="w-6 h-6" /> : <MessageSquare className="w-6 h-6" />}
      </button>
    </div>
  );
};
