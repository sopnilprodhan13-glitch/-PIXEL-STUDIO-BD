import React from 'react';
import { useAuth } from '../context/AuthContext';
import { useTranslation } from '../translations';
import {
  MessageSquare,
  PhoneCall,
  ShieldCheck,
  Heart,
  Globe
} from 'lucide-react';

export const Footer: React.FC = () => {
  const { language, toggleLanguage, setActiveView, openSupportModal, openAuthModal, openEmployerReqModal } = useAuth();
  const t = useTranslation(language);

  return (
    <footer className="bg-slate-50 border-t border-slate-200 pt-16 pb-12 text-slate-500 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 mb-12">
          {/* Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <img
                src="/assets/aistudio/WhatsApp_Image_2026-11-06_at_11.02.12_AM_4c49fd8b.jpeg"
                alt="PIXEL STUDIO BD"
                className="w-10 h-10 rounded-full border border-emerald-500 shadow-sm"
              />
              <span className="text-lg font-bold text-slate-900 font-display">
                PIXEL STUDIO <span className="text-emerald-600">BD</span>
              </span>
            </div>

            <p className="text-slate-500 text-xs leading-relaxed max-w-sm">
              বাংলাদেশের অন্যতম নির্ভরযোগ্য মাল্টি-ভেন্ডর ফ্রিল্যান্সিং, মাইক্রো-জব ও ডিজিটাল ক্রিয়েটিভ সার্ভিসেস প্ল্যাটফর্ম। ১০০% নিরাপদ ম্যানুয়াল পেমেন্ট ভেরিফিকেশন।
            </p>

            {/* Support Quick Contacts */}
            <div className="flex flex-wrap items-center gap-3 pt-1">
              <a
                href="https://t.me/INCOME47776"
                target="_blank"
                rel="noreferrer"
                className="px-3 py-1.5 rounded-lg bg-[#229ED9]/10 border border-[#229ED9]/20 text-[#229ED9] hover:bg-[#229ED9]/20 text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Telegram Support</span>
              </a>

              <a
                href="https://wa.me/8801320765354"
                target="_blank"
                rel="noreferrer"
                className="px-3 py-1.5 rounded-lg bg-emerald-50 border border-emerald-100 text-emerald-700 hover:bg-emerald-100 text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <PhoneCall className="w-3.5 h-3.5" />
                <span>WhatsApp: 01320765354</span>
              </a>
            </div>
          </div>

          {/* Column 1: Marketplace */}
          <div>
            <h4 className="text-xs uppercase font-bold text-slate-900 tracking-wider mb-3">
              মার্কেটপ্লেস
            </h4>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => setActiveView('jobs')}
                  className="hover:text-emerald-600 transition-colors cursor-pointer text-slate-600"
                >
                  {t.navFindJobs}
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveView('freelancing')}
                  className="hover:text-emerald-600 transition-colors cursor-pointer text-slate-600"
                >
                  {t.navFreelancing}
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveView('services')}
                  className="hover:text-emerald-600 transition-colors cursor-pointer text-slate-600"
                >
                  {t.navServices}
                </button>
              </li>
              <li>
                <button
                  onClick={openEmployerReqModal}
                  className="hover:text-emerald-600 transition-colors cursor-pointer text-slate-600"
                >
                  {t.navBecomeEmployer}
                </button>
              </li>
            </ul>
          </div>

          {/* Column 2: Help & Resources */}
          <div>
            <h4 className="text-xs uppercase font-bold text-slate-900 tracking-wider mb-3">
              সহায়তা ও রিসোর্স
            </h4>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => setActiveView('tutorials')}
                  className="hover:text-emerald-600 transition-colors cursor-pointer text-slate-600"
                >
                  {t.navTutorials}
                </button>
              </li>
              <li>
                <button
                  onClick={openSupportModal}
                  className="hover:text-emerald-600 transition-colors cursor-pointer text-slate-600"
                >
                  কাস্টমার সাপোর্ট ও হেল্প ডেস্ক
                </button>
              </li>
              <li>
                <button
                  onClick={() => openAuthModal('login')}
                  className="hover:text-slate-900 transition-colors cursor-pointer text-slate-600"
                >
                  ইউজার লগইন পোর্টাল
                </button>
              </li>
              <li>
                <button
                  onClick={toggleLanguage}
                  className="hover:text-emerald-600 transition-colors cursor-pointer flex items-center gap-1 text-slate-600"
                >
                  <Globe className="w-3 h-3 text-emerald-600" />
                  <span>ভাষা পরিবর্তন ({language === 'bn' ? 'English' : 'বাংলা'})</span>
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Legal & Security */}
          <div>
            <h4 className="text-xs uppercase font-bold text-slate-900 tracking-wider mb-3">
              পলিসি ও নিরাপত্তা
            </h4>
            <ul className="space-y-2 text-slate-600">
              <li>
                <span className="hover:text-slate-900 cursor-pointer">Terms & Conditions</span>
              </li>
              <li>
                <span className="hover:text-slate-900 cursor-pointer">Privacy & Data Policy</span>
              </li>
              <li>
                <span className="hover:text-slate-900 cursor-pointer">Deposit & Withdrawal Policy</span>
              </li>
              <li>
                <span className="hover:text-slate-900 cursor-pointer">Anti-Fraud & Guarantee</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4 text-slate-400 text-[11px]">
          <div className="text-center sm:text-left">
            <p className="font-bold text-slate-900 mb-1">© {new Date().getFullYear()} PIXEL STUDIO BD. All Rights Reserved.</p>
            <p>আমাদের ওয়েবসাইট ব্যবহারের মাধ্যমে আপনি আমাদের সকল পলিসি ও শর্তাবলীতে সম্মতি প্রদান করছেন।</p>
          </div>

          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1 text-emerald-600 font-bold">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>100% Genuine Task Guarantee</span>
            </span>
            <span>·</span>
            <span className="text-slate-400 font-medium">Currency: BDT (৳)</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
