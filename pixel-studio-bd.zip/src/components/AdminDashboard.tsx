import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTranslation } from '../translations';
import {
  Users,
  Briefcase,
  CheckCircle2,
  XCircle,
  Clock,
  ArrowDownLeft,
  ArrowUpRight,
  TrendingUp,
  ShieldCheck,
  ShoppingBag,
  Tv,
  Film,
  Plus,
  Trash2,
  ExternalLink,
  Lock,
  Search,
  AlertCircle,
  Copy
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const { user, language, openPostJobModal } = useAuth();
  const t = useTranslation(language);

  const [activeTab, setActiveTab] = useState<
    | 'overview'
    | 'employers'
    | 'jobs'
    | 'submissions'
    | 'deposits'
    | 'withdrawals'
    | 'orders'
    | 'adsterra'
    | 'tutorials'
    | 'security'
  >('overview');

  const [analytics, setAnalytics] = useState<any>(null);
  const [jobs, setJobs] = useState<any[]>([]);
  const [submissions, setSubmissions] = useState<any[]>([]);
  const [deposits, setDeposits] = useState<any[]>([]);
  const [withdrawals, setWithdrawals] = useState<any[]>([]);
  const [employerRequests, setEmployerRequests] = useState<any[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [tutorials, setTutorials] = useState<any[]>([]);
  const [adsterraConfig, setAdsterraConfig] = useState<any>({
    enabled: false,
    publisherId: '',
    slots: {
      underHero: { enabled: false, code: '' },
      middle: { enabled: false, code: '' },
      footer: { enabled: false, code: '' },
      tutorial: { enabled: false, code: '' }
    }
  });

  // Admin quick employer email approval
  const [quickEmail, setQuickEmail] = useState('');
  const [quickEmailMessage, setQuickEmailMessage] = useState<string | null>(null);

  // New Tutorial Form
  const [tutTitle, setTutTitle] = useState('');
  const [tutTitleBn, setTutTitleBn] = useState('');
  const [tutUrl, setTutUrl] = useState('');
  const [tutCategory, setTutCategory] = useState('How to Register');
  const [tutDesc, setTutDesc] = useState('');

  // Password Change
  const [newPassword, setNewPassword] = useState('');
  const [passwordMessage, setPasswordMessage] = useState<string | null>(null);

  const token = localStorage.getItem('pixel_token');

  const fetchAdminData = async () => {
    try {
      const headers = { Authorization: `Bearer ${token}` };

      // Analytics
      const resAna = await fetch('/api/admin/analytics', { headers });
      if (resAna.ok) {
        const data = await resAna.json();
        setAnalytics(data);
        setDeposits(data.depositsList || []);
        setWithdrawals(data.withdrawalsList || []);
        setEmployerRequests(data.employerRequests || []);
      }

      // Jobs
      const resJobs = await fetch('/api/jobs');
      if (resJobs.ok) setJobs(await resJobs.json());

      // Submissions
      const resSubs = await fetch('/api/submissions', { headers });
      if (resSubs.ok) setSubmissions(await resSubs.json());

      // Orders
      const resOrders = await fetch('/api/orders', { headers });
      if (resOrders.ok) setOrders(await resOrders.json());

      // Adsterra
      const resAd = await fetch('/api/settings/adsterra');
      if (resAd.ok) setAdsterraConfig(await resAd.json());

      // Tutorials
      const resTut = await fetch('/api/tutorials');
      if (resTut.ok) setTutorials(await resTut.json());
    } catch (e) {
      console.error('Error fetching admin data:', e);
    }
  };

  useEffect(() => {
    fetchAdminData();
  }, []);

  // Action: Employer Approval
  const handleEmployerAction = async (id: string, action: 'approve' | 'reject' | 'suspend') => {
    try {
      const res = await fetch(`/api/admin/employer-requests/${id}/action`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ action })
      });
      if (res.ok) {
        await fetchAdminData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Action: Quick Approve Employer by Email
  const handleQuickApproveEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickEmail) return;
    try {
      const res = await fetch('/api/admin/employer/approve-by-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ email: quickEmail })
      });
      const data = await res.json();
      if (res.ok) {
        setQuickEmailMessage(data.message || 'Employer access granted!');
        setQuickEmail('');
        await fetchAdminData();
      } else {
        setQuickEmailMessage(data.error || 'Failed to approve');
      }
    } catch (e: any) {
      setQuickEmailMessage(e.message || 'Error');
    }
  };

  // Action: Review Submission (Approve / Reject)
  const handleReviewSubmission = async (id: string, action: 'approve' | 'reject') => {
    try {
      const res = await fetch(`/api/submissions/${id}/review`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ action, feedback: action === 'approve' ? 'Approved by Admin' : 'Rejected' })
      });
      if (res.ok) {
        await fetchAdminData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Action: Approve Deposit
  const handleApproveDeposit = async (id: string) => {
    try {
      const res = await fetch(`/api/admin/deposits/${id}/approve`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        await fetchAdminData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Action: Reject Deposit
  const handleRejectDeposit = async (id: string) => {
    const reason = prompt('Reject reason (বিকাশ বা নগদ নম্বর ভুল বা টাকা আসেনি):');
    if (!reason) return;
    try {
      const res = await fetch(`/api/admin/deposits/${id}/reject`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ reason })
      });
      if (res.ok) {
        await fetchAdminData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Action: Pay Withdrawal
  const handlePayWithdrawal = async (id: string) => {
    try {
      const res = await fetch(`/api/admin/withdrawals/${id}/pay`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        await fetchAdminData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Action: Reject Withdrawal
  const handleRejectWithdrawal = async (id: string) => {
    const reason = prompt('Rejection reason (ভুল মোবাইল নম্বর ইত্যাদি):');
    if (!reason) return;
    try {
      const res = await fetch(`/api/admin/withdrawals/${id}/reject`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ reason })
      });
      if (res.ok) {
        await fetchAdminData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Action: Save Adsterra
  const handleSaveAdsterra = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/settings/adsterra', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify(adsterraConfig)
      });
      if (res.ok) {
        alert('Adsterra configuration saved successfully!');
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Action: Add Tutorial
  const handleAddTutorial = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/tutorials', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({
          title: tutTitle,
          titleBn: tutTitleBn || tutTitle,
          youtubeUrl: tutUrl,
          category: tutCategory,
          description: tutDesc
        })
      });
      if (res.ok) {
        setTutTitle('');
        setTutTitleBn('');
        setTutUrl('');
        setTutDesc('');
        await fetchAdminData();
        alert('Tutorial added successfully!');
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Action: Change Admin Password
  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPassword || newPassword.length < 6) {
      setPasswordMessage('Password must be at least 6 characters.');
      return;
    }
    try {
      const res = await fetch('/api/auth/profile', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ newPassword })
      });
      const data = await res.json();
      if (res.ok) {
        setPasswordMessage('Admin password updated successfully!');
        setNewPassword('');
      } else {
        setPasswordMessage(data.error || 'Failed to update');
      }
    } catch (e: any) {
      setPasswordMessage(e.message || 'Error');
    }
  };

  return (
    <div className="py-8 max-w-7xl mx-auto px-4 sm:px-6">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-200 mb-8">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-amber-600 mb-1">
            <ShieldCheck className="w-4 h-4" />
            <span>SUPER ADMIN CONTROL CENTER</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display">
            {t.adminDashboardTitle}
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Logged in as: <strong className="text-emerald-600 font-mono">{user?.email}</strong>
          </p>
        </div>

        <button
          onClick={openPostJobModal}
          className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md shadow-emerald-600/20 transition-all flex items-center gap-2 cursor-pointer self-start md:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>নতুন জব পোস্ট করুন</span>
        </button>
      </div>

      {/* Admin Horizontal Tabs */}
      <div className="flex flex-wrap items-center gap-2 mb-8 pb-3 border-b border-slate-200">
        {[
          { key: 'overview', label: t.tabOverview, icon: TrendingUp },
          { key: 'employers', label: t.tabEmployerApproval, icon: Briefcase, badge: analytics?.pendingEmployerRequests },
          { key: 'submissions', label: t.tabSubmissions, icon: CheckCircle2, badge: analytics?.pendingSubmissions },
          { key: 'deposits', label: t.tabDeposits, icon: ArrowDownLeft, badge: analytics?.pendingDeposits },
          { key: 'withdrawals', label: t.tabWithdrawals, icon: ArrowUpRight, badge: analytics?.pendingWithdrawals },
          { key: 'jobs', label: t.tabManageJobs, icon: Briefcase },
          { key: 'orders', label: t.tabServicesOrders, icon: ShoppingBag, badge: analytics?.pendingOrders },
          { key: 'adsterra', label: t.tabAdsterra, icon: Tv },
          { key: 'tutorials', label: t.tabTutorials, icon: Film },
          { key: 'security', label: t.tabSettings, icon: Lock }
        ].map((tabItem) => {
          const Icon = tabItem.icon;
          const isActive = activeTab === tabItem.key;
          return (
            <button
              key={tabItem.key}
              onClick={() => setActiveTab(tabItem.key as any)}
              className={`px-3 sm:px-4 py-2 rounded-xl text-[10px] sm:text-xs font-bold transition-all flex items-center gap-1.5 sm:gap-2 cursor-pointer whitespace-nowrap ${
                isActive
                  ? 'bg-amber-500 text-white shadow-md font-extrabold'
                  : 'bg-slate-100 text-slate-600 hover:text-slate-900 border border-slate-200'
              }`}
            >
              <Icon className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
              <span>{tabItem.label}</span>
              {Boolean(tabItem.badge) && (
                <span className="px-1.5 py-0.5 rounded-full text-[9px] sm:text-[10px] bg-rose-500 text-white font-mono">
                  {tabItem.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* 1. OVERVIEW & ANALYTICS */}
      {activeTab === 'overview' && analytics && (
        <div className="space-y-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-sm">
              <span className="text-[10px] sm:text-xs text-slate-500 block mb-1">মোট ইউজার</span>
              <span className="text-xl sm:text-2xl font-extrabold text-slate-900 font-mono tabular-nums">
                {analytics.totalUsers}
              </span>
              <div className="text-[9px] sm:text-[11px] text-slate-400 mt-1">
                {analytics.totalFreelancers} Freelancers · {analytics.totalEmployers} Employers
              </div>
            </div>

            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200">
              <span className="text-[10px] sm:text-xs text-emerald-600 block mb-1">মোট অ্যাপ্রুভড ডিপোজিট</span>
              <span className="text-xl sm:text-2xl font-extrabold text-emerald-700 font-mono tabular-nums">
                ৳{analytics.totalDeposited}
              </span>
              <div className="text-[9px] sm:text-[11px] text-amber-600 mt-1">
                {analytics.pendingDeposits} টি পেন্ডিং ডিপোজিট
              </div>
            </div>

            <div className="p-4 rounded-xl bg-violet-50 border border-violet-200">
              <span className="text-[10px] sm:text-xs text-violet-600 block mb-1">মোট পেইড উত্তোলন</span>
              <span className="text-xl sm:text-2xl font-extrabold text-violet-700 font-mono tabular-nums">
                ৳{analytics.totalWithdrawn}
              </span>
              <div className="text-[9px] sm:text-[11px] text-amber-600 mt-1">
                {analytics.pendingWithdrawals} টি পেন্ডিং উত্তোলন
              </div>
            </div>

            <div className="p-4 rounded-xl bg-amber-50 border border-amber-200">
              <span className="text-[10px] sm:text-xs text-amber-600 block mb-1">সক্রিয় জব ও কাজ</span>
              <span className="text-xl sm:text-2xl font-extrabold text-amber-700 font-mono tabular-nums">
                {analytics.activeJobs}
              </span>
              <div className="text-[9px] sm:text-[11px] text-slate-500 mt-1">
                {analytics.pendingSubmissions} টি নতুন প্রুফ রিভিউ বাকি
              </div>
            </div>
          </div>

          {/* Quick Notice Banner */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>
                সুপার অ্যাডমিন সিকিউরিটি নিশ্চিত: প্রতিটি ফাইন্যান্সিয়াল অ্যাকশন সরাসরি সিস্টেম লেজারে রেকর্ড করা হচ্ছে।
              </span>
            </div>
            <span className="text-slate-500 font-mono">Bilingual Engine Active</span>
          </div>
        </div>
      )}

      {/* 2. EMPLOYER APPROVALS */}
      {activeTab === 'employers' && (
        <div className="space-y-6">
          {/* Quick email approval */}
          <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm">
            <h3 className="text-sm font-bold text-slate-900 mb-2">
              সরাসরি ইমেইল দিয়ে এমপ্লয়ার অনুমোদন (Instant Approval by Email):
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              ব্যবহারকারী হোয়াটসঅ্যাপ বা টেলিগ্রামে ইমেইল পাঠালে এখানে লিখে সরাসরি অনুমোদন দিন।
            </p>
            <form onSubmit={handleQuickApproveEmail} className="flex gap-3 max-w-xl">
              <input
                type="email"
                required
                placeholder="user@example.com"
                value={quickEmail}
                onChange={(e) => setQuickEmail(e.target.value)}
                className="flex-1 px-4 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-emerald-500"
              />
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs cursor-pointer whitespace-nowrap"
              >
                এমপ্লয়ার বানান
              </button>
            </form>
            {quickEmailMessage && (
              <div className="text-xs font-semibold text-emerald-600 mt-2">
                {quickEmailMessage}
              </div>
            )}
          </div>

          {/* Request List */}
          <div className="space-y-3">
            <h3 className="text-xs uppercase font-bold text-slate-500 tracking-wider">
              জমা হওয়া এমপ্লয়ার রিকোয়েস্ট তালিকা ({employerRequests.length})
            </h3>
            {employerRequests.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-500 rounded-xl bg-white border border-slate-200 shadow-sm">
                কোনো পেন্ডিং এমপ্লয়ার রিকোয়েস্ট নেই।
              </div>
            ) : (
              employerRequests.map((req) => (
                <div
                  key={req.id}
                  className="p-4 rounded-xl bg-white border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4"
                >
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-bold text-slate-900 text-sm">{req.userName}</span>
                      <span className="text-xs text-emerald-600 font-mono">({req.userEmail})</span>
                      <span className="text-xs text-slate-500">· {req.mobileNumber}</span>
                    </div>
                    {req.companyName && (
                      <div className="text-xs text-indigo-400 font-semibold mb-1">
                        প্রতিষ্ঠান: {req.companyName}
                      </div>
                    )}
                    <p className="text-xs text-slate-600 leading-relaxed max-w-2xl">
                      &quot;{req.reason}&quot;
                    </p>
                    <div className="text-[10px] text-slate-500 mt-1">
                      জমা: {new Date(req.requestedAt).toLocaleString('bn-BD')} · স্ট্যাটাস: <strong className="text-amber-600">{req.status}</strong>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    {req.status === 'pending' ? (
                      <>
                        <button
                          onClick={() => handleEmployerAction(req.id, 'approve')}
                          className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs cursor-pointer shadow-sm"
                        >
                          Approve
                        </button>
                        <button
                          onClick={() => handleEmployerAction(req.id, 'reject')}
                          className="px-3 py-1.5 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 text-xs font-bold cursor-pointer"
                        >
                          Reject
                        </button>
                      </>
                    ) : (
                      <span className="text-xs font-bold text-emerald-600 capitalize px-3 py-1 bg-emerald-50 border border-emerald-200 rounded-md">
                        {req.status}
                      </span>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* 3. WORK SUBMISSIONS REVIEW */}
      {activeTab === 'submissions' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs uppercase font-bold text-slate-500 tracking-wider">
              ফ্রিল্যান্সারদের জমা দেওয়া কাজের প্রুফ ({submissions.length})
            </h3>
            <span className="text-xs text-emerald-600 font-semibold">অনুমোদন করলেই সরাসরি ওয়ালেটে টাকা জমা হবে</span>
          </div>

          {submissions.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-500 rounded-xl bg-white border border-slate-200 shadow-sm">
              কোনো কাজের প্রুফ জমা নেই।
            </div>
          ) : (
            submissions.map((sub) => (
              <div
                key={sub.id}
                className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div className="max-w-2xl">
                  <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
                    <span className="text-slate-900 font-bold">{sub.jobTitle}</span>
                    <span aria-hidden="true">·</span>
                    <span className="text-emerald-600 font-mono font-bold">পুরস্কার: ৳{sub.rewardAmount}</span>
                  </div>

                  <div className="text-xs text-slate-600 mb-2">
                    ফ্রিল্যান্সার: <strong className="text-slate-900">{sub.freelancerName}</strong> ({sub.freelancerEmail})
                  </div>

                  {sub.proofText && (
                    <p className="text-xs text-slate-600 bg-slate-50 p-3 rounded-lg border border-slate-200 mb-2 whitespace-pre-line">
                      {sub.proofText}
                    </p>
                  )}

                  <div className="flex flex-wrap items-center gap-3">
                    {sub.proofUrl && (
                      <a
                        href={sub.proofUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="text-xs text-emerald-400 hover:underline flex items-center gap-1 font-mono"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        <span>প্রুফ লিংক ওপেন করুন</span>
                      </a>
                    )}
                    {sub.screenshot && (
                      <a
                        href={sub.screenshot}
                        target="_blank"
                        rel="noreferrer"
                        className="text-xs text-teal-400 hover:underline flex items-center gap-1"
                      >
                        <Film className="w-3.5 h-3.5" />
                        <span>স্ক্রিনশট দেখুন</span>
                      </a>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {sub.status === 'pending' ? (
                    <>
                      <button
                        onClick={() => handleReviewSubmission(sub.id, 'approve')}
                        className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs cursor-pointer shadow-md shadow-emerald-600/10"
                      >
                        অনুমোদন (৳{sub.rewardAmount} দিন)
                      </button>
                      <button
                        onClick={() => handleReviewSubmission(sub.id, 'reject')}
                        className="px-3.5 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 font-bold text-xs cursor-pointer border border-rose-200"
                      >
                        বাতিল
                      </button>
                    </>
                  ) : (
                    <span
                      className={`text-xs font-bold px-3 py-1 rounded-md ${
                        sub.status === 'approved'
                          ? 'bg-emerald-50 text-emerald-600 border border-emerald-200'
                          : 'bg-rose-50 text-rose-600 border border-rose-200'
                      }`}
                    >
                      {sub.status.toUpperCase()}
                    </span>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* 4. DEPOSITS VERIFICATION */}
      {activeTab === 'deposits' && (
        <div className="space-y-4">
          <h3 className="text-xs uppercase font-bold text-slate-500 tracking-wider">
            বিকাশ ও নগদ ডিপোজিট রিকোয়েস্ট তালিকা ({deposits.length})
          </h3>

          {deposits.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-500 rounded-xl bg-white border border-slate-200 shadow-sm">
              কোনো ডিপোজিট রিকোয়েস্ট নেই।
            </div>
          ) : (
            deposits.map((dep) => (
              <div
                key={dep.id}
                className="p-4 rounded-xl bg-white border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-sm font-bold text-slate-900">{dep.userName}</span>
                    <span className="text-xs text-slate-500">({dep.userEmail})</span>
                    <span className="text-xs px-2 py-0.5 rounded bg-emerald-100 text-emerald-700 font-bold border border-emerald-200">
                      {dep.paymentMethod}
                    </span>
                  </div>

                  <div className="flex items-center gap-4 text-xs font-mono text-slate-600 my-1">
                    <span>পরিমাণ: <strong className="text-emerald-600 text-sm">৳{dep.amount}</strong></span>
                    <span>TrxID: <strong className="text-amber-600 font-bold">{dep.trxId}</strong></span>
                    <span>প্রেরকের নম্বর: <strong className="text-slate-900">{dep.senderNumber}</strong></span>
                  </div>

                  <div className="text-[10px] text-slate-500">
                    তারিখ: {new Date(dep.createdAt).toLocaleString('bn-BD')} · স্ট্যাটাস: <strong className="text-amber-400">{dep.status}</strong>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {dep.status === 'pending' ? (
                    <>
                      <button
                        onClick={() => handleApproveDeposit(dep.id)}
                        className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs cursor-pointer shadow-md shadow-emerald-600/10"
                      >
                        Approve (৳{dep.amount})
                      </button>
                      <button
                        onClick={() => handleRejectDeposit(dep.id)}
                        className="px-3 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 font-bold text-xs cursor-pointer border border-rose-200"
                      >
                        Reject
                      </button>
                    </>
                  ) : (
                    <span
                      className={`text-xs font-bold px-3 py-1 rounded-md ${
                        dep.status === 'approved'
                          ? 'bg-emerald-50 text-emerald-600 border border-emerald-200'
                          : 'bg-rose-50 text-rose-600 border border-rose-200'
                      }`}
                    >
                      {dep.status.toUpperCase()}
                    </span>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* 5. WITHDRAWALS */}
      {activeTab === 'withdrawals' && (
        <div className="space-y-4">
          <h3 className="text-xs uppercase font-bold text-slate-500 tracking-wider">
            উত্তোলন রিকোয়েস্ট তালিকা ({withdrawals.length})
          </h3>

          {withdrawals.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-500 rounded-xl bg-white border border-slate-200 shadow-sm">
              কোনো উত্তোলন রিকোয়েস্ট নেই।
            </div>
          ) : (
            withdrawals.map((wth) => (
              <div
                key={wth.id}
                className="p-4 rounded-xl bg-white border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-sm font-bold text-slate-900">{wth.userName}</span>
                    <span className="text-xs text-slate-500">({wth.userEmail})</span>
                    <span className="text-xs px-2 py-0.5 rounded bg-violet-50 text-violet-600 font-bold border border-violet-200">
                      {wth.paymentMethod}
                    </span>
                  </div>

                  <div className="flex items-center gap-4 text-xs font-mono text-slate-600 my-1">
                    <span>পরিমাণ: <strong className="text-emerald-600 text-sm">৳{wth.amount}</strong></span>
                    <span>নম্বর: <strong className="text-slate-900 font-bold">{wth.accountNumber}</strong></span>
                    <span>নাম: <strong className="text-slate-600">{wth.accountHolder}</strong></span>
                  </div>

                  <div className="text-[10px] text-slate-500">
                    তারিখ: {new Date(wth.createdAt).toLocaleString('bn-BD')} · স্ট্যাটাস: <strong className="text-amber-400">{wth.status}</strong>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {wth.status === 'pending' || wth.status === 'processing' ? (
                    <>
                      <button
                        onClick={() => handlePayWithdrawal(wth.id)}
                        className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs cursor-pointer shadow-md shadow-emerald-600/10"
                      >
                        পেইড মার্ক করুন (Paid)
                      </button>
                      <button
                        onClick={() => handleRejectWithdrawal(wth.id)}
                        className="px-3 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 font-bold text-xs cursor-pointer border border-rose-200"
                      >
                        রিজেক্ট ও রিফান্ড
                      </button>
                    </>
                  ) : (
                    <span
                      className={`text-xs font-bold px-3 py-1 rounded-md ${
                        wth.status === 'paid'
                          ? 'bg-emerald-50 text-emerald-600 border border-emerald-200'
                          : 'bg-rose-50 text-rose-600 border border-rose-200'
                      }`}
                    >
                      {wth.status.toUpperCase()}
                    </span>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* 6. MANAGE JOBS */}
      {activeTab === 'jobs' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs uppercase font-bold text-slate-500 tracking-wider">
              চলতি জব তালিকা ({jobs.length})
            </h3>
            <button
              onClick={openPostJobModal}
              className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white font-bold text-xs shadow-sm"
            >
              + নতুন জব
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {jobs.map((j) => (
              <div key={j.id} className="p-4 rounded-xl bg-white border border-slate-200 shadow-sm space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-emerald-600 font-semibold">{j.category}</span>
                  <span className="text-xs font-mono font-bold text-emerald-600">৳{j.paymentPerWorker}/worker</span>
                </div>
                <h4 className="text-sm font-bold text-slate-900">{j.title}</h4>
                <div className="flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100">
                  <span>স্লট: {j.filledSlots}/{j.totalSlots}</span>
                  <span>স্ট্যাটাস: <strong className="text-emerald-600">{j.status}</strong></span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 7. ADSTERRA AD MANAGER */}
      {activeTab === 'adsterra' && (
        <form onSubmit={handleSaveAdsterra} className="space-y-6 max-w-3xl">
          <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Adsterra Publisher Settings</h3>
                <p className="text-xs text-slate-500">
                  Adsterra ব্যানার ও সোশ্যাল বার কোড এখানে সেট করুন (Google AdSense সম্পূর্ণরূপে নিষিদ্ধ)।
                </p>
              </div>

              <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-slate-700">
                <input
                  type="checkbox"
                  checked={adsterraConfig.enabled}
                  onChange={(e) =>
                    setAdsterraConfig({ ...adsterraConfig, enabled: e.target.checked })
                  }
                  className="w-4 h-4 rounded text-emerald-600"
                />
                <span>Enable Adsterra Ads</span>
              </label>
            </div>

            {/* Slots */}
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  1. Homepage Hero Banner-এর নিচের অ্যাড স্লট কোড:
                </label>
                <textarea
                  rows={2}
                  placeholder="<!-- Adsterra 728x90 HTML/Script Code -->"
                  value={adsterraConfig.slots?.underHero?.code || ''}
                  onChange={(e) =>
                    setAdsterraConfig({
                      ...adsterraConfig,
                      slots: {
                        ...adsterraConfig.slots,
                        underHero: { enabled: true, code: e.target.value }
                      }
                    })
                  }
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  2. Homepage Middle Section স্লট কোড:
                </label>
                <textarea
                  rows={2}
                  placeholder="<!-- Adsterra 300x250 Native Card Code -->"
                  value={adsterraConfig.slots?.middle?.code || ''}
                  onChange={(e) =>
                    setAdsterraConfig({
                      ...adsterraConfig,
                      slots: {
                        ...adsterraConfig.slots,
                        middle: { enabled: true, code: e.target.value }
                      }
                    })
                  }
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  3. Footer-এর আগের সোশ্যাল বার স্লট কোড:
                </label>
                <textarea
                  rows={2}
                  placeholder="<!-- Adsterra Social Bar Code -->"
                  value={adsterraConfig.slots?.footer?.code || ''}
                  onChange={(e) =>
                    setAdsterraConfig({
                      ...adsterraConfig,
                      slots: {
                        ...adsterraConfig.slots,
                        footer: { enabled: true, code: e.target.value }
                      }
                    })
                  }
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 font-mono"
                />
              </div>
            </div>

            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs cursor-pointer shadow-md shadow-emerald-600/10"
            >
              Adsterra সেটিংস সেভ করুন
            </button>
          </div>
        </form>
      )}

      {/* 8. YOUTUBE TUTORIALS */}
      {activeTab === 'tutorials' && (
        <div className="space-y-6 max-w-3xl">
          <form onSubmit={handleAddTutorial} className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
            <h3 className="text-sm font-bold text-slate-900 mb-2">নতুন ইউটিউব টিউটোরিয়াল যোগ করুন</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-slate-700 mb-1">শিরোনাম (English):</label>
                <input
                  type="text"
                  required
                  value={tutTitle}
                  onChange={(e) => setTutTitle(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-900"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-700 mb-1">শিরোনাম (বাংলায়):</label>
                <input
                  type="text"
                  value={tutTitleBn}
                  onChange={(e) => setTutTitleBn(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-900"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-slate-700 mb-1">YouTube URL:</label>
                <input
                  type="url"
                  required
                  placeholder="https://www.youtube.com/watch?v=..."
                  value={tutUrl}
                  onChange={(e) => setTutUrl(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-900"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-700 mb-1">ক্যাটাগরি:</label>
                <select
                  value={tutCategory}
                  onChange={(e) => setTutCategory(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-900"
                >
                  <option value="How to Register">How to Register</option>
                  <option value="How to Find Jobs">How to Find Jobs</option>
                  <option value="How to Deposit">How to Deposit</option>
                  <option value="How to Withdraw">How to Withdraw</option>
                  <option value="How to Post Jobs">How to Post Jobs</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs text-slate-700 mb-1">সংক্ষিপ্ত বিবরণ:</label>
              <textarea
                rows={2}
                value={tutDesc}
                onChange={(e) => setTutDesc(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 resize-none"
              />
            </div>

            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs cursor-pointer shadow-sm"
            >
              টিউটোরিয়াল যোগ করুন
            </button>
          </form>
        </div>
      )}

      {/* 9. SECURITY SETTINGS */}
      {activeTab === 'security' && (
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm max-w-md space-y-4">
          <h3 className="text-sm font-bold text-slate-900">অ্যাডমিন সিকিউরিটি সেটিংস (Change Admin Password)</h3>
          <p className="text-xs text-slate-500">
            প্রাথমিক পাসওয়ার্ড &quot;111111&quot; দুর্বল হওয়ায় পাবলিক লঞ্চের আগে শক্তিশালী পাসওয়ার্ডে পরিবর্তন করুন।
          </p>

          <form onSubmit={handleChangePassword} className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                নতুন পাসওয়ার্ড (New Password):
              </label>
              <input
                type="password"
                required
                minLength={6}
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="কমপক্ষে ৬ ডিজিটের পাসওয়ার্ড"
                className="w-full px-4 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-amber-500"
              />
            </div>

            {passwordMessage && (
              <div className="text-xs font-semibold text-emerald-600">
                {passwordMessage}
              </div>
            )}

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs shadow-md shadow-amber-200/50 transition-all cursor-pointer"
            >
              পাসওয়ার্ড আপডেট করুন
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
