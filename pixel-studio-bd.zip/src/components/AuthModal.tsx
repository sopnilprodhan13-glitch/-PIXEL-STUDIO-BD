import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTranslation } from '../translations';
import {
  X,
  Lock,
  Mail,
  User,
  Phone,
  ShieldCheck,
  ArrowRight,
  Sparkles,
  KeyRound,
  Briefcase
} from 'lucide-react';

export const AuthModal: React.FC = () => {
  const {
    isAuthModalOpen,
    closeAuthModal,
    authModalTab,
    openAuthModal,
    login,
    register,
    adminLogin,
    language
  } = useAuth();
  const t = useTranslation(language);

  const [tab, setTab] = useState<'login' | 'register' | 'admin'>('login');

  // Form states
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [mobile, setMobile] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (authModalTab) {
      setTab(authModalTab);
      setError(null);
      if (authModalTab === 'admin') {
        setEmail('sopnilprodhan13@gmail.com');
        setPassword('111111');
      }
    }
  }, [authModalTab, isAuthModalOpen]);

  if (!isAuthModalOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    let res;
    if (tab === 'login') {
      res = await login(email, password);
    } else if (tab === 'register') {
      res = await register(name, email, mobile, password, 'freelancer');
    } else {
      res = await adminLogin(email, password);
    }

    setIsLoading(false);
    if (!res.success) {
      setError(res.error || 'Authentication failed');
    }
  };

  const handleFillAdmin = () => {
    setTab('admin');
    setEmail('sopnilprodhan13@gmail.com');
    setPassword('111111');
    setError(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-fade-in">
      <div className="bg-white border border-slate-200 w-full max-w-md rounded-2xl p-6 sm:p-7 shadow-2xl relative max-h-[95vh] overflow-y-auto">
        <button
          onClick={closeAuthModal}
          className="absolute top-5 right-5 text-slate-400 hover:text-white transition-colors cursor-pointer p-1"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Brand Header */}
        <div className="flex items-center gap-3 mb-6">
          <img
            src="/assets/aistudio/WhatsApp_Image_2026-11-06_at_11.02.12_AM_4c49fd8b.jpeg"
            alt="Logo"
            className="w-10 h-10 rounded-full border border-emerald-400"
          />
          <div>
            <h3 className="text-lg font-extrabold text-slate-900 font-display">
              PIXEL STUDIO BD
            </h3>
            <span className="text-xs text-slate-400">
              {tab === 'login'
                ? 'একাউন্টে লগইন করুন'
                : tab === 'register'
                ? 'নতুন একাউন্ট তৈরি করুন'
                : 'অ্যাডমিন সিকিউর প্যানেল'}
            </span>
          </div>
        </div>

        {/* Tabs */}
        <div className="grid grid-cols-2 gap-1 p-1 bg-slate-100 rounded-xl border border-slate-200 mb-6 text-xs font-semibold">
          <button
            type="button"
            onClick={() => {
              setTab('login');
              setError(null);
            }}
            className={`py-2 rounded-lg transition-all cursor-pointer ${
              tab === 'login'
                ? 'bg-emerald-600 text-white font-bold shadow-sm'
                : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            {t.navLogin}
          </button>
          <button
            type="button"
            onClick={() => {
              setTab('register');
              setError(null);
            }}
            className={`py-2 rounded-lg transition-all cursor-pointer ${
              tab === 'register'
                ? 'bg-emerald-600 text-white font-bold shadow-sm'
                : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            {t.navRegister}
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {tab === 'register' && (
            <div className="space-y-4">
              {/* Role Selection removed as requested */}


              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-emerald-600" />
                  <span>আপনার পুরো নাম (Full Name):</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="যেমন: তানভীর আহমেদ"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-teal-600" />
                  <span>মোবাইল নম্বর (বিকাশ/নগদ):</span>
                </label>
                <input
                  type="tel"
                  placeholder="01XXXXXXXXX"
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900 font-mono focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5 text-emerald-600" />
              <span>ইমেইল এড্রেস (Email Address):</span>
            </label>
            <input
              type="email"
              required
              placeholder="name@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-emerald-600" />
              <span>পাসওয়ার্ড (Password):</span>
            </label>
            <input
              type="password"
              required
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900 focus:outline-none focus:border-emerald-500"
            />
          </div>

          {error && (
            <div className="p-3 rounded-xl text-xs font-medium bg-rose-50 text-rose-600 border border-rose-100">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3 rounded-xl font-bold text-xs shadow-md transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50 bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-900/10"
          >
            <span>
              {isLoading
                ? 'অপেক্ষা করুন...'
                : tab === 'login'
                ? 'লগইন করুন'
                : 'একাউন্ট তৈরি করুন'}
            </span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>


      </div>
    </div>
  );
};
