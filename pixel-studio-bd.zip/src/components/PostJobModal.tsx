import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTranslation } from '../translations';
import {
  X,
  PlusCircle,
  Coins,
  Users,
  Calendar,
  AlertCircle,
  CheckCircle2
} from 'lucide-react';

export const PostJobModal: React.FC = () => {
  const { isPostJobModalOpen, closePostJobModal, user, wallet, refreshUser, language } = useAuth();
  const t = useTranslation(language);

  const [title, setTitle] = useState<string>('');
  const [titleBn, setTitleBn] = useState<string>('');
  const [category, setCategory] = useState<string>('Thumbnail Design');
  const [jobType, setJobType] = useState<string>('Per Task');
  const [paymentPerWorker, setPaymentPerWorker] = useState<string>('20');
  const [totalSlots, setTotalSlots] = useState<string>('10');
  const [deadline, setDeadline] = useState<string>('2026-12-01');
  const [description, setDescription] = useState<string>('');
  const [requiredProof, setRequiredProof] = useState<string>('Google Drive link and screenshot required.');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  if (!isPostJobModalOpen) return null;

  const payPerWorker = Math.max(1, Number(paymentPerWorker) || 0);
  const slots = Math.max(1, Number(totalSlots) || 0);
  const totalBudget = payPerWorker * slots;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (user?.role !== 'admin' && wallet.availableBalance < totalBudget) {
      setFeedback({
        type: 'error',
        text: `ওয়ালেটে পর্যাপ্ত ব্যালেন্স নেই। মোট প্রয়োজন ৳${totalBudget}। দয়া করে আগে ডিপোজিট করুন।`
      });
      return;
    }

    setIsSubmitting(true);
    setFeedback(null);

    try {
      const token = localStorage.getItem('pixel_token');
      const res = await fetch('/api/jobs', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          title,
          titleBn: titleBn || title,
          category,
          jobType,
          paymentPerWorker: payPerWorker,
          totalSlots: slots,
          deadline,
          description,
          requiredProof
        })
      });

      const data = await res.json();
      if (res.ok) {
        setFeedback({ type: 'success', text: 'জব সফলভাবে পাবলিশ হয়েছে!' });
        setTimeout(() => {
          closePostJobModal();
          window.location.reload();
        }, 1200);
        await refreshUser();
      } else {
        setFeedback({ type: 'error', text: data.error || 'জব পোস্ট করতে ব্যর্থ হয়েছে।' });
      }
    } catch (err: any) {
      setFeedback({ type: 'error', text: err.message || 'Network error' });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-fade-in">
      <div className="bg-white border border-slate-200 w-full max-w-2xl rounded-2xl p-6 sm:p-7 max-h-[92vh] overflow-y-auto shadow-2xl relative">
        <button
          onClick={closePostJobModal}
          className="absolute top-5 right-5 text-slate-400 hover:text-slate-600 transition-colors cursor-pointer p-1"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
            <PlusCircle className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xl font-extrabold text-slate-900 font-display">
              {t.navPostJob} — Create New Job
            </h3>
            <span className="text-xs text-slate-400">
              Approved Employer & Admin Multi-Vendor Management
            </span>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              কাজের শিরোনাম (Job Title in English):
            </label>
            <input
              type="text"
              required
              placeholder="e.g. YouTube Gaming High CTR Thumbnail Design"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm text-slate-900 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              কাজের শিরোনাম (বাংলায়):
            </label>
            <input
              type="text"
              placeholder="যেমন: গেমিং চ্যানেলের জন্য হাই সিটিআর থাম্বনেইল ডিজাইন"
              value={titleBn}
              onChange={(e) => setTitleBn(e.target.value)}
              className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm text-slate-900 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                ক্যাটাগরি (Category):
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm text-slate-900 focus:outline-none focus:border-emerald-500"
              >
                <option value="Thumbnail Design">Thumbnail Design</option>
                <option value="Logo Design">Logo Design</option>
                <option value="Video Editing">Video Editing</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                কাজের ধরণ (Job Type):
              </label>
              <select
                value={jobType}
                onChange={(e) => setJobType(e.target.value)}
                className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm text-slate-900 focus:outline-none focus:border-emerald-500"
              >
                <option value="Per Task">Per Task (প্রতি কাজ)</option>
                <option value="Fixed Price">Fixed Price (নির্দিষ্ট চুক্তি)</option>
                <option value="Micro Job">Micro Job (মাইক্রো জব)</option>
                <option value="Hourly">Hourly</option>
              </select>
            </div>
          </div>

          {/* Pricing & Slots Math */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-4 rounded-xl bg-slate-50 border border-slate-200">
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">
                প্রতি জনের পারিশ্রমিক (৳):
              </label>
              <input
                type="number"
                required
                min={1}
                value={paymentPerWorker}
                onChange={(e) => setPaymentPerWorker(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm text-emerald-600 font-mono font-bold focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">
                কতজন কাজ করতে পারবে (Slots):
              </label>
              <input
                type="number"
                required
                min={1}
                value={totalSlots}
                onChange={(e) => setTotalSlots(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm text-slate-900 font-mono font-bold focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">
                মোট ফান্ড/বাজেট (Total):
              </label>
              <div className="px-3 py-2 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-700 font-mono font-bold text-sm">
                ৳{totalBudget}
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-teal-400" />
              <span>শেষ সময় (Deadline):</span>
            </label>
            <input
              type="date"
              required
              value={deadline}
              onChange={(e) => setDeadline(e.target.value)}
              className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm text-slate-900 focus:outline-none focus:border-emerald-500 font-mono"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              কাজের বিস্তারিত নির্দেশাবলী (Job Description & Rules):
            </label>
            <textarea
              rows={3}
              required
              placeholder="ফ্রিল্যান্সারকে কী করতে হবে, কী সফটওয়্যার ব্যবহার করতে হবে তা পরিষ্কারভাবে লিখুন..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm text-slate-900 focus:outline-none focus:border-emerald-500 resize-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              প্রয়োজনীয় প্রুফ (Required Proof Instructions):
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Completed image link on Google Drive and screenshot of layer file."
              value={requiredProof}
              onChange={(e) => setRequiredProof(e.target.value)}
              className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm text-slate-900 focus:outline-none focus:border-emerald-500"
            />
          </div>

          {user?.role !== 'admin' && (
            <div className="flex items-center justify-between text-xs text-slate-500 p-2.5 bg-slate-50 rounded-lg">
              <span>আপনার বর্তমান ওয়ালেট ব্যালেন্স:</span>
              <span className="font-mono font-bold text-emerald-600">৳{wallet.availableBalance}</span>
            </div>
          )}

          {feedback && (
            <div
              className={`p-3 rounded-xl text-xs font-medium ${
                feedback.type === 'success'
                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                  : 'bg-rose-50 text-rose-700 border border-rose-200'
              }`}
            >
              {feedback.text}
            </div>
          )}

          <div className="pt-2 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={closePostJobModal}
              className="px-4 py-2.5 text-xs font-semibold text-slate-500 hover:text-slate-700 transition-colors cursor-pointer"
            >
              বাতিল
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-lg shadow-emerald-600/20 transition-all cursor-pointer disabled:opacity-50"
            >
              {isSubmitting ? 'পাবলিশ হচ্ছে...' : `জব পাবলিশ করুন (৳${totalBudget})`}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
