import React from 'react';
import { useAuth } from '../context/AuthContext';
import { useTranslation } from '../translations';
import {
  Wallet as WalletIcon,
  PlusCircle,
  ShieldAlert,
  UserCheck,
  LogOut,
  Globe,
  Briefcase
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const {
    user,
    wallet,
    language,
    toggleLanguage,
    activeView,
    setActiveView,
    openAuthModal,
    openWalletModal,
    openPostJobModal,
    openEmployerReqModal,
    logout
  } = useAuth();

  const t = useTranslation(language);
  const [logoClicks, setLogoClicks] = React.useState(0);

  const handleLogoClick = () => {
    const newClicks = logoClicks + 1;
    if (newClicks >= 5) {
      setLogoClicks(0);
      openAuthModal('admin');
    } else {
      setLogoClicks(newClicks);
      setActiveView('home');
      // Reset clicks after 2 seconds of inactivity
      setTimeout(() => setLogoClicks(0), 2000);
    }
  };

  const canPostJob = user && (user.role === 'admin' || user.employerStatus === 'approved');

  const handleProtectedAction = (view: typeof activeView) => {
    if (!user) {
      openAuthModal('login');
    } else {
      setActiveView(view);
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-slate-200 transition-colors">
      <div className="max-w-7xl mx-auto px-2 sm:px-6 py-2 flex items-center justify-between gap-2 sm:gap-4">
        {/* Zone 1: Single Brand Zone */}
        <button
          onClick={handleLogoClick}
          className="flex flex-col items-center group text-center cursor-pointer focus:outline-none shrink-0"
        >
          <div className="relative w-9 h-9 rounded-full p-0.5 bg-gradient-to-tr from-emerald-500 via-teal-400 to-amber-400 shrink-0 shadow-lg shadow-emerald-500/10 group-hover:scale-105 transition-transform">
            <img
              src="/assets/aistudio/WhatsApp_Image_2026-11-06_at_11.02.12_AM_4c49fd8b.jpeg"
              alt="PIXEL STUDIO BD Logo"
              className="w-full h-full object-cover rounded-full bg-white"
            />
          </div>
          <div className="flex flex-col items-center -mt-0.5">
            <span className="font-extrabold text-[10px] sm:text-[12px] tracking-tight text-slate-900 group-hover:text-emerald-600 transition-colors font-display leading-none">
              PIXEL STUDIO <span className="text-emerald-600 font-bold">BD</span>
            </span>
            <span className="text-[6px] sm:text-[8px] text-slate-400 tracking-tighter uppercase font-bold">
              Job & Freelance Hub
            </span>
          </div>
        </button>

        {/* Zone 2: Navigation Links (Single-Line, clean typography) */}
        <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-slate-600">
          <button
            onClick={() => setActiveView('home')}
            className={`whitespace-nowrap transition-colors cursor-pointer ${
              activeView === 'home' ? 'text-emerald-600 font-semibold' : 'hover:text-slate-900'
            }`}
          >
            {t.navHome}
          </button>
          <button
            onClick={() => handleProtectedAction('jobs')}
            className={`whitespace-nowrap transition-colors cursor-pointer ${
              activeView === 'jobs' ? 'text-emerald-600 font-semibold' : 'hover:text-slate-900'
            }`}
          >
            {t.navFindJobs}
          </button>
          <button
            onClick={() => handleProtectedAction('freelancing')}
            className={`whitespace-nowrap transition-colors cursor-pointer ${
              activeView === 'freelancing' ? 'text-emerald-600 font-semibold' : 'hover:text-slate-900'
            }`}
          >
            {t.navFreelancing}
          </button>
          <button
            onClick={() => handleProtectedAction('services')}
            className={`whitespace-nowrap transition-colors cursor-pointer ${
              activeView === 'services' ? 'text-emerald-600 font-semibold' : 'hover:text-slate-900'
            }`}
          >
            {t.navServices}
          </button>
          <button
            onClick={() => handleProtectedAction('tutorials')}
            className={`whitespace-nowrap transition-colors cursor-pointer ${
              activeView === 'tutorials' ? 'text-emerald-600 font-semibold' : 'hover:text-slate-900'
            }`}
          >
            {t.navTutorials}
          </button>
        </nav>

        {/* Zone 3: Actions & Auth */}
        <div className="flex items-center gap-3">
          {/* Language Switcher */}
          <button
            onClick={toggleLanguage}
            title="Toggle Language (বাংলা / English)"
            className="flex items-center gap-1 px-1.5 py-1 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 text-[10px] font-semibold text-slate-600 hover:text-emerald-600 transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <Globe className="w-3 h-3 text-emerald-600" />
            <span>{language === 'bn' ? 'EN' : 'বাংলা'}</span>
          </button>

          {user ? (
            <div className="flex items-center gap-2 sm:gap-3">
              {/* Wallet pill */}
              <button
                onClick={() => openWalletModal()}
                className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-50 border border-emerald-200 hover:border-emerald-400 text-emerald-700 text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 group"
              >
                <WalletIcon className="w-4 h-4 text-emerald-600 group-hover:scale-110 transition-transform" />
                <span className="font-mono tabular-nums text-sm">৳{wallet.availableBalance}</span>
              </button>

              {/* Admin Panel button - ONLY visible to actual admins */}
              {user.role === 'admin' && (
                <button
                  onClick={() => setActiveView('admin')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                    activeView === 'admin'
                      ? 'bg-amber-500 text-white font-extrabold shadow-md shadow-amber-500/20'
                      : 'bg-amber-50 border border-amber-200 text-amber-700 hover:bg-amber-100'
                  }`}
                >
                  <ShieldAlert className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Admin Panel</span>
                </button>
              )}

              {/* Post Job Button if authorized */}
              {canPostJob ? (
                <button
                  onClick={openPostJobModal}
                  className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shadow-md shadow-emerald-900/10 transition-all cursor-pointer whitespace-nowrap shrink-0"
                >
                  <PlusCircle className="w-4 h-4" />
                  <span className="hidden sm:inline">{t.navPostJob}</span>
                </button>
              ) : (
                <button
                  onClick={openEmployerReqModal}
                  className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-indigo-50 border border-indigo-200 hover:bg-indigo-100 text-indigo-700 text-xs font-medium transition-all cursor-pointer whitespace-nowrap shrink-0"
                  title="Post your own jobs"
                >
                  <Briefcase className="w-3.5 h-3.5 text-indigo-600" />
                  <span className="hidden md:inline">{t.navBecomeEmployer}</span>
                </button>
              )}

              {/* User Dropdown / Logout */}
              <div className="flex items-center gap-2 pl-1 border-l border-slate-200">
                <div
                  className="w-8 h-8 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center text-xs font-bold text-slate-700 shrink-0"
                  title={`${user.name} (${user.role})`}
                >
                  {user.name.charAt(0).toUpperCase()}
                </div>
                <button
                  onClick={logout}
                  title={t.navLogout}
                  className="p-1.5 text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-1.5 sm:gap-2">
              <button
                onClick={() => openAuthModal('login')}
                className="px-2 sm:px-3.5 py-1.5 text-[10px] sm:text-xs font-semibold text-slate-600 hover:text-slate-900 transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                {t.navLogin}
              </button>
              <button
                onClick={() => openAuthModal('register')}
                className="px-3 sm:px-4 py-1.5 text-[10px] sm:text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-md shadow-emerald-500/10 transition-all cursor-pointer whitespace-nowrap shrink-0"
              >
                {t.navRegister}
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
