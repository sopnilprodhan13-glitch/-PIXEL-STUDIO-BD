import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTranslation } from '../translations';
import {
  Briefcase,
  Calendar,
  Send,
  X,
  Clock,
  Sparkles,
  Link as LinkIcon
} from 'lucide-react';

interface Project {
  id: string;
  title: string;
  titleBn?: string;
  category: string;
  employerId: string;
  employerName: string;
  budget: number;
  deadline: string;
  projectType: string;
  skills: string[];
  proposalsCount: number;
  status: string;
  description: string;
  createdAt: string;
}

export const FreelancingSection: React.FC = () => {
  const { language, user, openAuthModal } = useAuth();
  const t = useTranslation(language);

  const [projects, setProjects] = useState<Project[]>([]);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [proposedPrice, setProposedPrice] = useState<string>('');
  const [deliveryDays, setDeliveryDays] = useState<string>('5');
  const [coverLetter, setCoverLetter] = useState<string>('');
  const [portfolioLink, setPortfolioLink] = useState<string>('');
  const [isSending, setIsSending] = useState<boolean>(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    // Fetch from backend (empty for now)
    setProjects([]);
  }, []);

  const handleSendProposal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      openAuthModal('login');
      return;
    }
    setIsSending(true);
    setFeedback(null);

    setTimeout(() => {
      setIsSending(false);
      setFeedback({
        type: 'success',
        text: 'আপনার প্রপোজাল ক্লায়েন্টের কাছে সফলভাবে পৌঁছেছে! ক্লায়েন্ট গ্রহণ করলে ড্যাশবোর্ডে নোটিফিকেশন পাবেন।'
      });
      setCoverLetter('');
      setPortfolioLink('');
    }, 600);
  };

  return (
    <section className="py-14 border-b border-slate-100" id="freelancing-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-10">
          <div>
            <div className="text-xs uppercase tracking-wider text-emerald-600 font-bold mb-1 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Direct Freelancing Contracts</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display">
              {language === 'bn' ? 'হাই-ভ্যালু ফ্রিল্যান্সিং প্রজেক্ট' : 'High-Value Freelancing Projects'}
            </h2>
            <p className="text-sm text-slate-500 mt-1 max-w-xl">
              {language === 'bn'
                ? 'বড় বাজেটের প্রজেক্টে প্রপোজাল পাঠিয়ে সরাসরি ক্লায়েন্টের সাথে কাজ করুন'
                : 'Send proposals to funded client projects with guaranteed milestone escrows.'}
            </p>
          </div>
        </div>

        {/* Project Cards */}
        <div className="space-y-4">
          {projects.length > 0 ? (
            projects.map((proj) => (
              <div
                key={proj.id}
                className="p-6 rounded-2xl bg-white border border-slate-200 hover:border-emerald-500/40 transition-all flex flex-col md:flex-row md:items-center justify-between gap-6 group shadow-sm hover:shadow-md"
              >
                <div className="max-w-3xl">
                  <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 mb-2">
                    <span className="text-emerald-600 font-bold uppercase">{proj.category}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-medium">{proj.projectType}</span>
                    <span aria-hidden="true">·</span>
                    <span className="text-slate-600 font-bold">ক্লায়েন্ট: {proj.employerName}</span>
                  </div>

                  <h3 className="text-lg font-bold text-slate-900 group-hover:text-emerald-600 transition-colors mb-2">
                    {language === 'bn' && proj.titleBn ? proj.titleBn : proj.title}
                  </h3>

                  <p className="text-xs text-slate-600 leading-relaxed mb-4">
                    {proj.description}
                  </p>

                  {/* Skills strip */}
                  <div className="flex flex-wrap items-center gap-1.5">
                    {proj.skills.map((skill, idx) => (
                      <span
                        key={idx}
                        className="px-2.5 py-1 rounded-md bg-slate-50 text-[11px] text-slate-600 font-semibold border border-slate-100"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Price & Apply column */}
                <div className="flex md:flex-col items-center md:items-end justify-between md:justify-center gap-4 shrink-0 border-t md:border-t-0 md:border-l border-slate-100 pt-4 md:pt-0 md:pl-6">
                  <div className="text-left md:text-right">
                    <span className="text-[11px] text-slate-400 block font-bold uppercase">বাজেট</span>
                    <span className="text-xl font-extrabold text-emerald-600 font-mono">
                      ৳{proj.budget}
                    </span>
                    <div className="text-[10px] text-slate-400 mt-0.5 font-medium">
                      {proj.proposalsCount} Proposals
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      if (!user) {
                        openAuthModal('login');
                      } else {
                        setSelectedProject(proj);
                        setProposedPrice(proj.budget.toString());
                        setFeedback(null);
                      }
                    }}
                    className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-sm transition-all cursor-pointer whitespace-nowrap"
                  >
                    প্রপোজাল পাঠান
                  </button>
                </div>
              </div>
            ))
          ) : (
            <div className="p-12 text-center bg-slate-50 rounded-3xl border border-dashed border-slate-200">
              <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-sm">
                <Briefcase className="w-8 h-8 text-slate-300" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-1">
                {language === 'bn' ? 'নতুন প্রজেক্ট শীঘ্রই আসছে' : 'No Projects Available Yet'}
              </h3>
              <p className="text-sm text-slate-500 max-w-sm mx-auto">
                {language === 'bn'
                  ? 'আমাদের টিম বর্তমানে হাই-ভ্যালু ক্লায়েন্ট ভেরিফিকেশন করছে। খুব শীঘ্রই এখানে বড় প্রজেক্ট দেখতে পাবেন।'
                  : 'Our team is currently verifying high-value clients. New projects will appear here very soon.'}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Proposal Submission Modal */}
      {selectedProject && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
          <div className="bg-white border border-slate-200 w-full max-w-xl rounded-2xl p-6 sm:p-7 max-h-[90vh] overflow-y-auto shadow-2xl relative">
            <button
              onClick={() => setSelectedProject(null)}
              className="absolute top-5 right-5 text-slate-400 hover:text-slate-900 transition-colors cursor-pointer p-1"
            >
              <X className="w-5 h-5" />
            </button>

            <span className="text-xs text-emerald-600 font-bold block mb-1 uppercase tracking-wider">
              Submit Proposal to Client
            </span>
            <h3 className="text-xl font-extrabold text-slate-900 font-display mb-1">
              {language === 'bn' && selectedProject.titleBn ? selectedProject.titleBn : selectedProject.title}
            </h3>
            <div className="text-xs text-slate-500 mb-6 font-medium">
              ক্লায়েন্টের বাজেট: <strong className="text-emerald-600 font-mono">৳{selectedProject.budget}</strong>
            </div>

            <form onSubmit={handleSendProposal} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    আপনার বিড প্রাইস (BDT ৳):
                  </label>
                  <input
                    type="number"
                    required
                    min={10}
                    value={proposedPrice}
                    onChange={(e) => setProposedPrice(e.target.value)}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900 focus:outline-none focus:border-emerald-500 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    ডেলিভারি সময় (দিন):
                  </label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={deliveryDays}
                    onChange={(e) => setDeliveryDays(e.target.value)}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900 focus:outline-none focus:border-emerald-500 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  কভার লেটার (আপনার কাজের অভিজ্ঞতা ও পরিকল্পনা):
                </label>
                <textarea
                  rows={4}
                  required
                  placeholder="ক্লায়েন্টকে সংক্ষেপে জানান আপনি কীভাবে এই প্রজেক্ট সম্পন্ন করবেন..."
                  value={coverLetter}
                  onChange={(e) => setCoverLetter(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-emerald-500 transition-colors resize-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
                  <LinkIcon className="w-3.5 h-3.5 text-emerald-600" />
                  <span>পোর্টফোলিও বা কাজের লিংক (ঐচ্ছিক):</span>
                </label>
                <input
                  type="url"
                  placeholder="https://behance.net/yourprofile or Google Drive folder"
                  value={portfolioLink}
                  onChange={(e) => setPortfolioLink(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-emerald-500 transition-colors"
                />
              </div>

              {feedback && (
                <div
                  className={`p-3 rounded-xl text-xs font-medium ${
                    feedback.type === 'success'
                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-100'
                      : 'bg-rose-50 text-rose-700 border border-rose-100'
                  }`}
                >
                  {feedback.text}
                </div>
              )}

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setSelectedProject(null)}
                  className="px-4 py-2.5 text-xs font-semibold text-slate-500 hover:text-slate-900 transition-colors cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  disabled={isSending}
                  className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-sm transition-all cursor-pointer disabled:opacity-50 flex items-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isSending ? 'পাঠানো হচ্ছে...' : 'প্রপোজাল জমা দিন'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </section>
  );
};
