import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTranslation } from '../translations';
import { Job } from '../types';
import {
  Search,
  CheckCircle2,
  Calendar,
  Users,
  Coins,
  ArrowUpRight,
  Upload,
  Link as LinkIcon,
  X,
  FileText,
  AlertCircle
} from 'lucide-react';

export const JobsSection: React.FC = () => {
  const { language, user, openAuthModal, openWalletModal, refreshUser } = useAuth();
  const t = useTranslation(language);

  const [jobs, setJobs] = useState<Job[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);

  // Application / submission modal states
  const [proofUrl, setProofUrl] = useState<string>('');
  const [proofText, setProofText] = useState<string>('');
  const [screenshot, setScreenshot] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [submitMessage, setSubmitMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const categories = [
    'All',
    'Thumbnail Design',
    'Logo Design',
    'Video Editing',
    'Banner Design',
    'Translation',
    'Micro Job'
  ];

  const fetchJobs = async () => {
    try {
      const res = await fetch('/api/jobs');
      if (res.ok) {
        const data = await res.json();
        setJobs(data);
      }
    } catch (err) {
      console.error('Error fetching jobs:', err);
    }
  };

  useEffect(() => {
    fetchJobs();
  }, []);

  const filteredJobs = jobs.filter((job) => {
    const matchesCategory = selectedCategory === 'All' || job.category === selectedCategory;
    const matchesSearch =
      searchQuery.trim() === '' ||
      job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (job.titleBn && job.titleBn.toLowerCase().includes(searchQuery.toLowerCase())) ||
      job.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleScreenshotChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        alert('File size exceeds 5MB. Please upload a smaller screenshot or provide a Google Drive link.');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setScreenshot(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleApply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      openAuthModal('login');
      return;
    }
    if (!selectedJob) return;

    if (!proofUrl.trim() && !proofText.trim() && !screenshot) {
      setSubmitMessage({ type: 'error', text: 'Please provide proof (link, text description, or screenshot).' });
      return;
    }

    setIsSubmitting(true);
    setSubmitMessage(null);

    try {
      const token = localStorage.getItem('pixel_token');
      const res = await fetch(`/api/jobs/${selectedJob.id}/apply`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          proofUrl,
          proofText,
          screenshot
        })
      });

      const data = await res.json();
      if (res.ok) {
        setSubmitMessage({ type: 'success', text: data.message || 'Work submitted successfully! Pending review.' });
        setProofUrl('');
        setProofText('');
        setScreenshot('');
        fetchJobs();
        refreshUser();
      } else {
        setSubmitMessage({ type: 'error', text: data.error || 'Failed to submit work.' });
      }
    } catch (err: any) {
      setSubmitMessage({ type: 'error', text: err.message || 'Network error' });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section className="py-14 border-b border-slate-100" id="jobs-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
          <div>
            <div className="text-xs uppercase tracking-wider text-emerald-600 font-bold mb-1">
              Find Jobs & Earn BDT
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display">
              {t.jobsTitle}
            </h2>
            <p className="text-sm text-slate-500 mt-1 max-w-xl">
              {t.jobsSubtitle}
            </p>
          </div>

          {/* Search Box */}
          <div className="relative w-full md:w-80">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder={t.searchPlaceholder}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-emerald-500 transition-colors"
            />
          </div>
        </div>

        {/* Category Tabs (interactive button controls) */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-500/10 font-bold'
                  : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200 hover:border-slate-300'
              }`}
            >
              {cat === 'All' ? t.allCategories : cat}
            </button>
          ))}
        </div>

        {/* Jobs Grid */}
        {filteredJobs.length === 0 ? (
          <div className="p-12 text-center rounded-2xl bg-slate-50 border border-slate-100">
            <AlertCircle className="w-10 h-10 text-slate-300 mx-auto mb-3" />
            <h3 className="text-base font-bold text-slate-500">কোনো কাজ পাওয়া যায়নি</h3>
            <p className="text-xs text-slate-400 mt-1">অন্য কোনো ক্যাটাগরি বা সার্চ দিয়ে চেষ্টা করুন।</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredJobs.map((job) => {
              const remainingSlots = Math.max(0, job.totalSlots - job.filledSlots);
              const isFull = remainingSlots === 0;

              return (
                <div
                  key={job.id}
                  className="rounded-2xl bg-white border border-slate-200 hover:border-emerald-500 transition-all p-5 flex flex-col justify-between group shadow-sm hover:shadow-md"
                >
                  <div>
                    {/* Top Row: Category text & Reward pill */}
                    <div className="flex items-center justify-between gap-2 mb-3">
                      <span className="text-xs font-semibold text-emerald-600 uppercase tracking-wide">
                        {job.category}
                      </span>
                      <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-50 border border-emerald-100 text-emerald-700 text-xs font-mono font-bold">
                        <Coins className="w-3.5 h-3.5 text-emerald-600" />
                        <span>৳{job.paymentPerWorker}</span>
                      </div>
                    </div>

                    {/* Job Title */}
                    <h3 className="text-base font-bold text-slate-900 group-hover:text-emerald-700 transition-colors leading-snug mb-2">
                      {language === 'bn' && job.titleBn ? job.titleBn : job.title}
                    </h3>

                    {/* Employer Info */}
                    <div className="flex items-center gap-2 text-xs text-slate-500 mb-4">
                      <span>{job.employerName}</span>
                      {job.employerVerified && (
                        <span title={t.employerVerified} className="inline-flex">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                        </span>
                      )}
                      <span aria-hidden="true">·</span>
                      <span className="text-slate-400">{job.jobType}</span>
                    </div>

                    <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed mb-4">
                      {job.description}
                    </p>
                  </div>

                  <div>
                    {/* Slots & Deadline Strip */}
                    <div className="pt-3 border-t border-slate-100 grid grid-cols-2 gap-2 text-xs text-slate-500 mb-4">
                      <div className="flex items-center gap-1.5">
                        <Users className="w-3.5 h-3.5 text-slate-400" />
                        <span>স্লট: <strong className="text-slate-900 font-mono">{job.filledSlots}/{job.totalSlots}</strong></span>
                      </div>
                      <div className="flex items-center gap-1.5 justify-end">
                        <Calendar className="w-3.5 h-3.5 text-slate-400" />
                        <span className="font-mono text-slate-500">{job.deadline}</span>
                      </div>
                    </div>

                    {/* Action Button */}
                    <button
                      onClick={() => {
                        if (!user) {
                          openAuthModal('login');
                        } else {
                          setSelectedJob(job);
                          setSubmitMessage(null);
                        }
                      }}
                      disabled={isFull}
                      className={`w-full py-2.5 px-4 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                        isFull
                          ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                          : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm'
                      }`}
                    >
                      <span>{isFull ? 'স্লট পূর্ণ' : t.btnApplyNow}</span>
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Submit Work / Application Modal */}
      {selectedJob && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
          <div className="bg-white border border-slate-200 w-full max-w-2xl rounded-2xl p-6 sm:p-7 max-h-[90vh] overflow-y-auto shadow-2xl relative">
            <button
              onClick={() => setSelectedJob(null)}
              className="absolute top-5 right-5 text-slate-400 hover:text-slate-900 transition-colors cursor-pointer p-1"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 text-xs text-emerald-600 font-bold mb-2">
              <span>{selectedJob.category}</span>
              <span aria-hidden="true">·</span>
              <span>{selectedJob.jobType}</span>
            </div>

            <h3 className="text-xl font-extrabold text-slate-900 font-display mb-1">
              {language === 'bn' && selectedJob.titleBn ? selectedJob.titleBn : selectedJob.title}
            </h3>

            <div className="flex items-center gap-4 text-xs text-slate-500 mb-6">
              <span>এমপ্লয়ার: <strong className="text-slate-700">{selectedJob.employerName}</strong></span>
              <span>পারিশ্রমিক: <strong className="text-emerald-600 font-mono text-sm font-bold">৳{selectedJob.paymentPerWorker}</strong></span>
              <span>অবশিষ্ট স্লট: <strong className="text-slate-900 font-mono">{selectedJob.totalSlots - selectedJob.filledSlots}</strong></span>
            </div>

            {/* Description & Task Instructions */}
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 mb-6">
              <h4 className="text-xs uppercase font-bold text-slate-600 tracking-wider mb-2 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-emerald-600" />
                <span>কাজের বিস্তারিত নির্দেশিকা (Job Instructions):</span>
              </h4>
              <p className="text-xs text-slate-600 leading-relaxed whitespace-pre-line mb-3">
                {selectedJob.description}
              </p>
              <div className="pt-2 border-t border-slate-200">
                <span className="text-xs font-bold text-amber-700">প্রয়োজনীয় প্রুফ (Required Proof): </span>
                <span className="text-xs text-slate-600">{selectedJob.requiredProof}</span>
              </div>
            </div>

            {/* Submission Form */}
            <form onSubmit={handleApply} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
                  <LinkIcon className="w-3.5 h-3.5 text-emerald-600" />
                  <span>কাজের লিংক (Google Drive / Imgur / YouTube link):</span>
                </label>
                <input
                  type="url"
                  placeholder="https://drive.google.com/..."
                  value={proofUrl}
                  onChange={(e) => setProofUrl(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-emerald-500 transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  কাজের বর্ণনা বা টেক্সট প্রুফ (Description / Proof Notes):
                </label>
                <textarea
                  rows={3}
                  placeholder="কাজটি কীভাবে সম্পন্ন করেছেন এবং প্রয়োজনীয় তথ্য লিখুন..."
                  value={proofText}
                  onChange={(e) => setProofText(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-emerald-500 transition-colors resize-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
                  <Upload className="w-3.5 h-3.5 text-teal-600" />
                  <span>স্ক্রিনশট আপলোড (ঐচ্ছিক, সর্বোচ্চ 5MB):</span>
                </label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleScreenshotChange}
                  className="w-full text-xs text-slate-500 file:mr-3 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-slate-100 file:text-slate-700 cursor-pointer"
                />
                {screenshot && (
                  <div className="mt-2 relative w-32 h-20 rounded-lg overflow-hidden border border-slate-200">
                    <img src={screenshot} alt="Screenshot Preview" className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={() => setScreenshot('')}
                      className="absolute top-1 right-1 p-0.5 bg-red-600 rounded text-white"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                )}
              </div>

              {submitMessage && (
                <div
                  className={`p-3 rounded-xl text-xs font-medium ${
                    submitMessage.type === 'success'
                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-100'
                      : 'bg-rose-50 text-rose-700 border border-rose-100'
                  }`}
                >
                  {submitMessage.text}
                </div>
              )}

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setSelectedJob(null)}
                  className="px-4 py-2.5 text-xs font-semibold text-slate-500 hover:text-slate-900 transition-colors cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-sm transition-all cursor-pointer disabled:opacity-50"
                >
                  {isSubmitting ? 'জমা হচ্ছে...' : 'প্রুফ সাবমিট করুন'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </section>
  );
};
