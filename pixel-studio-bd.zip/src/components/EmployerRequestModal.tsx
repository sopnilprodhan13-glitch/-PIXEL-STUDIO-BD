import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTranslation } from '../translations';
import {
  X,
  Briefcase,
  Send,
  MessageSquare,
  PhoneCall,
  CheckCircle2,
  Clock
} from 'lucide-react';

export const EmployerRequestModal: React.FC = () => {
  const { isEmployerReqModalOpen, closeEmployerReqModal, user, refreshUser, language } = useAuth();
  const t = useTranslation(language);

  const [companyName, setCompanyName] = useState<string>('');
  const [mobileNumber, setMobileNumber] = useState<string>(user?.mobile || '');
  const [reason, setReason] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [statusSubmitted, setStatusSubmitted] = useState<boolean>(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  if (!isEmployerReqModalOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setFeedback(null);

    try {
      const token = localStorage.getItem('pixel_token');
      const res = await fetch('/api/employer/request-access', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          companyName,
          mobileNumber,
          reason
        })
      });

      const data = await res.json();
      if (res.ok) {
        setStatusSubmitted(true);
        await refreshUser();
      } else {
        setFeedback(data.error || 'আবেদন জমা দিতে সমস্যা হয়েছে।');
      }
    } catch (err: any) {
      setFeedback(err.message || 'Network error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-fade-in">
      <div className="bg-white border border-slate-200 w-full max-w-xl rounded-2xl p-6 sm:p-7 max-h-[90vh] overflow-y-auto shadow-2xl relative">
        <button
          onClick={closeEmployerReqModal}
          className="absolute top-5 right-5 text-slate-400 hover:text-slate-600 transition-colors cursor-pointer p-1"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400">
            <Briefcase className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xl font-extrabold text-slate-900 font-display">
              {t.employerReqTitle}
            </h3>
            <span className="text-xs text-slate-400">Job Posting Verification</span>
          </div>
        </div>

        {statusSubmitted || user?.employerStatus === 'pending' ? (
          <div className="p-5 rounded-2xl bg-indigo-50 border border-indigo-200 text-center space-y-4">
            <div className="w-12 h-12 rounded-full bg-indigo-100 border border-indigo-200 flex items-center justify-center mx-auto text-indigo-600">
              <Clock className="w-6 h-6 animate-pulse" />
            </div>

            <div>
              <span className="inline-block px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-700 border border-amber-200 mb-2">
                Status: Pending Approval
              </span>
              <h4 className="text-base font-bold text-slate-900 mb-1">
                আপনার আবেদন পর্যালোচনার জন্য জমা হয়েছে!
              </h4>
              <p className="text-xs text-slate-600 leading-relaxed max-w-md mx-auto">
                দ্রুত Approval এর জন্য আমাদের Support Team এর সঙ্গে আপনার রেজিস্টার্ড ইমেইল (
                <strong className="text-emerald-600 font-mono">{user?.email}</strong>) সহ যোগাযোগ করুন।
              </p>
            </div>

            {/* Direct Support Buttons */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <a
                href="https://t.me/INCOME47776"
                target="_blank"
                rel="noreferrer"
                className="py-3 px-4 rounded-xl bg-[#229ED9]/10 hover:bg-[#229ED9]/20 border border-[#229ED9]/20 text-[#229ED9] font-bold text-xs flex items-center justify-center gap-2 transition-all"
              >
                <MessageSquare className="w-4 h-4" />
                <span>{t.contactSupportTelegram}</span>
              </a>

              <a
                href={`https://wa.me/8801320765354?text=${encodeURIComponent(
                  `Hello PIXEL STUDIO BD Admin, I have submitted an Employer Access request for email: ${user?.email}. Please verify.`
                )}`}
                target="_blank"
                rel="noreferrer"
                className="py-3 px-4 rounded-xl bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-600 font-bold text-xs flex items-center justify-center gap-2 transition-all"
              >
                <PhoneCall className="w-4 h-4" />
                <span>{t.contactSupportWhatsapp}</span>
              </a>
            </div>

            <button
              onClick={closeEmployerReqModal}
              className="text-xs text-slate-500 hover:text-slate-700 transition-colors cursor-pointer pt-2"
            >
              বন্ধ করুন
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600 leading-relaxed">
              এমপ্লয়ার হিসেবে অনুমোদিত হলে আপনি সরাসরি নিজের পছন্দমতো বাজেটে জব এবং ফ্রিল্যান্সিং প্রজেক্ট পোস্ট করতে পারবেন।
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                রেজিস্টার্ড ইমেইল:
              </label>
              <input
                type="text"
                disabled
                value={user?.email || ''}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                মোবাইল নম্বর:
              </label>
              <input
                type="tel"
                required
                value={mobileNumber}
                onChange={(e) => setMobileNumber(e.target.value)}
                placeholder="01XXXXXXXXX"
                className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm text-slate-900 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {t.companyNameLabel}:
              </label>
              <input
                type="text"
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                placeholder="যেমন: Media Content Creator / Tech Agency"
                className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm text-slate-900 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {t.reasonLabel}:
              </label>
              <textarea
                rows={3}
                required
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="আমরা প্রতিদিন ৫-১০টি ইউটিউব থাম্বনেইল ও রিলস এডিটের কাজ করাতে চাই..."
                className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm text-slate-900 focus:outline-none focus:border-indigo-500 resize-none"
              />
            </div>

            {feedback && (
              <div className="p-3 rounded-xl text-xs font-medium bg-rose-50 text-rose-700 border border-rose-200">
                {feedback}
              </div>
            )}

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white font-bold text-xs shadow-lg shadow-indigo-200/50 transition-all cursor-pointer disabled:opacity-50"
            >
              {isSubmitting ? 'জমা হচ্ছে...' : t.btnSubmitEmployerReq}
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
