import { Language } from '../types';

export const translations = {
  bn: {
    // Brand
    brandName: 'PIXEL STUDIO BD',
    tagline: 'দক্ষতা দিয়ে কাজ করুন, নিজের আয়ের সুযোগ তৈরি করুন!',
    subTagline: 'PIXEL STUDIO BD-তে খুঁজে নিন আপনার পছন্দের কাজ, ফ্রিল্যান্সিং প্রজেক্ট এবং ডিজিটাল সার্ভিস।',
    earningPromise: 'প্রতিদিন ১০০–২০০ টাকা পর্যন্ত আয়ের সুযোগ',
    earningDisclaimer: 'আয় নির্ভর করবে কাজের প্রাপ্যতা, দক্ষতা, সম্পন্ন কাজ এবং অনুমোদনের ওপর। নির্দিষ্ট আয় নিশ্চিত নয়।',

    // Nav
    navHome: 'হোম',
    navFindJobs: 'কাজ খুঁজুন',
    navFreelancing: 'ফ্রিল্যান্সিং',
    navServices: 'ডিজিটাল সার্ভিস',
    navHowItWorks: 'কীভাবে কাজ করে',
    navTutorials: 'ভিডিও টিউটোরিয়াল',
    navSupport: 'সাপোর্ট',
    navLogin: 'লগইন',
    navRegister: 'রেজিস্টার',
    navPostJob: 'জব পোস্ট করুন',
    navDashboard: 'ড্যাশবোর্ড',
    navAdminPanel: 'অ্যাডমিন প্যানেল',
    navLogout: 'লগআউট',
    navBecomeEmployer: 'এমপ্লয়ার হন',
    navWallet: 'ওয়ালেট',

    // Hero CTAs
    btnFindJobs: 'কাজ খুঁজুন',
    btnExploreFreelancing: 'ফ্রিল্যান্সিং প্রজেক্ট',
    btnOurServices: 'ডিজিটাল সার্ভিসেস',
    btnDepositNow: 'ডিপোজিট করুন',
    btnWithdrawNow: 'টাকা তুলুন',

    // Stats
    statJobsAvailable: 'চলতি কাজের সংখ্যা',
    statTotalPaid: 'মোট পেমেন্ট সম্পন্ন',
    statActiveFreelancers: 'সক্রিয় ফ্রিল্যান্সার',
    statSuccessRate: 'সফল কাজের হার',

    // Job Section
    jobsTitle: 'উপলব্ধ কাজের তালিকা',
    jobsSubtitle: 'সহজ টাস্ক ও প্রজেক্ট সম্পন্ন করে সাথে সাথে বিডিটি ওয়ালেটে আয় করুন',
    searchPlaceholder: 'কাজের নাম বা ক্যাটাগরি খুঁজুন...',
    allCategories: 'সকল ক্যাটাগরি',
    allTypes: 'সকল কাজের ধরন',
    slotCount: 'অবশিষ্ট স্লট',
    paymentPerTask: 'প্রতি কাজের পারিশ্রমিক',
    deadline: 'শেষ সময়',
    btnApplyNow: 'কাজ জমা দিন',
    btnDetails: 'বিস্তারিত দেখুন',
    employerVerified: 'ভেরিফাইড এমপ্লয়ার',

    // Services Section
    servicesTitle: 'আমাদের প্রিমিয়াম ডিজিটাল সার্ভিস',
    servicesSubtitle: 'ইউটিউব থাম্বনেইল, লোগো ডিজাইন, এবং ভিডিও এডিটিং এর জন্য বিশ্বমানের সমাধান',
    startingFrom: 'শুরু মাত্র ৳',
    btnOrderPackage: 'অর্ডার করুন',
    packageBasic: 'বেসিক',
    packageStandard: 'স্ট্যান্ডার্ড',
    packagePremium: 'প্রিমিয়াম',

    // How It Works
    howTitle: 'কীভাবে প্ল্যাটফর্মে কাজ শুরু করবেন?',
    howStep1Title: '১. একাউন্ট তৈরি করুন',
    howStep1Desc: 'সহজেই সাইন আপ করে ফ্রিল্যান্সার অথবা এমপ্লয়ার হিসেবে প্রোফাইল সাজান।',
    howStep2Title: '২. কাজ বেছে নিয়ে সম্পন্ন করুন',
    howStep2Desc: 'আপনার পছন্দের ক্যাটাগরির কাজ বেছে নির্দেশিকা অনুযায়ী কাজ করুন ও প্রুফ জমা দিন।',
    howStep3Title: '৩. ওয়ালেটে আয় বুঝে নিন',
    howStep3Desc: 'এমপ্লয়ার বা অ্যাডমিন যাচাই করার সাথে সাথে আপনার ওয়ালেটে টাকা জমা হবে।',
    howStep4Title: '৪. বিকাশ/নগদে উত্তোলন করুন',
    howStep4Desc: 'যেকোনো সময় বিকাশ, নগদ বা রকেটে টাকা তুলে নিন সরাসরি আপনার পার্সোনাল নম্বরে।',

    // Wallet Modal
    walletTitle: 'আমার পার্সোনাল ওয়ালেট',
    availableBalance: 'উত্তোলনযোগ্য ব্যালেন্স',
    pendingBalance: 'পেন্ডিং ডিপোজিট',
    heldBalance: 'হোল্ড ব্যালেন্স',
    totalEarned: 'সর্বমোট আয়',
    tabDeposit: 'ডিপোজিট (টাকা যোগ)',
    tabWithdraw: 'উত্তোলন (টাকা তোলা)',
    tabLedger: 'ট্রানজেকশন হিস্ট্রি',
    amountLabel: 'টাকার পরিমাণ (BDT ৳)',
    trxIdLabel: 'Transaction ID (TrxID)',
    senderPhoneLabel: 'প্রেরকের মোবাইল নম্বর',
    proofScreenshotLabel: 'পেমেন্ট স্ক্রিনশট (ঐচ্ছিক)',
    btnSubmitDeposit: 'ডিপোজিট রিকোয়েস্ট পাঠান',
    withdrawMethodLabel: 'পেমেন্ট মেথড নির্বাচন করুন',
    accountNumberLabel: 'আপনার বিকাশ/নগদ/রকেট নম্বর',
    accountHolderLabel: 'একাউন্টধারীর নাম',
    btnSubmitWithdraw: 'উত্তোলনের আবেদন করুন',
    minWithdrawNotice: 'নূন্যতম উত্তোলনের পরিমাণ ১০০ টাকা। ২৪ ঘণ্টার মধ্যে আপনার নম্বরে টাকা পৌঁছে যাবে।',

    // Employer Request Modal
    employerReqTitle: 'Become an Employer / এমপ্লয়ার পারমিশন আবেদন',
    employerReqNotice: 'আপনার Employer Access Request জমা হলে Support Team (WhatsApp / Telegram)-এ যোগাযোগ করে Approval নিন।',
    companyNameLabel: 'প্রতিষ্ঠান বা চ্যানেল নাম (ঐচ্ছিক)',
    reasonLabel: 'আপনি কেন কাজ পোস্ট করতে চান?',
    btnSubmitEmployerReq: 'আবেদন জমা দিন',
    contactSupportTelegram: 'টেলিগ্রাম সাপোর্টে নক করুন',
    contactSupportWhatsapp: 'হোয়াটসঅ্যাপে নক করুন',

    // Admin
    adminDashboardTitle: 'PIXEL STUDIO BD অ্যাডমিন কন্ট্রোল সেন্টার',
    adminLoginTitle: 'এডমিন সিকিউর লগইন',
    adminEmailNotice: 'নির্দিষ্ট অ্যাডমিন ইমেইল: sopnilprodhan13@gmail.com',
    adminPassNotice: 'ডিফল্ট পাসওয়ার্ড: 111111',
    tabOverview: 'ওভারভিউ ও অ্যানালিটিক্স',
    tabEmployerApproval: 'এমপ্লয়ার অনুমোদন',
    tabManageJobs: 'জব ম্যানেজমেন্ট',
    tabSubmissions: 'কাজের প্রুফ যাচাই',
    tabDeposits: 'ডিপোজিট ভেরিফিকেশন',
    tabWithdrawals: 'উত্তোলন অনুমোদন',
    tabServicesOrders: 'সার্ভিস অর্ডার',
    tabAdsterra: 'অ্যাডস্টেরা বিজ্ঞাপন',
    tabTutorials: 'ইউটিউব টিউটোরিয়াল',
    tabSettings: 'সিকিউরিটি ও সেটিংস'
  },
  en: {
    // Brand
    brandName: 'PIXEL STUDIO BD',
    tagline: 'Work with skills, create your own earning opportunities!',
    subTagline: 'Discover micro-jobs, freelancing projects, and digital creative services on PIXEL STUDIO BD.',
    earningPromise: 'Earn ৳100–৳200 or more daily',
    earningDisclaimer: 'Earnings depend on job availability, skill, completed tasks, and approvals. Fixed earnings are not guaranteed.',

    // Nav
    navHome: 'Home',
    navFindJobs: 'Find Jobs',
    navFreelancing: 'Freelancing',
    navServices: 'Digital Services',
    navHowItWorks: 'How It Works',
    navTutorials: 'Video Tutorials',
    navSupport: 'Support',
    navLogin: 'Login',
    navRegister: 'Register',
    navPostJob: 'Post a Job',
    navDashboard: 'Dashboard',
    navAdminPanel: 'Admin Panel',
    navLogout: 'Logout',
    navBecomeEmployer: 'Become Employer',
    navWallet: 'Wallet',

    // Hero CTAs
    btnFindJobs: 'Find Jobs',
    btnExploreFreelancing: 'Freelancing Projects',
    btnOurServices: 'Digital Services',
    btnDepositNow: 'Deposit Funds',
    btnWithdrawNow: 'Withdraw',

    // Stats
    statJobsAvailable: 'Available Jobs',
    statTotalPaid: 'Total Paid Out',
    statActiveFreelancers: 'Active Freelancers',
    statSuccessRate: 'Task Approval Rate',

    // Job Section
    jobsTitle: 'Available Job Marketplace',
    jobsSubtitle: 'Complete tasks, submit proof, and get credited directly to your BDT wallet.',
    searchPlaceholder: 'Search jobs or categories...',
    allCategories: 'All Categories',
    allTypes: 'All Job Types',
    slotCount: 'Available Slots',
    paymentPerTask: 'Pay per task',
    deadline: 'Deadline',
    btnApplyNow: 'Submit Work',
    btnDetails: 'View Details',
    employerVerified: 'Verified Employer',

    // Services Section
    servicesTitle: 'Our Premium Digital Services',
    servicesSubtitle: 'World-class YouTube thumbnails, branding marks, and engaging video reels',
    startingFrom: 'Starting from ৳',
    btnOrderPackage: 'Order Now',
    packageBasic: 'Basic',
    packageStandard: 'Standard',
    packagePremium: 'Premium',

    // How It Works
    howTitle: 'How to Get Started',
    howStep1Title: '1. Create an Account',
    howStep1Desc: 'Sign up easily as a freelancer or apply for employer permissions to post jobs.',
    howStep2Title: '2. Pick a Task & Complete',
    howStep2Desc: 'Choose your desired category, follow instructions carefully, and submit your proof.',
    howStep3Title: '3. Get Credited in Wallet',
    howStep3Desc: 'Upon employer or admin verification, money is immediately credited to your balance.',
    howStep4Title: '4. Cash Out via bKash/Nagad',
    howStep4Desc: 'Withdraw anytime to your personal bKash, Nagad, or Rocket mobile wallet.',

    // Wallet Modal
    walletTitle: 'My Personal Wallet',
    availableBalance: 'Available Balance',
    pendingBalance: 'Pending Deposit',
    heldBalance: 'Held / In Escrow',
    totalEarned: 'Total Earned',
    tabDeposit: 'Deposit Funds',
    tabWithdraw: 'Withdraw Funds',
    tabLedger: 'Transaction Ledger',
    amountLabel: 'Amount (BDT ৳)',
    trxIdLabel: 'Transaction ID (TrxID)',
    senderPhoneLabel: 'Sender Mobile Number',
    proofScreenshotLabel: 'Payment Screenshot (Optional)',
    btnSubmitDeposit: 'Submit Deposit Request',
    withdrawMethodLabel: 'Select Payment Method',
    accountNumberLabel: 'Your bKash / Nagad / Rocket Number',
    accountHolderLabel: 'Account Holder Name',
    btnSubmitWithdraw: 'Submit Withdrawal Request',
    minWithdrawNotice: 'Minimum withdrawal amount is ৳100. Payouts processed within 24 hours.',

    // Employer Request Modal
    employerReqTitle: 'Become an Employer / Request Job Posting Access',
    employerReqNotice: 'After submitting this request, contact support on WhatsApp or Telegram with your registered email for rapid approval.',
    companyNameLabel: 'Company / Channel Name (Optional)',
    reasonLabel: 'Why do you want to post jobs?',
    btnSubmitEmployerReq: 'Submit Request',
    contactSupportTelegram: 'Contact via Telegram Support',
    contactSupportWhatsapp: 'Contact via WhatsApp Support',

    // Admin
    adminDashboardTitle: 'PIXEL STUDIO BD Admin Control Center',
    adminLoginTitle: 'Admin Secure Login',
    adminEmailNotice: 'Designated Admin: sopnilprodhan13@gmail.com',
    adminPassNotice: 'Initial Password: 111111',
    tabOverview: 'Overview & Analytics',
    tabEmployerApproval: 'Employer Approvals',
    tabManageJobs: 'Job Management',
    tabSubmissions: 'Work Submissions',
    tabDeposits: 'Deposit Verification',
    tabWithdrawals: 'Withdrawal Payouts',
    tabServicesOrders: 'Service Orders',
    tabAdsterra: 'Adsterra Ads',
    tabTutorials: 'YouTube Tutorials',
    tabSettings: 'Security & Settings'
  }
};

export const useTranslation = (lang: Language) => {
  return translations[lang] || translations.bn;
};
