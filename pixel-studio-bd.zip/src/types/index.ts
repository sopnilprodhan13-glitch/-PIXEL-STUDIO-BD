export type Language = 'bn' | 'en';

export interface User {
  id: string;
  name: string;
  email: string;
  mobile?: string;
  role: 'admin' | 'freelancer' | 'employer';
  employerStatus: 'none' | 'pending' | 'approved' | 'rejected';
  companyName?: string;
  avatar?: string;
  bio?: string;
  skills?: string[];
  createdAt: string;
}

export interface Wallet {
  availableBalance: number;
  pendingBalance: number;
  heldBalance: number;
  totalEarned: number;
  totalDeposited: number;
  totalWithdrawn: number;
}

export interface LedgerItem {
  id: string;
  userId: string;
  type: 'deposit' | 'withdrawal' | 'job_reward' | 'freelance_payment' | 'service_purchase' | 'employer_funding' | 'refund' | 'admin_adjustment';
  amount: number;
  balanceAfter: number;
  description: string;
  referenceId?: string;
  createdAt: string;
}

export interface Job {
  id: string;
  title: string;
  titleBn?: string;
  category: string;
  employerId: string;
  employerName: string;
  employerVerified: boolean;
  budget: number;
  paymentPerWorker: number;
  totalSlots: number;
  filledSlots: number;
  deadline: string;
  jobType: string;
  description: string;
  requiredProof: string;
  status: 'active' | 'paused' | 'completed' | 'cancelled';
  createdAt: string;
  thumbnail: string;
}

export interface JobSubmission {
  id: string;
  jobId: string;
  jobTitle: string;
  freelancerId: string;
  freelancerName: string;
  freelancerEmail: string;
  proofUrl: string;
  proofText: string;
  screenshot?: string;
  status: 'pending' | 'approved' | 'rejected';
  rewardAmount: number;
  submittedAt: string;
  reviewedAt?: string | null;
  feedback?: string;
}

export interface ServicePackage {
  name: string;
  price: number;
  deliveryDays: number;
  revisions: number;
  features: string[];
}

export interface DigitalService {
  id: string;
  title: string;
  titleBn?: string;
  category: string;
  slug: string;
  thumbnail: string;
  description: string;
  startingPrice: number;
  packages: {
    basic: ServicePackage;
    standard: ServicePackage;
    premium: ServicePackage;
  };
  active: boolean;
}

export interface ServiceOrder {
  id: string;
  serviceId: string;
  serviceTitle: string;
  customerId: string;
  customerName: string;
  customerEmail: string;
  customerMobile?: string;
  packageType: 'basic' | 'standard' | 'premium';
  price: number;
  requirements: string;
  referenceLink?: string;
  status: 'pending' | 'in_progress' | 'revision' | 'completed' | 'cancelled';
  createdAt: string;
  deliveryDate: string;
}

export interface DepositRequest {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  amount: number;
  paymentMethod: string;
  trxId: string;
  senderNumber: string;
  screenshot?: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
  reviewedAt?: string | null;
  rejectionReason?: string;
}

export interface WithdrawalRequest {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  amount: number;
  paymentMethod: string;
  accountNumber: string;
  accountHolder: string;
  note?: string;
  status: 'pending' | 'processing' | 'paid' | 'rejected';
  createdAt: string;
  reviewedAt?: string | null;
  rejectionReason?: string;
}

export interface PaymentMethod {
  id: string;
  provider: string;
  accountNumber: string;
  accountType: string;
  accountHolder: string;
  instructions: string;
  minDeposit: number;
  maxDeposit: number;
  active: boolean;
}

export interface EmployerRequest {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  mobileNumber: string;
  companyName: string;
  reason: string;
  status: 'pending' | 'approved' | 'rejected';
  requestedAt: string;
  reviewedAt?: string | null;
}

export interface AdsterraSettings {
  enabled: boolean;
  publisherId: string;
  slots: {
    underHero: { enabled: boolean; code: string };
    middle: { enabled: boolean; code: string };
    footer: { enabled: boolean; code: string };
    tutorial: { enabled: boolean; code: string };
  };
}

export interface YouTubeTutorial {
  id: string;
  title: string;
  titleBn?: string;
  youtubeUrl: string;
  youtubeId: string;
  category: string;
  description: string;
  featured: boolean;
  createdAt: string;
}
