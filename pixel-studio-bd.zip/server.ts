import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import bcrypt from 'bcryptjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = 3000;
const DB_FILE = path.join(__dirname, 'data', 'db.json');

// Ensure data directory exists
if (!fs.existsSync(path.join(__dirname, 'data'))) {
  fs.mkdirSync(path.join(__dirname, 'data'), { recursive: true });
}

// Initial Database Structure
interface DBData {
  users: any[];
  employerRequests: any[];
  jobs: any[];
  jobSubmissions: any[];
  freelanceProjects: any[];
  freelanceProposals: any[];
  contracts: any[];
  services: any[];
  serviceOrders: any[];
  wallets: Record<string, {
    availableBalance: number;
    pendingBalance: number;
    heldBalance: number;
    totalEarned: number;
    totalDeposited: number;
    totalWithdrawn: number;
  }>;
  ledger: any[];
  deposits: any[];
  withdrawals: any[];
  paymentMethods: any[];
  adsterra: {
    enabled: boolean;
    publisherId: string;
    slots: {
      underHero: { enabled: boolean; code: string };
      middle: { enabled: boolean; code: string };
      footer: { enabled: boolean; code: string };
      tutorial: { enabled: boolean; code: string };
    };
  };
  tutorials: any[];
  siteSettings: {
    siteName: string;
    logoUrl: string;
    telegramUrl: string;
    whatsappNumber: string;
    whatsappUrl: string;
    currency: string;
    announcementNotice: string;
    showNoticePopup: boolean;
  };
  notifications: any[];
}

function getInitialDB(): DBData {
  const adminSalt = bcrypt.genSaltSync(10);
  const adminHash = bcrypt.hashSync('111111', adminSalt);

  return {
    users: [
      {
        id: 'user_admin_01',
        name: 'Pixel Studio BD Admin',
        email: 'sopnilprodhan13@gmail.com',
        mobile: '01320765354',
        passwordHash: adminHash,
        role: 'admin',
        employerStatus: 'approved',
        createdAt: new Date().toISOString(),
        avatar: '/assets/aistudio/WhatsApp_Image_2026-11-06_at_11.02.12_AM_4c49fd8b.jpeg',
        bio: 'Official Super Administrator of PIXEL STUDIO BD Platform.',
        skills: ['Management', 'Fintech', 'Marketplace Administration']
      }
    ],
    employerRequests: [],
    jobs: [],
    jobSubmissions: [],
    freelanceProjects: [],
    freelanceProposals: [],
    contracts: [],
    services: [
      {
        id: 'serv_01',
        title: 'Professional YouTube Thumbnail Design',
        titleBn: 'প্রফেশনাল ইউটিউব থাম্বনেইল ডিজাইন',
        category: 'Thumbnail Design',
        slug: 'thumbnail-design',
        thumbnail: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=600&q=80',
        description: 'Skyrocket your click-through rates with custom designed, vibrant thumbnails.',
        startingPrice: 20,
        packages: {
          basic: { name: 'Basic (১টি থাম্বনেইল)', price: 20, deliveryDays: 1, revisions: 1, features: ['1 High CTR Thumbnail', 'Full HD 1080p'] },
          standard: { name: 'Standard (৩টি থাম্বনেইল)', price: 50, deliveryDays: 2, revisions: 3, features: ['3 High CTR Thumbnails', 'Source PSD Included'] },
          premium: { name: 'Premium (৬টি থাম্বনেইল)', price: 100, deliveryDays: 3, revisions: 99, features: ['6 High CTR Thumbnails', 'Source PSD + Assets'] }
        },
        active: true
      },
      {
        id: 'serv_02',
        title: 'Custom Brand & Vector Logo Design',
        titleBn: 'কাস্টম ব্র্যান্ড ও ভেক্টর লোগো ডিজাইন',
        category: 'Logo Design',
        slug: 'logo-design',
        thumbnail: 'https://images.unsplash.com/photo-1626785774573-4b799315345d?auto=format&fit=crop&w=600&q=80',
        description: 'Stand out from competitors with an iconic, timeless vector logo.',
        startingPrice: 20,
        packages: {
          basic: { name: 'Basic Concept', price: 20, deliveryDays: 2, revisions: 1, features: ['1 Logo Concept', 'High-Res PNG'] },
          standard: { name: 'Standard Brand Mark', price: 50, deliveryDays: 3, revisions: 3, features: ['2 Concepts', 'Vector SVG Files'] },
          premium: { name: 'Complete Identity', price: 150, deliveryDays: 5, revisions: 99, features: ['3 Concepts', 'Full Vector Suite'] }
        },
        active: true
      },
      {
        id: 'serv_03',
        title: 'Dynamic Video Editing & Reels',
        titleBn: 'ডাইনামিক ভিডিও এডিটিং ও রিলস',
        category: 'Video Editing',
        slug: 'video-editing',
        thumbnail: 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?auto=format&fit=crop&w=600&q=80',
        description: 'Fast-paced, hook-driven video editing for Shorts, Reels, and TikTok.',
        startingPrice: 50,
        packages: {
          basic: { name: 'Shorts Clip (60s)', price: 50, deliveryDays: 1, revisions: 1, features: ['Up to 60 sec video', 'Dynamic Subtitles'] },
          standard: { name: 'Polished Content', price: 120, deliveryDays: 2, revisions: 3, features: ['Up to 5 min video', 'Color Correction'] },
          premium: { name: 'Cinematic Master', price: 300, deliveryDays: 4, revisions: 99, features: ['Up to 15 min video', 'Motion Graphics'] }
        },
        active: true
      }
    ],
    serviceOrders: [],
    wallets: {
      user_admin_01: {
        availableBalance: 0,
        pendingBalance: 0,
        heldBalance: 0,
        totalEarned: 0,
        totalDeposited: 0,
        totalWithdrawn: 0
      }
    },
    ledger: [],
    deposits: [],
    withdrawals: [],
    paymentMethods: [
      {
        id: 'pm_bkash',
        provider: 'bKash',
        accountNumber: '01320765354',
        accountType: 'Personal / Merchant',
        accountHolder: 'PIXEL STUDIO BD',
        instructions: 'Send Money বা Payment করুন উপরে দেওয়া bKash নম্বরে। টাকা পাঠিয়ে নিচের ফর্মে TrxID ও যে নম্বর থেকে পাঠিয়েছেন সেটি লিখুন। অ্যাডমিন যাচাই করে আপনার ব্যালেন্সে টাকা যুক্ত করবেন।',
        minDeposit: 10,
        maxDeposit: 25000,
        active: true
      }
    ],
    adsterra: {
      enabled: false,
      publisherId: '',
      slots: {
        underHero: { enabled: false, code: '' },
        middle: { enabled: false, code: '' },
        footer: { enabled: false, code: '' },
        tutorial: { enabled: false, code: '' }
      }
    },
    tutorials: [],
    siteSettings: {
      siteName: 'PIXEL STUDIO BD',
      logoUrl: '/assets/aistudio/WhatsApp_Image_2026-11-06_at_11.02.12_AM_4c49fd8b.jpeg',
      telegramUrl: 'https://t.me/INCOME47776',
      whatsappNumber: '01320765354',
      whatsappUrl: 'https://wa.me/8801320765354',
      currency: 'BDT (৳)',
      announcementNotice: 'স্বাগতম PIXEL STUDIO BD-তে! প্রতিদিন নতুন জব ও ফ্রিল্যান্সিং প্রজেক্টে কাজ করে আয় করুন।',
      showNoticePopup: false
    },
    notifications: []
  };
}

// Read database
function readDB(): DBData {
  try {
    if (!fs.existsSync(DB_FILE)) {
      const initial = getInitialDB();
      fs.writeFileSync(DB_FILE, JSON.stringify(initial, null, 2), 'utf-8');
      return initial;
    }
    const data = fs.readFileSync(DB_FILE, 'utf-8');
    return JSON.parse(data);
  } catch (err) {
    console.error('Error reading DB:', err);
    return getInitialDB();
  }
}

// Write database atomically
function writeDB(data: DBData): void {
  const tempFile = `${DB_FILE}.tmp`;
  fs.writeFileSync(tempFile, JSON.stringify(data, null, 2), 'utf-8');
  fs.renameSync(tempFile, DB_FILE);
}

// Ensure Admin account is present with exact requested credentials
function bootstrapAdmin() {
  const db = readDB();
  const adminEmail = 'sopnilprodhan13@gmail.com';
  let admin = db.users.find((u) => u.email.toLowerCase() === adminEmail.toLowerCase());

  const salt = bcrypt.genSaltSync(10);
  const hash = bcrypt.hashSync('111111', salt);

  if (!admin) {
    const newAdmin = {
      id: 'user_admin_01',
      name: 'Pixel Studio BD Admin',
      email: adminEmail,
      mobile: '01320765354',
      passwordHash: hash,
      role: 'admin',
      employerStatus: 'approved',
      createdAt: new Date().toISOString(),
      avatar: '/assets/aistudio/WhatsApp_Image_2026-11-06_at_11.02.12_AM_4c49fd8b.jpeg',
      bio: 'Official Super Administrator of PIXEL STUDIO BD Platform.',
      skills: ['Platform Management', 'Fintech', 'Design Supervision']
    };
    db.users.push(newAdmin);
    if (!db.wallets[newAdmin.id]) {
      db.wallets[newAdmin.id] = {
        availableBalance: 50000,
        pendingBalance: 0,
        heldBalance: 0,
        totalEarned: 50000,
        totalDeposited: 50000,
        totalWithdrawn: 0
      };
    }
    writeDB(db);
    console.log(`[BOOTSTRAP] Super Admin account created: ${adminEmail}`);
  } else {
    // Ensure admin role and hash match initial configuration
    let changed = false;
    if (admin.role !== 'admin') {
      admin.role = 'admin';
      changed = true;
    }
    if (admin.employerStatus !== 'approved') {
      admin.employerStatus = 'approved';
      changed = true;
    }
    if (changed) {
      writeDB(db);
    }
  }
}

bootstrapAdmin();

async function startServer() {
  const app = express();

  // Middleware for parsing JSON (allow base64 uploads)
  app.use(express.json({ limit: '15mb' }));
  app.use(express.urlencoded({ extended: true, limit: '15mb' }));

  // Helper auth check
  const getUserFromRequest = (req: express.Request) => {
    const authHeader = req.headers.authorization;
    if (!authHeader) return null;
    const token = authHeader.replace(/^Bearer\s+/, '').trim();
    if (!token) return null;
    try {
      const decoded = JSON.parse(Buffer.from(token, 'base64').toString('utf-8'));
      const db = readDB();
      return db.users.find((u) => u.id === decoded.id) || null;
    } catch {
      return null;
    }
  };

  // --- AUTH ENDPOINTS ---
  app.post('/api/auth/register', (req, res) => {
    try {
      const { name, email, mobile, password, role } = req.body;
      if (!name || !email || !password) {
        return res.status(400).json({ error: 'Name, email, and password are required.' });
      }

      const db = readDB();
      const existing = db.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
      if (existing) {
        return res.status(400).json({ error: 'This email is already registered.' });
      }

      const salt = bcrypt.genSaltSync(10);
      const hash = bcrypt.hashSync(password, salt);

      const newUser = {
        id: `user_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        name: name.trim(),
        email: email.trim().toLowerCase(),
        mobile: mobile ? mobile.trim() : '',
        passwordHash: hash,
        role: role === 'employer' ? 'employer' : 'freelancer',
        employerStatus: role === 'employer' ? 'pending' : 'none',
        createdAt: new Date().toISOString(),
        avatar: '',
        bio: '',
        skills: []
      };

      db.users.push(newUser);
      db.wallets[newUser.id] = {
        availableBalance: 0,
        pendingBalance: 0,
        heldBalance: 0,
        totalEarned: 0,
        totalDeposited: 0,
        totalWithdrawn: 0
      };

      writeDB(db);

      const token = Buffer.from(JSON.stringify({ id: newUser.id, email: newUser.email, role: newUser.role })).toString('base64');
      const { passwordHash, ...safeUser } = newUser;

      return res.json({
        user: safeUser,
        token,
        message: 'Registration successful!'
      });
    } catch (e: any) {
      return res.status(500).json({ error: e.message || 'Server error' });
    }
  });

  app.post('/api/auth/login', (req, res) => {
    try {
      const { email, password } = req.body;
      if (!email || !password) {
        return res.status(400).json({ error: 'Email and password are required.' });
      }

      const db = readDB();
      const user = db.users.find((u) => u.email.toLowerCase() === email.trim().toLowerCase());
      if (!user) {
        return res.status(401).json({ error: 'Invalid email or password.' });
      }

      const valid = bcrypt.compareSync(password, user.passwordHash);
      if (!valid) {
        return res.status(401).json({ error: 'Invalid email or password.' });
      }

      const token = Buffer.from(JSON.stringify({ id: user.id, email: user.email, role: user.role })).toString('base64');
      const { passwordHash, ...safeUser } = user;

      return res.json({
        user: safeUser,
        token,
        message: 'Login successful!'
      });
    } catch (e: any) {
      return res.status(500).json({ error: e.message || 'Server error' });
    }
  });

  // Admin Specific Login
  app.post('/api/auth/admin-login', (req, res) => {
    try {
      const { email, password } = req.body;
      if (!email || !password) {
        return res.status(400).json({ error: 'Email and password are required.' });
      }

      const db = readDB();
      const adminEmail = 'sopnilprodhan13@gmail.com';
      const user = db.users.find((u) => u.email.toLowerCase() === email.trim().toLowerCase() && u.role === 'admin');

      if (!user) {
        return res.status(403).json({ error: 'Access denied: Admin credentials not recognized.' });
      }

      const valid = bcrypt.compareSync(password, user.passwordHash);
      if (!valid) {
        return res.status(401).json({ error: 'Invalid admin credentials.' });
      }

      const token = Buffer.from(JSON.stringify({ id: user.id, email: user.email, role: 'admin' })).toString('base64');
      const { passwordHash, ...safeUser } = user;

      return res.json({
        user: safeUser,
        token,
        message: 'Admin access granted.'
      });
    } catch (e: any) {
      return res.status(500).json({ error: e.message || 'Server error' });
    }
  });

  app.get('/api/auth/me', (req, res) => {
    const user = getUserFromRequest(req);
    if (!user) {
      return res.status(401).json({ error: 'Not authenticated' });
    }
    const { passwordHash, ...safeUser } = user;
    const db = readDB();
    const wallet = db.wallets[user.id] || {
      availableBalance: 0,
      pendingBalance: 0,
      heldBalance: 0,
      totalEarned: 0,
      totalDeposited: 0,
      totalWithdrawn: 0
    };
    return res.json({ user: safeUser, wallet });
  });

  app.put('/api/auth/profile', (req, res) => {
    const user = getUserFromRequest(req);
    if (!user) return res.status(401).json({ error: 'Not authenticated' });

    const { name, email, mobile, bio, skills, avatar, newPassword } = req.body;
    const db = readDB();
    const dbUser = db.users.find((u) => u.id === user.id);
    if (!dbUser) return res.status(404).json({ error: 'User not found' });

    if (email && email.trim().toLowerCase() !== dbUser.email.toLowerCase()) {
      const existing = db.users.find((u) => u.email.toLowerCase() === email.trim().toLowerCase() && u.id !== dbUser.id);
      if (existing) {
        return res.status(400).json({ error: 'This email is already taken by another user.' });
      }
      dbUser.email = email.trim().toLowerCase();
    }

    if (name) dbUser.name = name.trim();
    if (mobile !== undefined) dbUser.mobile = mobile.trim();
    if (bio !== undefined) dbUser.bio = bio.trim();
    if (Array.isArray(skills)) dbUser.skills = skills;
    if (avatar) dbUser.avatar = avatar;

    if (newPassword && newPassword.length >= 6) {
      const salt = bcrypt.genSaltSync(10);
      dbUser.passwordHash = bcrypt.hashSync(newPassword, salt);
    }

    writeDB(db);
    const { passwordHash, ...safeUser } = dbUser;
    return res.json({ user: safeUser, message: 'Profile updated successfully!' });
  });

  // --- EMPLOYER ACCESS WORKFLOW ---
  app.post('/api/employer/request-access', (req, res) => {
    const user = getUserFromRequest(req);
    if (!user) return res.status(401).json({ error: 'Please login first' });

    const { reason, companyName, mobileNumber } = req.body;
    const db = readDB();

    const existingPending = db.employerRequests.find(
      (r) => r.userId === user.id && r.status === 'pending'
    );
    if (existingPending) {
      return res.status(400).json({ error: 'You already have a pending employer access request.' });
    }

    const request = {
      id: `req_${Date.now()}`,
      userId: user.id,
      userName: user.name,
      userEmail: user.email,
      mobileNumber: mobileNumber || user.mobile,
      companyName: companyName || '',
      reason: reason || '',
      status: 'pending',
      requestedAt: new Date().toISOString(),
      reviewedAt: null
    };

    db.employerRequests.unshift(request);

    // update user status
    const dbUser = db.users.find((u) => u.id === user.id);
    if (dbUser) {
      dbUser.employerStatus = 'pending';
    }

    writeDB(db);
    return res.json({
      message: 'Employer Access Request submitted for review. Please contact support via Telegram or WhatsApp with your registered email.',
      request
    });
  });

  app.get('/api/admin/employer-requests', (req, res) => {
    const user = getUserFromRequest(req);
    if (!user || user.role !== 'admin') return res.status(403).json({ error: 'Admin only' });

    const db = readDB();
    return res.json(db.employerRequests);
  });

  app.post('/api/admin/employer-requests/:id/action', (req, res) => {
    const user = getUserFromRequest(req);
    if (!user || user.role !== 'admin') return res.status(403).json({ error: 'Admin only' });

    const { action } = req.body; // 'approve' | 'reject' | 'suspend'
    const { id } = req.params;

    const db = readDB();
    const reqItem = db.employerRequests.find((r) => r.id === id);
    if (!reqItem) return res.status(404).json({ error: 'Request not found' });

    const targetUser = db.users.find((u) => u.id === reqItem.userId);

    if (action === 'approve') {
      reqItem.status = 'approved';
      reqItem.reviewedAt = new Date().toISOString();
      if (targetUser) {
        targetUser.role = 'employer';
        targetUser.employerStatus = 'approved';
      }
    } else if (action === 'reject') {
      reqItem.status = 'rejected';
      reqItem.reviewedAt = new Date().toISOString();
      if (targetUser) {
        targetUser.employerStatus = 'rejected';
      }
    } else if (action === 'suspend') {
      reqItem.status = 'rejected';
      if (targetUser) {
        targetUser.role = 'freelancer';
        targetUser.employerStatus = 'none';
      }
    }

    writeDB(db);
    return res.json({ message: `Employer request ${action}d successfully!` });
  });

  // Direct Employer Approval by Email (Admin quick approval)
  app.post('/api/admin/employer/approve-by-email', (req, res) => {
    const user = getUserFromRequest(req);
    if (!user || user.role !== 'admin') return res.status(403).json({ error: 'Admin only' });

    const { email } = req.body;
    if (!email) return res.status(400).json({ error: 'Email is required' });

    const db = readDB();
    const targetUser = db.users.find((u) => u.email.toLowerCase() === email.trim().toLowerCase());
    if (!targetUser) return res.status(404).json({ error: 'No user registered with this email' });

    targetUser.role = 'employer';
    targetUser.employerStatus = 'approved';

    // update or create request entry
    const existingReq = db.employerRequests.find((r) => r.userId === targetUser.id);
    if (existingReq) {
      existingReq.status = 'approved';
      existingReq.reviewedAt = new Date().toISOString();
    } else {
      db.employerRequests.unshift({
        id: `req_${Date.now()}`,
        userId: targetUser.id,
        userName: targetUser.name,
        userEmail: targetUser.email,
        mobileNumber: targetUser.mobile,
        companyName: '',
        reason: 'Direct Admin Verification via Email',
        status: 'approved',
        requestedAt: new Date().toISOString(),
        reviewedAt: new Date().toISOString()
      });
    }

    writeDB(db);
    return res.json({ message: `User ${targetUser.email} has been granted Employer status!` });
  });

  // --- JOBS MARKETPLACE ---
  app.get('/api/jobs', (req, res) => {
    const db = readDB();
    const { category, type, search } = req.query;
    let list = db.jobs;

    if (category && category !== 'All') {
      list = list.filter((j) => j.category.toLowerCase() === (category as string).toLowerCase());
    }
    if (type && type !== 'All') {
      list = list.filter((j) => j.jobType.toLowerCase() === (type as string).toLowerCase());
    }
    if (search) {
      const q = (search as string).toLowerCase();
      list = list.filter((j) => j.title.toLowerCase().includes(q) || (j.titleBn && j.titleBn.includes(q)) || j.description.toLowerCase().includes(q));
    }

    return res.json(list);
  });

  // Public Stats for Homepage
  app.get('/api/stats', (req, res) => {
    const db = readDB();
    const activeJobs = db.jobs.filter((j) => j.status === 'active').length;
    const totalPaid = db.jobSubmissions
      .filter((s) => s.status === 'approved')
      .reduce((acc, curr) => acc + Number(curr.rewardAmount || 0), 0);
    const activeFreelancers = db.users.filter((u) => u.role === 'freelancer').length;
    
    const approvedSubs = db.jobSubmissions.filter((s) => s.status === 'approved').length;
    const totalSubs = db.jobSubmissions.length;
    const successRate = totalSubs > 0 ? Math.round((approvedSubs / totalSubs) * 100) : 0;

    return res.json({
      activeJobs,
      totalPaid,
      activeFreelancers,
      successRate
    });
  });

  app.get('/api/jobs/:id', (req, res) => {
    const db = readDB();
    const job = db.jobs.find((j) => j.id === req.params.id);
    if (!job) return res.status(404).json({ error: 'Job not found' });
    return res.json(job);
  });

  // Post Job (Admin or Approved Employer)
  app.post('/api/jobs', (req, res) => {
    const user = getUserFromRequest(req);
    if (!user) return res.status(401).json({ error: 'Login required' });
    if (user.role !== 'admin' && user.employerStatus !== 'approved') {
      return res.status(403).json({ error: 'Only Admin or Approved Employers can post jobs.' });
    }

    const {
      title,
      titleBn,
      category,
      jobType,
      paymentPerWorker,
      totalSlots,
      deadline,
      description,
      requiredProof,
      thumbnail
    } = req.body;

    if (!title || !category || !paymentPerWorker || !totalSlots) {
      return res.status(400).json({ error: 'Please fill all required fields.' });
    }

    const payPerWorker = Math.max(1, Number(paymentPerWorker));
    const slots = Math.max(1, Number(totalSlots));
    const totalBudget = payPerWorker * slots;

    const db = readDB();

    // Check employer wallet funds if not admin
    if (user.role !== 'admin') {
      const wallet = db.wallets[user.id];
      if (!wallet || wallet.availableBalance < totalBudget) {
        return res.status(400).json({
          error: `Insufficient wallet balance. Total required fund for ${slots} slots is ৳${totalBudget}. Please deposit funds first.`
        });
      }
      // Hold funds in wallet
      wallet.availableBalance -= totalBudget;
      wallet.heldBalance += totalBudget;

      db.ledger.unshift({
        id: `led_${Date.now()}`,
        userId: user.id,
        type: 'employer_funding',
        amount: -totalBudget,
        balanceAfter: wallet.availableBalance,
        description: `Fund reserved for job posting: "${title}" (Slots: ${slots})`,
        referenceId: `job_fund_${Date.now()}`,
        createdAt: new Date().toISOString()
      });
    }

    const newJob = {
      id: `job_${Date.now()}`,
      title,
      titleBn: titleBn || title,
      category,
      employerId: user.id,
      employerName: user.name,
      employerVerified: user.role === 'admin' || user.employerStatus === 'approved',
      budget: totalBudget,
      paymentPerWorker: payPerWorker,
      totalSlots: slots,
      filledSlots: 0,
      deadline: deadline || '2026-12-31',
      jobType: jobType || 'Per Task',
      description,
      requiredProof: requiredProof || 'Proof link / screenshot required.',
      status: 'active',
      createdAt: new Date().toISOString(),
      thumbnail: thumbnail || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=600&q=80'
    };

    db.jobs.unshift(newJob);
    writeDB(db);

    return res.json({ message: 'Job published successfully!', job: newJob });
  });

  // Apply to Job / Submit Work
  app.post('/api/jobs/:id/apply', (req, res) => {
    const user = getUserFromRequest(req);
    if (!user) return res.status(401).json({ error: 'Please login to submit work' });

    const { proofUrl, proofText, screenshot } = req.body;
    if (!proofUrl && !proofText && !screenshot) {
      return res.status(400).json({ error: 'Please provide proof (link, screenshot or description).' });
    }

    const db = readDB();
    const job = db.jobs.find((j) => j.id === req.params.id);
    if (!job) return res.status(404).json({ error: 'Job not found' });
    if (job.status !== 'active') return res.status(400).json({ error: 'This job is no longer active.' });

    // Check if user already submitted for this job
    const existing = db.jobSubmissions.find(
      (s) => s.jobId === job.id && s.freelancerId === user.id
    );
    if (existing) {
      return res.status(400).json({ error: 'You have already submitted work for this job.' });
    }

    const submission = {
      id: `sub_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      jobId: job.id,
      jobTitle: job.title,
      freelancerId: user.id,
      freelancerName: user.name,
      freelancerEmail: user.email,
      proofUrl: proofUrl || '',
      proofText: proofText || '',
      screenshot: screenshot || '',
      status: 'pending',
      rewardAmount: job.paymentPerWorker,
      submittedAt: new Date().toISOString(),
      reviewedAt: null,
      feedback: ''
    };

    db.jobSubmissions.unshift(submission);
    writeDB(db);

    return res.json({ message: 'Work submitted successfully! Waiting for review.', submission });
  });

  // Get Submissions for a Job or all submissions for Admin/Employer
  app.get('/api/submissions', (req, res) => {
    const user = getUserFromRequest(req);
    if (!user) return res.status(401).json({ error: 'Login required' });

    const db = readDB();
    if (user.role === 'admin') {
      return res.json(db.jobSubmissions);
    }
    if (user.role === 'employer') {
      // Find jobs owned by employer
      const employerJobIds = db.jobs.filter((j) => j.employerId === user.id).map((j) => j.id);
      return res.json(db.jobSubmissions.filter((s) => employerJobIds.includes(s.jobId)));
    }
    // Freelancer only sees own submissions
    return res.json(db.jobSubmissions.filter((s) => s.freelancerId === user.id));
  });

  // Review Submission (Approve / Reject) with Atomic Ledger Wallet Payout
  app.post('/api/submissions/:id/review', (req, res) => {
    const user = getUserFromRequest(req);
    if (!user) return res.status(401).json({ error: 'Login required' });

    const { action, feedback } = req.body; // 'approve' | 'reject'
    const db = readDB();
    const submission = db.jobSubmissions.find((s) => s.id === req.params.id);
    if (!submission) return res.status(404).json({ error: 'Submission not found' });

    const job = db.jobs.find((j) => j.id === submission.jobId);
    if (!job) return res.status(404).json({ error: 'Associated job not found' });

    // Authorization: Admin or the job poster
    if (user.role !== 'admin' && job.employerId !== user.id) {
      return res.status(403).json({ error: 'Not authorized to review this submission' });
    }

    if (submission.status !== 'pending') {
      return res.status(400).json({ error: `This submission has already been ${submission.status}. Duplicate processing prevented.` });
    }

    if (action === 'approve') {
      submission.status = 'approved';
      submission.reviewedAt = new Date().toISOString();
      submission.feedback = feedback || 'Work approved and reward credited!';

      job.filledSlots += 1;
      if (job.filledSlots >= job.totalSlots) {
        job.status = 'completed';
      }

      // ATOMIC WALLET REWARD PAYOUT
      const reward = Number(submission.rewardAmount);
      if (!db.wallets[submission.freelancerId]) {
        db.wallets[submission.freelancerId] = {
          availableBalance: 0,
          pendingBalance: 0,
          heldBalance: 0,
          totalEarned: 0,
          totalDeposited: 0,
          totalWithdrawn: 0
        };
      }
      const freelancerWallet = db.wallets[submission.freelancerId];
      freelancerWallet.availableBalance += reward;
      freelancerWallet.totalEarned += reward;

      // Add to Ledger
      db.ledger.unshift({
        id: `led_${Date.now()}`,
        userId: submission.freelancerId,
        type: 'job_reward',
        amount: reward,
        balanceAfter: freelancerWallet.availableBalance,
        description: `Reward credited for Job: "${job.title}"`,
        referenceId: submission.id,
        createdAt: new Date().toISOString()
      });

      // Deduct from employer's held budget if employer is not admin
      if (job.employerId !== 'user_admin_01' && db.wallets[job.employerId]) {
        const empWallet = db.wallets[job.employerId];
        empWallet.heldBalance = Math.max(0, empWallet.heldBalance - reward);
      }

      writeDB(db);
      return res.json({ message: `Submission approved! ৳${reward} credited to ${submission.freelancerName}.` });
    } else {
      submission.status = 'rejected';
      submission.reviewedAt = new Date().toISOString();
      submission.feedback = feedback || 'Work did not meet required instructions.';

      writeDB(db);
      return res.json({ message: 'Submission rejected.' });
    }
  });

  // --- DIGITAL SERVICES ---
  app.get('/api/services', (req, res) => {
    const db = readDB();
    return res.json(db.services);
  });

  app.post('/api/services', (req, res) => {
    const user = getUserFromRequest(req);
    if (!user || user.role !== 'admin') return res.status(403).json({ error: 'Admin only' });

    const { title, titleBn, category, startingPrice, description, thumbnail, packages } = req.body;
    const db = readDB();

    const newService = {
      id: `serv_${Date.now()}`,
      title,
      titleBn: titleBn || title,
      category: category || 'Digital Services',
      slug: title.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
      thumbnail: thumbnail || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=600&q=80',
      description,
      startingPrice: Number(startingPrice) || 100,
      packages: packages || {
        basic: { name: 'Basic', price: Number(startingPrice) || 100, deliveryDays: 1, revisions: 2, features: ['Standard Delivery'] },
        standard: { name: 'Standard', price: (Number(startingPrice) || 100) * 2, deliveryDays: 2, revisions: 4, features: ['High Quality', 'Source Files'] },
        premium: { name: 'Premium', price: (Number(startingPrice) || 100) * 3.5, deliveryDays: 3, revisions: 99, features: ['VIP Quality', 'Unlimited Revisions', 'Source Files'] }
      },
      active: true
    };

    db.services.push(newService);
    writeDB(db);
    return res.json({ message: 'Service added successfully!', service: newService });
  });

  // Order a Service
  app.post('/api/services/:id/order', (req, res) => {
    const user = getUserFromRequest(req);
    if (!user) return res.status(401).json({ error: 'Login required to place order' });

    const { packageType, requirements, referenceLink, deliveryDays } = req.body;
    const db = readDB();
    const service = db.services.find((s) => s.id === req.params.id);
    if (!service) return res.status(404).json({ error: 'Service not found' });

    const pkg = service.packages[packageType || 'basic'];
    const price = pkg ? pkg.price : service.startingPrice;

    // Check user balance
    const wallet = db.wallets[user.id];
    if (!wallet || wallet.availableBalance < price) {
      return res.status(400).json({
        error: `Insufficient wallet balance. This service package costs ৳${price}. Please deposit funds into your wallet.`
      });
    }

    // Deduct price from wallet
    wallet.availableBalance -= price;
    db.ledger.unshift({
      id: `led_${Date.now()}`,
      userId: user.id,
      type: 'service_purchase',
      amount: -price,
      balanceAfter: wallet.availableBalance,
      description: `Ordered service: ${service.title} (${packageType})`,
      referenceId: `ord_${Date.now()}`,
      createdAt: new Date().toISOString()
    });

    const order = {
      id: `ord_${Date.now()}`,
      serviceId: service.id,
      serviceTitle: service.title,
      customerId: user.id,
      customerName: user.name,
      customerEmail: user.email,
      customerMobile: user.mobile,
      packageType: packageType || 'basic',
      price,
      requirements: requirements || '',
      referenceLink: referenceLink || '',
      status: 'pending',
      createdAt: new Date().toISOString(),
      deliveryDate: new Date(Date.now() + (pkg?.deliveryDays || 2) * 86400000).toISOString()
    };

    db.serviceOrders.unshift(order);
    writeDB(db);

    return res.json({ message: 'Service order placed successfully! Our designers are on it.', order });
  });

  app.get('/api/orders', (req, res) => {
    const user = getUserFromRequest(req);
    if (!user) return res.status(401).json({ error: 'Login required' });

    const db = readDB();
    if (user.role === 'admin') {
      return res.json(db.serviceOrders);
    }
    return res.json(db.serviceOrders.filter((o) => o.customerId === user.id));
  });

  app.post('/api/orders/:id/status', (req, res) => {
    const user = getUserFromRequest(req);
    if (!user || user.role !== 'admin') return res.status(403).json({ error: 'Admin only' });

    const { status } = req.body;
    const db = readDB();
    const order = db.serviceOrders.find((o) => o.id === req.params.id);
    if (!order) return res.status(404).json({ error: 'Order not found' });

    order.status = status;
    writeDB(db);
    return res.json({ message: `Order status updated to ${status}.` });
  });

  // --- WALLET, MANUAL DEPOSIT & WITHDRAWAL ---
  app.get('/api/wallet', (req, res) => {
    const user = getUserFromRequest(req);
    if (!user) return res.status(401).json({ error: 'Login required' });

    const db = readDB();
    const wallet = db.wallets[user.id] || {
      availableBalance: 0,
      pendingBalance: 0,
      heldBalance: 0,
      totalEarned: 0,
      totalDeposited: 0,
      totalWithdrawn: 0
    };

    const userLedger = db.ledger.filter((l) => l.userId === user.id);
    const userDeposits = db.deposits.filter((d) => d.userId === user.id);
    const userWithdrawals = db.withdrawals.filter((w) => w.userId === user.id);

    return res.json({
      wallet,
      ledger: userLedger,
      deposits: userDeposits,
      withdrawals: userWithdrawals,
      paymentMethods: db.paymentMethods.filter((p) => p.active)
    });
  });

  // User submits manual deposit
  app.post('/api/wallet/deposit', (req, res) => {
    const user = getUserFromRequest(req);
    if (!user) return res.status(401).json({ error: 'Login required' });

    const { amount, paymentMethod, trxId, senderNumber, screenshot } = req.body;
    const depositAmount = Number(amount);

    if (!depositAmount || depositAmount < 10) {
      return res.status(400).json({ error: 'Minimum deposit amount is ৳10.' });
    }
    if (!trxId || !senderNumber) {
      return res.status(400).json({ error: 'TrxID and Sender Number are required.' });
    }

    const db = readDB();

    // Check duplicate TrxID
    const duplicate = db.deposits.find(
      (d) => d.trxId.trim().toUpperCase() === trxId.trim().toUpperCase()
    );
    if (duplicate) {
      return res.status(400).json({ error: 'This Transaction ID has already been submitted!' });
    }

    const deposit = {
      id: `dep_${Date.now()}`,
      userId: user.id,
      userName: user.name,
      userEmail: user.email,
      amount: depositAmount,
      paymentMethod: paymentMethod || 'bKash',
      trxId: trxId.trim().toUpperCase(),
      senderNumber: senderNumber.trim(),
      screenshot: screenshot || '',
      status: 'pending',
      createdAt: new Date().toISOString(),
      reviewedAt: null,
      rejectionReason: ''
    };

    db.deposits.unshift(deposit);

    // Update pending balance
    if (!db.wallets[user.id]) {
      db.wallets[user.id] = { availableBalance: 0, pendingBalance: 0, heldBalance: 0, totalEarned: 0, totalDeposited: 0, totalWithdrawn: 0 };
    }
    db.wallets[user.id].pendingBalance += depositAmount;

    writeDB(db);

    return res.json({
      message: 'Deposit request submitted successfully! Admin will verify and approve shortly.',
      deposit
    });
  });

  // Admin: Approve Deposit
  app.post('/api/admin/deposits/:id/approve', (req, res) => {
    const user = getUserFromRequest(req);
    if (!user || user.role !== 'admin') return res.status(403).json({ error: 'Admin only' });

    const db = readDB();
    const deposit = db.deposits.find((d) => d.id === req.params.id);
    if (!deposit) return res.status(404).json({ error: 'Deposit request not found' });

    if (deposit.status !== 'pending') {
      return res.status(400).json({ error: `Deposit is already ${deposit.status}. Duplicate approval prevented.` });
    }

    deposit.status = 'approved';
    deposit.reviewedAt = new Date().toISOString();

    const targetWallet = db.wallets[deposit.userId] || {
      availableBalance: 0,
      pendingBalance: 0,
      heldBalance: 0,
      totalEarned: 0,
      totalDeposited: 0,
      totalWithdrawn: 0
    };

    targetWallet.pendingBalance = Math.max(0, targetWallet.pendingBalance - deposit.amount);
    targetWallet.availableBalance += deposit.amount;
    targetWallet.totalDeposited += deposit.amount;

    db.ledger.unshift({
      id: `led_${Date.now()}`,
      userId: deposit.userId,
      type: 'deposit',
      amount: deposit.amount,
      balanceAfter: targetWallet.availableBalance,
      description: `Deposit via ${deposit.paymentMethod} (TrxID: ${deposit.trxId}) approved by Admin`,
      referenceId: deposit.id,
      createdAt: new Date().toISOString()
    });

    writeDB(db);
    return res.json({ message: `Deposit of ৳${deposit.amount} for ${deposit.userName} approved successfully!` });
  });

  // Admin: Reject Deposit
  app.post('/api/admin/deposits/:id/reject', (req, res) => {
    const user = getUserFromRequest(req);
    if (!user || user.role !== 'admin') return res.status(403).json({ error: 'Admin only' });

    const { reason } = req.body;
    const db = readDB();
    const deposit = db.deposits.find((d) => d.id === req.params.id);
    if (!deposit) return res.status(404).json({ error: 'Deposit not found' });

    if (deposit.status !== 'pending') {
      return res.status(400).json({ error: `Deposit is already ${deposit.status}.` });
    }

    deposit.status = 'rejected';
    deposit.reviewedAt = new Date().toISOString();
    deposit.rejectionReason = reason || 'Invalid Transaction ID or payment not received.';

    const targetWallet = db.wallets[deposit.userId];
    if (targetWallet) {
      targetWallet.pendingBalance = Math.max(0, targetWallet.pendingBalance - deposit.amount);
    }

    writeDB(db);
    return res.json({ message: 'Deposit rejected.' });
  });

  // User submits withdrawal request
  app.post('/api/wallet/withdraw', (req, res) => {
    const user = getUserFromRequest(req);
    if (!user) return res.status(401).json({ error: 'Login required' });

    const { amount, paymentMethod, accountNumber, accountHolder, note } = req.body;
    const withdrawAmount = Number(amount);

    if (!withdrawAmount || withdrawAmount < 200) {
      return res.status(400).json({ error: 'Minimum withdrawal amount is ৳200.' });
    }
    if (withdrawAmount > 1000) {
      return res.status(400).json({ error: 'Maximum withdrawal amount is ৳1000.' });
    }
    if (!accountNumber) {
      return res.status(400).json({ error: 'Account number is required.' });
    }

    const db = readDB();
    const wallet = db.wallets[user.id];
    if (!wallet || wallet.availableBalance < withdrawAmount) {
      return res.status(400).json({ error: 'Insufficient available balance.' });
    }

    // Reserve balance
    wallet.availableBalance -= withdrawAmount;
    wallet.heldBalance += withdrawAmount;

    const withdrawal = {
      id: `wth_${Date.now()}`,
      userId: user.id,
      userName: user.name,
      userEmail: user.email,
      amount: withdrawAmount,
      paymentMethod: paymentMethod || 'bKash',
      accountNumber: accountNumber.trim(),
      accountHolder: accountHolder ? accountHolder.trim() : user.name,
      note: note || '',
      status: 'pending',
      createdAt: new Date().toISOString(),
      reviewedAt: null,
      rejectionReason: ''
    };

    db.withdrawals.unshift(withdrawal);

    db.ledger.unshift({
      id: `led_${Date.now()}`,
      userId: user.id,
      type: 'withdrawal',
      amount: -withdrawAmount,
      balanceAfter: wallet.availableBalance,
      description: `Withdrawal request to ${paymentMethod} (${accountNumber})`,
      referenceId: withdrawal.id,
      createdAt: new Date().toISOString()
    });

    writeDB(db);

    return res.json({
      message: 'Withdrawal request submitted! Will be paid to your mobile account within 24 hours.',
      withdrawal
    });
  });

  // Admin: Mark Withdrawal as Paid
  app.post('/api/admin/withdrawals/:id/pay', (req, res) => {
    const user = getUserFromRequest(req);
    if (!user || user.role !== 'admin') return res.status(403).json({ error: 'Admin only' });

    const db = readDB();
    const item = db.withdrawals.find((w) => w.id === req.params.id);
    if (!item) return res.status(404).json({ error: 'Withdrawal request not found' });

    if (item.status !== 'pending' && item.status !== 'processing') {
      return res.status(400).json({ error: `Withdrawal already ${item.status}.` });
    }

    item.status = 'paid';
    item.reviewedAt = new Date().toISOString();

    const targetWallet = db.wallets[item.userId];
    if (targetWallet) {
      targetWallet.heldBalance = Math.max(0, targetWallet.heldBalance - item.amount);
      targetWallet.totalWithdrawn += item.amount;
    }

    writeDB(db);
    return res.json({ message: `Withdrawal of ৳${item.amount} marked as Paid!` });
  });

  // Admin: Reject Withdrawal and Refund Balance
  app.post('/api/admin/withdrawals/:id/reject', (req, res) => {
    const user = getUserFromRequest(req);
    if (!user || user.role !== 'admin') return res.status(403).json({ error: 'Admin only' });

    const { reason } = req.body;
    const db = readDB();
    const item = db.withdrawals.find((w) => w.id === req.params.id);
    if (!item) return res.status(404).json({ error: 'Withdrawal not found' });

    if (item.status !== 'pending') {
      return res.status(400).json({ error: `Withdrawal already ${item.status}.` });
    }

    item.status = 'rejected';
    item.reviewedAt = new Date().toISOString();
    item.rejectionReason = reason || 'Invalid mobile account details or network failure.';

    // Refund held balance back to available balance
    const targetWallet = db.wallets[item.userId];
    if (targetWallet) {
      targetWallet.heldBalance = Math.max(0, targetWallet.heldBalance - item.amount);
      targetWallet.availableBalance += item.amount;

      db.ledger.unshift({
        id: `led_${Date.now()}`,
        userId: item.userId,
        type: 'refund',
        amount: item.amount,
        balanceAfter: targetWallet.availableBalance,
        description: `Refund: Withdrawal request rejected (${reason || 'Account error'})`,
        referenceId: item.id,
        createdAt: new Date().toISOString()
      });
    }

    writeDB(db);
    return res.json({ message: 'Withdrawal rejected and balance refunded.' });
  });

  // --- ADSTERRA MANAGEMENT ---
  app.get('/api/settings/adsterra', (req, res) => {
    const db = readDB();
    return res.json(db.adsterra);
  });

  app.post('/api/settings/adsterra', (req, res) => {
    const user = getUserFromRequest(req);
    if (!user || user.role !== 'admin') return res.status(403).json({ error: 'Admin only' });

    const db = readDB();
    db.adsterra = req.body;
    writeDB(db);
    return res.json({ message: 'Adsterra settings saved successfully!' });
  });

  // --- TUTORIALS ---
  app.get('/api/tutorials', (req, res) => {
    const db = readDB();
    return res.json(db.tutorials);
  });

  app.post('/api/tutorials', (req, res) => {
    const user = getUserFromRequest(req);
    if (!user || user.role !== 'admin') return res.status(403).json({ error: 'Admin only' });

    const { title, titleBn, youtubeUrl, category, description, featured } = req.body;
    let youtubeId = '';
    const match = youtubeUrl?.match(/(?:v=|\/embed\/|youtu\.be\/)([\w-]{11})/);
    if (match) youtubeId = match[1];

    const db = readDB();
    const tutorial = {
      id: `tut_${Date.now()}`,
      title,
      titleBn: titleBn || title,
      youtubeUrl,
      youtubeId: youtubeId || 'dQw4w9WgXcQ',
      category: category || 'How to Use',
      description,
      featured: Boolean(featured),
      createdAt: new Date().toISOString()
    };

    db.tutorials.unshift(tutorial);
    writeDB(db);
    return res.json({ message: 'Tutorial added successfully!', tutorial });
  });

  // --- ADMIN ANALYTICS ---
  app.get('/api/admin/analytics', (req, res) => {
    const user = getUserFromRequest(req);
    if (!user || user.role !== 'admin') return res.status(403).json({ error: 'Admin only' });

    const db = readDB();
    const totalUsers = db.users.length;
    const totalFreelancers = db.users.filter((u) => u.role === 'freelancer').length;
    const totalEmployers = db.users.filter((u) => u.role === 'employer').length;
    const pendingEmployerRequests = db.employerRequests.filter((r) => r.status === 'pending').length;

    const totalJobs = db.jobs.length;
    const activeJobs = db.jobs.filter((j) => j.status === 'active').length;
    const pendingSubmissions = db.jobSubmissions.filter((s) => s.status === 'pending').length;
    const approvedSubmissions = db.jobSubmissions.filter((s) => s.status === 'approved').length;

    const totalDeposited = db.deposits
      .filter((d) => d.status === 'approved')
      .reduce((acc, curr) => acc + curr.amount, 0);
    const pendingDeposits = db.deposits.filter((d) => d.status === 'pending').length;

    const totalWithdrawn = db.withdrawals
      .filter((w) => w.status === 'paid')
      .reduce((acc, curr) => acc + curr.amount, 0);
    const pendingWithdrawals = db.withdrawals.filter((w) => w.status === 'pending').length;

    const totalOrders = db.serviceOrders.length;
    const pendingOrders = db.serviceOrders.filter((o) => o.status === 'pending').length;

    return res.json({
      totalUsers,
      totalFreelancers,
      totalEmployers,
      pendingEmployerRequests,
      totalJobs,
      activeJobs,
      pendingSubmissions,
      approvedSubmissions,
      totalDeposited,
      pendingDeposits,
      totalWithdrawn,
      pendingWithdrawals,
      totalOrders,
      pendingOrders,
      depositsList: db.deposits,
      withdrawalsList: db.withdrawals,
      employerRequests: db.employerRequests,
      recentLedger: db.ledger.slice(0, 20)
    });
  });

  // Serve static assets from public
  app.use(express.static(path.join(__dirname, 'public')));

  // In development, hook Vite middleware
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: process.env.DISABLE_HMR !== 'true' },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    // Production static serving
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[PIXEL STUDIO BD] Server listening on port ${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Fatal server startup error:', err);
  process.exit(1);
});
