# PIXEL STUDIO BD
### Multi-Vendor Freelancing, Job Marketplace, Digital Services & Micro-Job Platform with BDT Wallet

**PIXEL STUDIO BD** is a production-grade full-stack marketplace designed for Bangladesh, featuring micro-tasks, high-value freelancing contracts, a digital creative services catalog, manual mobile banking deposit & withdrawal verification (bKash, Nagad, Rocket), multi-role authentication (Admin, Freelancer, Employer), and Adsterra advertising management.

---

## 🚀 Key Highlights & Features

1. **Multi-Role User Architecture**:
   - **Super Admin**: Complete management over jobs, categories, deposit/withdrawal requests, submission proofs, service orders, Adsterra settings, and YouTube tutorials.
   - **Freelancers**: Profile creation, skill showcase, task search, work submission with proofs (links & screenshots), personal BDT wallet, and mobile withdrawals.
   - **Employers**: Multi-vendor job posting with per-worker rewards and slot calculations, candidate verification, submission reviews, and funded budgets. Requires Admin verification.

2. **Employer Verification Workflow**:
   - Users apply via *Become an Employer*.
   - Status transitions to `Pending Approval`.
   - Admin verifies and grants Employer permissions via direct email lookup or review buttons.
   - Quick direct contacts via WhatsApp (`01320765354`) & Telegram (`https://t.me/INCOME47776`).

3. **Manual Mobile Financial System (BDT ৳)**:
   - **Supported Gateways**: bKash, Nagad, Rocket.
   - **Manual Deposit Verification**: Users send money to the official admin account (`01320765354`), submit their TrxID, sender mobile number, and payment screenshot. Balance is only credited upon Admin approval with duplicate TrxID prevention.
   - **Withdrawals**: Minimum payout ৳100. Balance is held in reserve until marked as `Paid` by the Admin. If rejected, held funds are immediately refunded to the user's available balance.
   - **Immutable Financial Ledger**: Every reward, deposit, withdrawal, and service purchase creates a transparent audit trail with atomic balance tracking.

4. **Digital Creative Services**:
   - YouTube High-CTR Thumbnail Design (Basic, Standard, Premium packages).
   - Brand Vector Logo Design.
   - 60-Second Video Reels & Shorts Editing with dynamic subtitles.
   - Promotional Banners, Retouching, and Responsive Web Design.
   - Direct ordering with automatic wallet balance deduction.

5. **Adsterra Advertising Manager (Section 20)**:
   - Zero Google AdSense.
   - Dedicated slots for Adsterra Publisher banners (Under Hero, Middle, Footer, and Tutorial pages).
   - Clean hiding when slots are unconfigured.

6. **Bilingual Experience**:
   - Full instant translation between **বাংলা (Bengali)** and **English** across all pages, forms, and alerts.

---

## 🔑 Default Administrator Credentials

- **Admin Login URL**: `/admin/login` or via the top navigation Admin button.
- **Admin Email**: `sopnilprodhan13@gmail.com`
- **Initial Password**: `111111`

*Note: You can update your Super Admin password at any time inside the Admin Dashboard under Security Settings.*

---

## 🛠️ Tech Stack

- **Frontend**: React 19, TypeScript, Tailwind CSS v4, Lucide Icons, Canvas Confetti.
- **Backend**: Node.js & Express API with full-stack TypeScript execution (`tsx server.ts`).
- **Database & Ledger**: Self-contained persistent JSON file database with atomic transaction locks (`data/db.json`).
- **Security**: Password hashing with `bcryptjs`, session tokens, and server-enforced role access controls.

---

## 📦 Local Setup Instructions

```bash
# 1. Install dependencies
npm install

# 2. Run dev server on port 3000
npm run dev

# 3. Build for production
npm run build
```

---

## 📞 Support Contacts

- **Official Telegram**: [https://t.me/INCOME47776](https://t.me/INCOME47776)
- **WhatsApp Hotline**: [https://wa.me/8801320765354](https://wa.me/8801320765354) (`01320765354`)
